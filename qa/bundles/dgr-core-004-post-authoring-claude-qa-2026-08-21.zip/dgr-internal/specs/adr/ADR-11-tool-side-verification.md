---
id: ADR-11
type: ADR
status: active
supersedes: []
superseded-by: null
owner: Founder + Engineering
last-reviewed: 2026-07-23
---

# ADR-11 — Tool-side verification

**Status:** Active  
**Decision:** Use OpenClaw's native `before_tool_call` runtime check as the
Phase 1 enforcement point (founder resolution C; DECI-0006). `CORE-002` proves
this boundary.

Sequence a verifier wrapper/SDK for the second adapter in Phase 2, followed by a
gateway/proxy for Phase 3 operator-proof enforcement. These upgrades are
referenced, not built here.

## Context

Non-bypassability requires the effectful tool side to verify that execution is
authorized, not merely trust an agent's claim that the gate returned ALLOW.
This ADR frames where and how that verification contract is enforced. It does
not modify or propose the T0 token format, decision point, fail-closed guard, or
hash chain.

## Decision drivers

- No effectful action without verifiable, request-bound authorization.
- Fail closed on missing, expired, mismatched, replayed, or unverifiable proof.
- Bind proof to tenant, principal, tool, action, parameters/evidence digest, and
  validity window as required by the selected T0 contract.
- Keep deploy access distinct from data access.
- Make bypass attempts observable and testable.

## Options

### Option A — Verification library embedded in every adapter

Each approved tool adapter invokes one maintained verification library before
calling the effectful backend.

**Tradeoffs:** Low network overhead and consistent reusable logic; language and
version drift can create bypass variants.

### Option B — Local sidecar or proxy enforcement point

Adapters send effectful requests through a local enforcement process that
verifies authorization before forwarding.

**Tradeoffs:** Centralizes verification per workload; adds deployment,
availability, and local-bypass hardening requirements.

### Option C — Remote enforcement proxy at the resource boundary

Effectful traffic passes through a managed proxy or service endpoint that
verifies authorization.

**Tradeoffs:** Strong centralized control and audit; adds latency, service
availability, and integration constraints.

### Option D — Layered verification

Use an adapter library plus a resource-boundary control for high-impact actions.

**Tradeoffs:** Defense in depth; more operational complexity and reconciliation
between enforcement layers.

## Required evidence before decision

- Bypass-suite coverage for direct SDK/API calls, stale proof, parameter swap,
  replay, network failure, and verifier exception.
- Compatibility with ADR-10 identity choice and ADR-6 isolation.
- Deterministic verification tests and an explicit degraded-mode outcome.
- Founder-approved scope for the first demo tools and non-payment action.

## Consequences

- Phase 1 bypass evidence targets the actual OpenClaw runtime hook.
- The native hook does not by itself establish operator-proof enforcement.
- The wrapper and gateway remain sequenced upgrades, not implied current state.
