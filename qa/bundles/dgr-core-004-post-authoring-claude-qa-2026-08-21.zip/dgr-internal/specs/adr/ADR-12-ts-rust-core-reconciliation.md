---
id: ADR-12
type: ADR
status: active
supersedes: []
superseded-by: null
owner: Founder + Engineering
last-reviewed: 2026-07-23
---

# ADR-12 — TypeScript and Rust core reconciliation

**Status:** Active  
**Decision:** Option A — Rust now. The core is Rust per ADR-7; PR #2's
TypeScript core is a throwaway spike. `CORE-001` through `CORE-005` are authored
in Rust (DECI-0006).

The goal is the fastest path to a green bypass suite, and the re-runnable suite
is the asset that makes any future implementation change safe. Rust ramp must
not stall the enforcement proof. If it does, the fallback is
TS-now/Rust-later, with the suite as the migration guarantee; that fallback is
recorded but **not chosen**.

## Context

ADR-7 locks a Rust core using Cedar's native crate. The supplied build-state
record describes draft PR #2 as a pnpm/TypeScript monorepo containing T0
components, core policy/types, tests/CI, and an OpenClaw adapter. Both statements
are preserved until the founder decides whether TypeScript is a prototype,
adapter layer, temporary implementation, or intended core change.

T0 files are review-only. This ADR does not authorize their modification.

## Decision drivers

- Preserve the ADR-7 assurance rationale and Cedar integration.
- Avoid two divergent decision semantics or policy-evaluation paths.
- Keep adapters and developer experience practical.
- Preserve deterministic tests and bypass-suite evidence across any transition.
- Make the source-of-truth boundary explicit.

## Options

### Option A — Rust remains the core; TypeScript is adapter/prototype only

Define a stable Rust-core contract and restrict TypeScript to SDK, adapter, or
prototype responsibilities.

**Tradeoffs:** Aligns with ADR-7; requires migration or replacement of any core
logic currently implemented in TypeScript.

### Option B — Staged TypeScript-to-Rust migration

Use the current TypeScript work to validate contracts while moving bounded
components to Rust behind acceptance tests.

**Tradeoffs:** May preserve near-term momentum; creates a temporary dual-stack
period requiring strict parity and cutover gates.

### Option C — Reopen ADR-7 and adopt a TypeScript core

Treat PR #2 as evidence to revisit the locked language decision.

**Tradeoffs:** Reduces immediate migration; requires a new assurance, Cedar,
performance, and non-bypassability case rather than silently drifting.

### Option D — Split core with a narrow interop boundary

Keep deterministic enforcement in Rust and selected orchestration or
integration logic in TypeScript through a versioned interface.

**Tradeoffs:** Can isolate critical logic; introduces interop failure modes,
versioning, and additional bypass-suite coverage.

## Required evidence before decision

- Inventory of PR #2 components by T0/T1/T2/T3 tier.
- Semantic-parity tests and ownership of the policy decision contract.
- Cedar integration comparison.
- Migration/cutover plan with rollback and bypass-suite gates.
- Founder-approved source-of-truth and deprecation policy.

## Consequences

- TypeScript core code in PR #2 is not production source of truth.
- Phase 1 bypass-suite work targets Rust.
- Any future language change must preserve behavior through the re-runnable
  bypass suite.
