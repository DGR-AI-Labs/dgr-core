---
id: SRS-07
type: SRS
status: active
supersedes: []
superseded-by: null
owner: Founder/CEO + CTO
last-reviewed: 2026-07-23
---

# SRS-07 — Threat Model & Trust Boundary

**Governing invariants:** INV-1 (bounded, deterministic hot path), INV-2 (fail-closed; ALLOW only for an affirmative, completed, fully-evidenced, fresh permit), INV-3 (evidence sufficiency/freshness), INV-4 (audit-before-return, tamper-evident). This document bounds the claims those invariants license.
**Status:** v2 · 6 Jul 2026 · authoritative for the MVP **and** hosted (`dgr-cloud`) security guarantee. Extends v1 (17 Jun 2026) with the ADR-6/ADR-7 hosted-tenancy boundary.
**Relates to:** ADR-6 (tenant isolation, silo-per-account), ADR-7 (compute/ledger), SRS-04 (audit log), SRS-06 (failure & acceptance), CISO-BRIEF (claims must be bounded here and test-backed by M5).

This document exists so every claim in `CISO-BRIEF.md` is not only *backed by a test* but *bounded by a stated adversary model*. "Cannot fail open" and "non-bypassable" are precise claims about a specific boundary against a specific set of adversaries — this draws that boundary.

---

## 1. What DGR protects (the asset)

The integrity of the **`ALLOW` decision** and its **durable record**:

- An `ALLOW` is returned **only** for an affirmative, completed, fully-evidenced, fresh policy permit (INV-2/INV-3).
- Every binding decision is recorded, before it is returned, in a tamper-evident log (INV-4).

DGR is an **integrity** control, not a confidentiality or availability control. Its job is to make a *wrong permissive outcome* impossible-by-construction within the boundary, and to make the record of every decision impossible to silently alter.

## 2. What DGR does not protect

- **Availability of the guarded action.** Under load, failure, or attack DGR **fails closed** — it degrades to BLOCK/ESCALATE, never to ALLOW. A denial-of-service against DGR produces *refusals*, not *unauthorized permits*. That is the intended failure direction, not a defect.
- **Confidentiality of upstream data** beyond the digesting/reference discipline in SRS-04 (raw action parameters and resource attributes are stored by digest/reference, not value).
- **Correctness of the policy itself.** DGR enforces the policy bundle it is given; a wrong policy is a policy-authoring failure (SRS-05 lifecycle), not an enforcement failure.
- **The upstream evidence source of truth.** DGR reads pre-materialized evidence (SRS-02); it does not certify the source system that produced it (it does record freshness/verification and escalates on staleness/unverifiability).

## 3. The trust boundary — developer-grade vs regulator-grade

The non-bypassability claim is **tiered**, and the tier must never be overstated (honest-claim-scoping):

- **Developer-grade (OSS OpenClaw plugin).** The gate is **non-bypassable by the agent** but **bypassable by the operator** — a local single-process agent means the human running it can disable the plugin. Guaranteed: an agent cannot obtain ALLOW without an evidenced permit, and cannot route around the gate to reach effectful tools *within the runtime's control*. Not guaranteed: an operator who owns the process cannot be stopped from disabling DGR. This tier is honestly the weaker control.
- **Regulator-grade (`dgr-cloud`, hosted silo).** The gate is **operator-proof**: out-of-process, tool-side verification of DGR-signed authorization, capability tokens, network segmentation, per-tenant account isolation. Downstream tools reject any action not carrying a valid DGR authorization.

## 4. Adversary model (in-scope / out-of-scope)

| # | Adversary | Tier | In scope? | Guarantee |
|---|---|---|---|---|
| A1 | Malicious / compromised **agent** | dev + hosted | **In** | Cannot obtain ALLOW without an affirmative evidenced permit (INV-2); cannot self-ratify via its own justification (see §6); cannot reach effectful tools without DGR authorization (hosted: tool-side verification) |
| A2 | **Operator** running the agent | dev | **Out** | Local operator can disable the plugin — stated, not defended, at the OSS tier |
| A2′ | **Tenant's own operator** | hosted | **Out** (within own tenant) | Trusted within their own tenant silo; cannot reach any *other* tenant (A3) |
| A3 | Compromise of **one tenant account** | hosted | **In** | Blast radius contained to that tenant: cannot mint authorizations for other tenants (per-tenant CMK, §5), cannot read or rewrite other tenants' ledgers; can write only its own ledger, which is replicated **write-once** to log-archive |
| A4 | Compromise of the **deploy / CI-CD role** | hosted | **In** (primary shared surface) | Can provision/alter infrastructure but **cannot decrypt a tenant CMK or read ledger contents** (deploy ≠ data access); mitigated by short-lived OIDC-scoped, per-tenant deploy roles |
| A5 | Compromise of the **DGR control plane in one tenant** | hosted | **In** | Bounded to that tenant; cannot forge cross-tenant authorizations |
| — | AWS platform compromise; root of the **management / security** org accounts; KMS/HSM side-channel; global availability/DoS | — | **Out** | Explicitly out of scope; DoS resolves to BLOCK, not ALLOW |

## 5. Hosted-tenancy trust boundary (ADR-6 / ADR-7)

- **Tenant boundary = a dedicated AWS account.** No tenant compute or tenant decision data is shared. Only org-governance accounts (management, security/log-archive, CI-CD, DGR non-prod) are shared, and they hold **no** tenant decision data (log-archive holds write-once replicas only).
- **Per-tenant KMS CMK is the crown-jewel boundary.** A shared signing key would let one tenant's compromise mint authorizations for all — forbidden. Each tenant has its own CMK. **Ed25519 signing keys are not KMS keys** (KMS has no Ed25519): the private signing key is stored at rest (e.g., Secrets Manager) wrapped by the tenant CMK, and the gate signs **in-process**. KMS on the hot path is only envelope encryption for the ledger, with data-key caching (ADR-7).
- **Deploy ≠ data access.** The Service Catalog launch/deploy role provisions the silo but is denied CMK decrypt and ledger read. This is the load-bearing IAM assertion for A4.
- **WORM audit** is a **cross-account, write-once** replication from the tenant's ledger to the log-archive S3 Object Lock bucket. The tenant can write its own history; it cannot rewrite it, and the archived copy is immutable and outside the tenant's control.
- **Gate execution role** inside a tenant is least-privilege: DynamoDB append + KMS `GenerateDataKey`/`Decrypt` + signing-key read; nothing else.

## 6. The non-bypassability claim, bounded

"Non-bypassable" means, precisely: **no path returns a binding ALLOW that DGR did not affirmatively issue against a fully-evidenced permit, and no effectful tool executes a consequential action without a valid DGR authorization** — at the regulator-grade tier, enforced by tool-side verification; at the developer-grade tier, enforced against the agent but not the operator. It does **not** mean DGR resists an operator with process control (dev tier) or a compromised AWS platform (out of scope). DGR also never accepts an agent's or an LLM's own justification as the permit (ICAIL bias-laundering / LLM-as-judge anti-pattern): justification is recorded evidence, never the gate.

## 7. Fail-closed under degradation (ties to SRS-06 — no failure row ends in ALLOW)

| Degradation | Outcome |
|---|---|
| DGR/control plane unavailable | BLOCK/ESCALATE |
| Ledger append fails/times out (candidate ALLOW) | ESCALATE / AUDIT_UNAVAILABLE — never ALLOW (SRS-04) |
| KMS throttled / data-key unavailable | fail closed on the affected operation |
| Decision deadline exceeded (incl. group-commit flush) | ESCALATE / DEADLINE_EXCEEDED (SRS-01/ADR-7) |
| Evidence missing / stale / unverifiable | ESCALATE (SRS-02); no benefit of the doubt |
| Cedar eval error | BLOCK (SRS-03) |

## 8. Residual risks & explicitly-accepted assumptions

- **OSS operator bypass (A2)** — accepted at the dev tier; the mitigation is the *hosted* tier, not a patch to the plugin.
- **Deploy-role blast surface (A4)** — the one genuine shared surface in a silo; mitigated but not eliminated; hardened via scoped short-lived OIDC roles and the CMK/ledger deny.
- **Async replication lag** — the write-once archive copy is eventually consistent (seconds) behind the synchronous in-tenant chain; the *synchronous* chain (SRS-04 `prev_hash`/`record_hash`) is what gates ALLOW, so lag does not weaken the verdict-time guarantee.
- **Policy correctness and evidence-source truth** — out of DGR's remit (see §2).

## 9. What must be tested to back each claim (M5)

- A1/INV-2: IT-1 fuzzed fail-closed (≥10⁵ injections) — no ALLOW without an evidenced permit.
- INV-4/A3: chain-integrity verifier (SRS-04) + cross-account write-once replication test.
- A4: IAM assertion test — deploy role cannot decrypt CMK or read ledger (deny/absence).
- Deadline: SRS-01 deadline test — overflow → ESCALATE/DEADLINE_EXCEEDED, never ALLOW.
- Determinism: SRS-02 byte-identical-tuple test with shuffled evidence arrival — canonical ordering holds.
- Non-bypass (hosted): tool-side verification rejects any action without a valid DGR authorization.

Until each is green (M5), the corresponding CISO-BRIEF claim is **target design, unproven** — and must be worded that way anywhere it appears before M5.
