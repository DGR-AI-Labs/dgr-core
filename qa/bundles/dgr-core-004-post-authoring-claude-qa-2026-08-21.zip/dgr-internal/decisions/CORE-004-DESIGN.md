---
id: CORE-004-DESIGN
type: DECI
status: active
supersedes: []
superseded-by: null
owner: Founder
last-reviewed: 2026-08-19
relates-to:
  - CORE-004
  - VAL-004
---

# CORE-004 design decision record — ATK-06 escalate → deny-on-timeout

## Purpose and status

This record freezes the contract that `VAL-004` fixtures,
`CORE-004-T3-tests`, and the founder-authored `CORE-004-T0-*` units are
authored against. Nothing in CORE-004 may be implemented before the ownership
map in §9 is updated.

All decisions below are founder-confirmed, including the R-3 ordering
resolution in §4.

## 1. Fork selection

**(b) + (c), documented.**

- **(b)** CORE-004 adds a founder-designed temporal/approval seam: a new
  `Escalated` observation, an `ApprovalStore` port, and a durable-local pending
  store.
- **(c)** Real human delivery, real waiting across process lifetimes,
  restart/retry behavior, cross-instance pending state, and live
  non-bypassability are deferred (see §8).

Option (a), “provable in the existing single-shot model,” is rejected: the
attack requires two externally visible moments—an observable review request
and a later deadline transition to denial—which the single terminal
observation cannot express.

## 2. State machine and observable sequence

Minimal machine for ATK-06, deny path only:

```text
Requested(deadline) --(now > deadline AND no approval)--> DeniedOnTimeout
```

The gate test asserts this observable sequence:

1. **Escalation moment.** An action requiring approval, with no pending record,
   is escalated. A pending record is durably written, and the boundary observes
   `Escalated { review_request_id, deadline }`, with
   `authorization_issued: false` and `effectful_invocations: 0`.
2. **Timeout moment.** With `now > deadline` and no approval, the terminal
   outcome is `Blocked { outcome:
   RequiredOutcome::EscalateThenDenyOnTimeout, authorization_issued: false,
   effectful_invocations: 0 }`.

The test asserts the ordered pair
`[Escalated, Blocked { EscalateThenDenyOnTimeout }]` with zero effectful
invocations throughout. The terminal outcome is derived from
`attack_by_id("ATK-06").expected`; it is never hardcoded.

## 3. `Escalated` observation contract

Add a new `BeforeToolCallObservation::Escalated` variant carrying at least the
`review_request_id` and the `deadline`.

All of these invariants are T0-enforced:

- `Escalated` is not an authorization. `authorization_issued` is false, and
  the effectful probe is never invoked on this path.
- `Escalated` is emitted only after the pending record is durably written
  (persist-then-observe; see §5), so a crash cannot lose the fact that
  escalation was requested.
- `Escalated` is distinct from `Blocked`, `Proceeded`, and `GuardFault`. No
  consumer may treat it as, coerce it to, or default it into an allow.

## 4. Founder-confirmed ordering resolution: R-3

The approval window in §7 is 24 hours, while the established capability-token
lifetime is 300 seconds. The guard order is signature → lifetime/expiry →
binding → consume. A second token presentation 24 hours later would therefore
hit expiry first and return ATK-02, permanently masking ATK-06.

**R-3 is confirmed: decouple timeout from token presentation.** Deadline expiry
is a fact about time and the pending record, not an agent action:

- the escalation moment occurs on `before_tool_call` with a valid token and
  the existing full verification order, unchanged;
- the timeout moment evaluates the pending record against the trusted clock on
  a distinct founder-authored path and yields the terminal
  `Blocked { EscalateThenDenyOnTimeout }`; and
- token-bearing requests retain the existing verify-then-decide ordering.

The two moments therefore use two different surfaces: a `before_tool_call`
escalation and a timeout evaluation. `VAL-004` and the T3 tests must use that
shape.

**Rejected alternative R-1:** evaluate pending escalation before expiry on
token re-presentation. This would let a long-expired token drive a decision
path and would advance a new check ahead of the existing expiry floor.

**Rejected alternative R-2:** constrain the approval window to the token
lifetime. A window of 300 seconds or less defeats human review.

## 5. `ApprovalStore` port and outcomes

Add a founder-owned port structurally parallel to `ConsumptionStore` and its
durable-local implementation, using the already-pinned `rusqlite` dependency.

Minimum operations for the timeout-only scope:

- record pending escalation →
  `Recorded | AlreadyPending { deadline } | Faulted(GuardFault)`; and
- look up pending escalation →
  `Pending { deadline } | NotFound | Faulted(GuardFault)`.

Expected rejections and operational faults remain distinct types.
`Faulted(GuardFault)` is an internal failure and fails closed; it is never
conflated with `AlreadyPending` or `NotFound`.

### Deadline immutability

The deadline is computed once, at first escalation, from the trusted injected
clock and is never extended. `AlreadyPending` returns the original deadline.
Re-presentation must not reset or extend it, because repeated escalation could
otherwise prevent timeout indefinitely.

### Persist then observe

The pending record must be durably committed before `Escalated` is observed.
Commit failure becomes `Faulted`, then fails closed. Failure direction is
always denied-or-pending, never authorized.

The illustrative durable-local shape is a table keyed by
`review_request_id`, with explicit `requested_at`, `deadline`, and status
columns; one persistent connection per store instance; and `open_in_memory()`
and `open_at(path)` constructors mirroring the S2 consumption store. The exact
implementation remains founder-authored T0.

## 6. Approve-path scope

**6-A is selected: CORE-004 covers timeout → deny only.**

CORE-004 proves escalation is observable and, absent approval by the deadline,
the action is denied. It does not implement a path by which approval grants
execution.

**6-B is a future extension:** `escalate → {approve | timeout}` requires a
separate approval-authenticity design. A store row alone cannot authorize an
action. A future grant path requires signed approvals bound to the
`review_request_id` and action commitment, a pinned approver key set, and
single-use replay protection, with its own VAL/T3/T0 cycle.

The future grant path must also decide whether execution requires a freshly
minted token after the original 300-second token has expired. Neither question
is part of 6-A.

## 7. Window, inequality, arithmetic, and TTL rules

- **Window:** 24 hours (86,400 seconds), held as a founder-owned constant in a
  T0 unit. A read-only conformance mirror may expose the value to fixtures
  without allowing fixture code to change the enforced value.
- **Inequality:** timed out iff `now > deadline`. Exactly at the deadline the
  escalation remains pending. Fixtures pin `deadline - 1`, `deadline`, and
  `deadline + 1`.
- **Arithmetic:** compute
  `requested_at.checked_add(APPROVAL_WINDOW_SECONDS)`. `None` is a fail-closed
  fault, never panic or wrapping arithmetic. Do not compute `now - deadline`.
- **Clock:** use only the trusted injected `now_unix_seconds`; never read wall
  clock inside the decision and never accept time from an agent-controlled
  request.

### TTL prohibition

The deadline is stored explicitly and compared against the injected clock at
read time. SQLite cleanup, DynamoDB TTL, or another background reaper may only
reclaim storage; it must never be the enforcement signal.

Provider TTL is asynchronous, and using record absence to mean “timed out” is
ambiguous with never-escalated, early-reaped, and failed-write states.
Authorization behavior must not depend on that ambiguity.

## 8. Isolation/runtime fence

CORE-004 isolation proves that escalation is durably recorded locally and
observable, the deadline is set once from the trusted clock and never
extended, and `now > deadline` without approval produces
`Blocked { EscalateThenDenyOnTimeout }` with no authorization and zero
effectful invocations.

Real delivery of the review request to a human, real latency across process
lifetimes, restart/retry behavior in a live runtime, cross-instance pending
state (the S3 analogue), and approval-path route-around/non-bypassability are
deferred to a separately tracked runtime item. The canonical backlog already
uses `RUNTIME-005`; the backlog must explicitly amend that item or allocate a
new ID rather than create an ID collision.

The downstream bounded claim must be used verbatim:

> CORE-004 proves the escalate → deny-on-timeout contract for a single guard
> instance and its local pending store under a modeled clock. It does not prove
> real human delivery, real waiting across restarts, cross-instance pending
> state, or live non-bypassability.

## 9. T0 ownership map

Before implementation, `T0-AUTHORS.md` and
`tests/bypass-rust/T0-BOUNDARY.md` must record these surfaces.

### T0 — founder-authored

- the `ApprovalStore` port/trait;
- the SQLite pending-store implementation;
- escalation and timeout decision logic extending the founder guard unit;
- the R-3 timeout-evaluation path; and
- adapter behavior that emits `Escalated` and guarantees no authorization and
  no invocation on that path.

### T3 — agent-authorable only after the contract is frozen

- `VAL-004` fixture data: review-request IDs, requested/deadline values,
  clocks at `deadline - 1`, `deadline`, and `deadline + 1`, and the no-approval
  scenario;
- a deterministic/fake store used solely by tests; and
- RED conformance tests asserting the
  `[Escalated, Blocked { ... }]` sequence with the registry-derived outcome
  and zero invocations.

Any shared enum or trait encoding consequential pending, escalated, approved,
or denied semantics is T0 until the founder records otherwise.

## 10. Authoring order

1. Publish this founder-confirmed record.
2. Update the dgr-core T0 ownership/boundary documents and pin this record;
   reconcile the deferred runtime backlog item.
3. Author `VAL-004` fixtures against the frozen contract.
4. Author `CORE-004-T3-tests` RED conformance scaffolding.
5. Founder-author the port, store, escalation/timeout logic, R-3 timeout path,
   and `Escalated` adapter behavior.
6. Un-ignore ATK-06 only after the founder implementation turns the reviewed
   RED tests green without changing the registry-derived expectation.
7. Run the exact-commit T0 gate: adversarial tests, independent human review,
   cross-model review, fresh Semgrep and CodeQL, cargo-deny, founder approval,
   and human merge.

## 11. Non-claims

This record does not implement CORE-004. It does not claim ATK-06 green,
approval authenticity, a grant path, cross-instance pending state, real
restart durability, real human delivery, or live non-bypassability.
