---
id: DECI-0006
type: DECI
status: active
supersedes: []
superseded-by: null
owner: Founder
last-reviewed: 2026-07-24
resolves: FND-5
---
# DECI-0006 — Phase 1 enforcement architecture sequence

## Context

ADR-10, ADR-11, and ADR-12 required coordinated choices for the Phase 1
enforcement proof.

## Decision

### ADR-12 — Rust now

The core is Rust per ADR-7. PR #2's TypeScript core is a throwaway spike, and
`CORE-001` through `CORE-005` are authored in Rust.

The goal is the fastest path to a green bypass suite. The re-runnable suite is
the durable asset that makes future change safe. Rust ramp must not stall the
enforcement proof. If it does, the fallback is TS-now/Rust-later with the suite
as the migration guarantee; that fallback is **not chosen**.

### ADR-10 — Short-lived Ed25519 capability token

Use the existing T0 capability token for agent-to-gate authentication at the
OSS/developer tier. This tier is honestly scoped as **agent-non-bypassable,
operator-bypassable**. Mutual TLS or an identity layer such as Okta for AI
Agents is the named Phase 3 operator-proof upgrade; it is referenced, not built.

### ADR-11 — Native runtime check

Use OpenClaw `before_tool_call` as the enforcement point now, as tested by
`CORE-002`. Sequence a verifier wrapper/SDK for the second adapter in Phase 2,
then a gateway/proxy for Phase 3 operator-proof enforcement. Those upgrades are
referenced, not built.

## Affected artifacts

- ADR-10, ADR-11, and ADR-12
- `strategy/DGR-program-status.md`
- `dgr-backlog` items `CORE-001` through `CORE-005` and `FND-5`
