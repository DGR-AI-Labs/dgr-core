---
id: CORE-004-DESIGN-ADDENDUM-A
type: DECI
status: active
supersedes: []
superseded-by: null
owner: Founder
last-reviewed: 2026-08-19
relates-to:
  - CORE-004-DESIGN
  - CORE-004
  - VAL-004
  - SPEC-CORE-001-ATTACK-SET
---

# CORE-004-DESIGN — Addendum A

**Purpose.** Close the fixture-observable contract gaps found while scoping
`VAL-004`, so fixture and test authors have a complete, frozen target. This
addendum amends `CORE-004-DESIGN` (§2, §3, §7) and is binding on `VAL-004`,
`CORE-004-T3-tests`, and the founder-authored `CORE-004-T0-*` units.

## A1. Pre-deadline observation on the timeout-evaluation path (amends §2, §3)

The R-3 timeout-evaluation path returns, for an existing pending record:

- **`now <= deadline`** → `Escalated { review_request_id, deadline }` — the
  **same** id and the **same** deadline as the original escalation. This is the
  same state, re-observed; no new observation variant is introduced.
- **`now > deadline`** → `Blocked { outcome:
  RequiredOutcome::EscalateThenDenyOnTimeout, authorization_issued: false,
  effectful_invocations: 0 }`.

Neither path issues authorization or invokes the effectful probe.
Re-observation never mutates or extends the pending record (deadline
immutability per §5).

**Boundary fixtures required by VAL-004:** `deadline - 1` → `Escalated`;
`deadline` → `Escalated`; `deadline + 1` →
`Blocked { EscalateThenDenyOnTimeout }`. These pin the frozen inequality
`timed out iff now > deadline`.

## A2. Escalation trigger — T-2, threshold on a bound field (amends §2)

### Binding rule

An escalation predicate over **agent-supplied action data** MUST depend only on
hash-committed fields, and only after the guard has verified the action binding
and the field's canonical form. An unbound, agent-mutable field must never be
able to activate **or suppress** escalation.

The six ARCH-005 bound fields (`action`, `amount`, `currency`, `destination`,
`invoice_id`, and `source_account`) are committed in the token. Altering any of
them fails the binding check and denies. The non-bound fields
(`idempotency_key` and `memo`) are freely mutable by the agent with no binding
consequence, as demonstrated by the `change-idempotency-key` and `change-memo`
fixtures. A predicate over one of those non-bound fields would therefore not
be an enforcement control.

A future predicate may also depend on trusted guard-derived or independently
verified evidence facts only under a separately frozen provenance and binding
contract. This addendum does not define or authorize such an evidence model.

### CORE-004 trigger

Escalation is required when the **bound `amount`** exceeds a founder-owned
threshold:

- Constant: `APPROVAL_REQUIRED_ABOVE_MINOR_UNITS = 1_000_000` minor units
  (`$10,000.00` for a two-decimal currency).
- Comparison: escalate iff the mathematical integer represented by `amount`
  is greater than `APPROVAL_REQUIRED_ABOVE_MINOR_UNITS`. At or below the
  threshold, no escalation is required and the decision proceeds normally.
- The value is a private founder constant in the T0 unit with a
  `#[doc(hidden)] pub CONFORMANCE_*` mirror. Fixtures may assert equality but
  cannot change what the guard enforces. This follows the established
  `MAXIMUM_LIFETIME_SECONDS`, `EXPIRY_SKEW_SECONDS`, and
  `APPROVAL_WINDOW_SECONDS` pattern.
- Before comparison, the guard rejects any `amount` that is not the canonical
  positive ASCII integer-minor-units form required by ARCH-005. A valid token
  signature or a matching commitment over malformed bytes does not make a
  malformed amount valid. Decimal points, signs, separators, leading zeroes,
  zero, empty values, and non-ASCII digits deny before escalation.
- Numeric comparison must not wrap, panic, silently coerce, or turn a
  representation failure into Allow. An otherwise canonical integer larger
  than the implementation's machine integer range is mathematically above the
  threshold and therefore escalates; an overflow-free decimal comparison is
  acceptable.

### Regression constraint

The threshold is above the VAL-002 baseline amount (`100000`), so every
currently green CORE-002 fixture (`valid`, `expired-within-skew`,
`change-idempotency-key`, `change-memo`, `replay`, and the binding-swap cases)
continues to behave exactly as it does today and does not begin escalating.
VAL-004 introduces a new above-threshold scenario. Any future threshold change
must re-verify the existing suite.

## A3. Placement in the decision sequence and nonce rule (amends §2)

The founder-authored order becomes:

```text
signature → lifetime/expiry → binding + canonical validation → ESCALATION CHECK → consume → allow
```

- **After binding and canonical validation:** only a verified, canonical,
  committed amount may drive escalation.
- **Before consume:** escalation does not spend the single-use nonce.

**Escalation MUST NOT consume the nonce.** Burning a token for an action that
was never authorized would deny a legitimate retry, and the future 6-B
approve→allow path could not execute if the token had already been consumed.
On re-presentation the store returns `AlreadyPending` with the original
`review_request_id` and original deadline. This prevents an agent from
resetting the clock while the nonce remains unconsumed.

## A4. Recorded deferrals

- **T-1 — token-declared escalation flag.** Rejected for CORE-004. ARCH-006's
  wire format is frozen at 145 bytes with no such field, so this requires a
  format-version-v2 token, a new preimage, and re-minted fixtures. It also
  relocates the decision to the issuer, whereas the gate decides.
- **T-4 / general policy-driven escalation.** Deferred. Declarative policy
  over the action and verified evidence is the eventual shape; CORE-004
  deliberately implements one founder-owned threshold rather than a policy
  engine.
- **ATK-05 coupling.** The CORE-001 registry assigns ATK-05 (evidence
  conflicts, is stale, or cannot be verified) the same required outcome as
  ATK-06: `EscalateThenDenyOnTimeout`. ATK-05 is a cause of escalation and
  ATK-06 is the timeout of an escalation. When ATK-05 is implemented it must
  reuse this escalation path, port, store, and observation contract rather
  than introduce a parallel mechanism. Its evidence predicate requires its
  own founder-approved provenance/binding contract; unbound agent-supplied
  evidence cannot activate or suppress escalation. Evidence modeling remains
  unbuilt and out of scope here.

## A5. Non-claims

This addendum does not implement or authorize implementation of CORE-004 code.
It does not claim ATK-06 green or introduce an approve→allow grant path. 6-A
remains in force; 6-B remains a future extension requiring its own
approval-authenticity design. Exact Rust signatures, pending-record correlation
keys, review-request-id construction, concurrency behavior, and SQLite schema
remain founder-authored T0 choices that must preserve the observable contract
above and the original design's persist-then-observe rule.
