#!/usr/bin/env python3
"""Build a deterministic, traceable top-priorities report from pm/items.json."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
from pathlib import Path

from epic_status import materialize_epic_statuses


ROOT = Path(__file__).resolve().parent.parent
ITEMS_PATH = ROOT / "pm/items.json"
REFERENCE_PATH = ROOT / "reference/reference-index.lock.json"
OUTPUT_PATH = ROOT / "pm/TOP-PRIORITIES.md"
DEFAULT_PROGRAM_STATUS = ROOT.parent / "dgr-internal/strategy/DGR-program-status.md"
TOKEN = "{FOUNDER-SUPPLY:"
PRIORITY = re.compile(r"^P([0-3])(?:\b| )")
FND_ID = re.compile(r"\bFND-\d+\b")
T0 = re.compile(r"\bT0\b")
PHASE = re.compile(r"current program phase is \*\*(Phase \d+)\b", re.IGNORECASE)
REQUIRED_FIELDS = {
    "id",
    "title",
    "type",
    "epic",
    "priority",
    "size",
    "owner-role",
    "status",
    "prerequisites",
    "context",
    "acceptance-criteria",
    "definition-of-done",
    "human-gate",
    "dependencies",
    "links",
    "tags",
}


def load_json(path: Path) -> object:
    return json.loads(path.read_text(encoding="utf-8"))


def natural_id(value: str) -> tuple[object, ...]:
    return tuple(int(part) if part.isdigit() else part for part in re.split(r"(\d+)", value))


def size_rank(value: object) -> int:
    prefix = str(value).strip()[:1].upper()
    return {"S": 0, "M": 1, "L": 2}.get(prefix, 99)


def priority_rank(value: object) -> int | None:
    match = PRIORITY.match(str(value))
    return int(match.group(1)) if match else None


def contains_token(value: object) -> bool:
    if isinstance(value, dict):
        return any(contains_token(part) for part in value.values())
    if isinstance(value, list):
        return any(contains_token(part) for part in value)
    return TOKEN in str(value)


def markdown(value: object) -> str:
    return str(value).replace("|", "\\|").replace("\n", " ")


def code(value: object) -> str:
    return f"`{str(value).replace('`', '')}`"


def heading_anchor(item: dict[str, object]) -> str:
    heading = f"{item['id']} — {item['title']}".lower()
    return re.sub(r"[^a-z0-9 -]", "", heading).replace(" ", "-").strip("-")


def decision_link(item: dict[str, object]) -> str:
    return f"[{item['id']}](FOUNDER-DECISIONS.md#{heading_anchor(item)})"


def joined_codes(values: list[str]) -> str:
    return ", ".join(code(value) for value in values) if values else "none"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--program-status",
        type=Path,
        default=DEFAULT_PROGRAM_STATUS,
        help="Program-status source used only to confirm the active phase.",
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help="Fail if pm/TOP-PRIORITIES.md is not the current generated output.",
    )
    args = parser.parse_args()

    stored_items = load_json(ITEMS_PATH)
    references = load_json(REFERENCE_PATH)
    if not isinstance(stored_items, list) or not isinstance(references, list):
        raise ValueError("items and reference lock must both be JSON arrays")

    for raw_item in stored_items:
        if not isinstance(raw_item, dict):
            raise ValueError("every item must be an object")
        item = raw_item
        if set(item) != REQUIRED_FIELDS:
            raise ValueError(f"{item.get('id', '<missing id>')}: unexpected field set")

    items = materialize_epic_statuses(stored_items)
    by_id: dict[str, dict[str, object]] = {}
    for item in items:
        item_id = str(item["id"])
        if item_id in by_id:
            raise ValueError(f"duplicate item id: {item_id}")
        by_id[item_id] = item

    reference_by_id = {str(entry["id"]): entry for entry in references}
    for item in items:
        item_id = str(item["id"])
        for dependency in item["dependencies"]:
            if dependency not in by_id:
                raise ValueError(f"{item_id}: missing dependency {dependency}")
        for prerequisite in item["prerequisites"]:
            if prerequisite not in reference_by_id:
                raise ValueError(f"{item_id}: missing prerequisite reference {prerequisite}")
            if reference_by_id[prerequisite].get("status") == "superseded":
                raise ValueError(f"{item_id}: superseded prerequisite reference {prerequisite}")

    program_status_path = args.program_status.resolve()
    if not program_status_path.is_file():
        raise ValueError(f"program status not found: {program_status_path}")
    program_status = program_status_path.read_text(encoding="utf-8")
    phase_match = PHASE.search(program_status)
    if not phase_match:
        raise ValueError(f"active phase not found in {program_status_path}")
    active_phase = phase_match.group(1)

    epic_core = by_id.get("EPIC-CORE")
    if epic_core is None:
        raise ValueError("EPIC-CORE is required to derive the bypass-suite gate")
    if "bypass suite is green" not in str(epic_core["definition-of-done"]).lower():
        raise ValueError("EPIC-CORE does not define a green bypass-suite gate")
    gate_epic = str(epic_core["epic"])
    gate_items = [
        item
        for item in items
        if item["type"] != "Epic" and str(item["epic"]) == gate_epic
    ]
    if not gate_items:
        raise ValueError("no leaf items found for the bypass-suite gate")

    open_fnd = {
        item_id
        for item_id, item in by_id.items()
        if item_id.startswith("FND-") and item["status"] != "Done"
    }

    def dependency_blockers(item: dict[str, object]) -> list[str]:
        return [
            dependency
            for dependency in item["dependencies"]
            if by_id[dependency]["status"] != "Done"
        ]

    def gate_blockers(item: dict[str, object]) -> list[str]:
        return sorted(
            set(FND_ID.findall(str(item["human-gate"]))) & open_fnd,
            key=natural_id,
        )

    def touches_t0(item: dict[str, object]) -> bool:
        fields = [
            item["title"],
            item["context"],
            item["definition-of-done"],
            *item["acceptance-criteria"],
        ]
        return any(T0.search(str(value)) for value in fields)

    def well_specified(item: dict[str, object]) -> bool:
        return bool(item["acceptance-criteria"]) and bool(item["definition-of-done"]) and not (
            contains_token(item["acceptance-criteria"])
            or contains_token(item["definition-of-done"])
        )

    def startable(item: dict[str, object]) -> bool:
        return (
            item["status"] == "To Do"
            and not contains_token(item["status"])
            and not dependency_blockers(item)
            and not gate_blockers(item)
        )

    def delegability(item: dict[str, object]) -> str:
        human_gate = str(item["human-gate"])
        if item["type"] == "Epic":
            return "no: derived Epic rollup"
        if item["status"] == "Done":
            return "no: Done"
        if touches_t0(item):
            return "founder-led: T0"
        if human_gate != "None":
            return f"founder-led: human-gate={human_gate}"
        if not well_specified(item):
            return "no: acceptance/DoD incomplete"
        return "yes"

    def startable_label(item: dict[str, object]) -> str:
        if item["type"] == "Epic":
            return f"no: derived {item['status']} rollup"
        blockers = dependency_blockers(item) + gate_blockers(item)
        if startable(item):
            return "yes"
        if item["status"] == "Done":
            return "no: Done"
        if contains_token(item["status"]):
            return "unknown: status token"
        if blockers:
            return "blocked by " + ", ".join(blockers)
        return f"no: status={item['status']}"

    rankable_gate_items = []
    for item in gate_items:
        if priority_rank(item["priority"]) is None:
            raise ValueError(f"{item['id']}: gate item lacks a P0-P3 priority")
        if contains_token(
            {
                field: item[field]
                for field in ("priority", "status", "dependencies", "size", "human-gate")
            }
        ):
            raise ValueError(f"{item['id']}: gate item has an unresolved ranking token")
        rankable_gate_items.append(item)

    ranked = sorted(
        rankable_gate_items,
        key=lambda item: (
            priority_rank(item["priority"]),
            2 if item["status"] == "Done" else 0,
            0 if not dependency_blockers(item) else 1,
            len(dependency_blockers(item)),
            size_rank(item["size"]),
            natural_id(str(item["id"])),
        ),
    )

    rankable_workstream_epics = [
        item
        for item in items
        if item not in gate_items
        and item["type"] == "Epic"
        and str(item["id"]) not in {"EPIC-FND", "EPIC-BKO"}
        and priority_rank(item["priority"]) is not None
        and not contains_token(
            {
                field: item[field]
                for field in ("priority", "status", "dependencies", "size", "human-gate")
            }
        )
    ]
    if rankable_workstream_epics:
        ranked.extend(
            sorted(
                rankable_workstream_epics,
                key=lambda item: (
                    priority_rank(item["priority"]),
                    size_rank(item["size"]),
                    natural_id(str(item["id"])),
                ),
            )
        )

    ranked = ranked[:10]
    ranked_ids = {str(item["id"]) for item in ranked}
    if any(item_id not in by_id for item_id in ranked_ids):
        raise AssertionError("ranked output contains an unknown item")

    startable_items = [
        item for item in items if item["type"] != "Epic" and startable(item)
    ]
    startable_items.sort(
        key=lambda item: (
            0 if item in gate_items else 1,
            size_rank(item["size"]),
            natural_id(str(item["id"])),
        )
    )
    agent_startable = [
        item for item in startable_items if delegability(item) == "yes"
    ]
    founder_startable = [
        item for item in startable_items if delegability(item).startswith("founder-led:")
    ]
    incomplete_startable = [
        item
        for item in startable_items
        if item not in agent_startable and item not in founder_startable
    ]
    if incomplete_startable:
        raise ValueError(
            "startable items do not fit the requested delegation categories: "
            + ", ".join(str(item["id"]) for item in incomplete_startable)
        )

    blocked_on_founder = [
        item
        for item in items
        if item["type"] != "Epic"
        and item["status"] != "Deferred"
        and not str(item["id"]).startswith("FND-")
        and gate_blockers(item)
    ]
    blocked_on_founder.sort(key=lambda item: natural_id(str(item["id"])))

    unranked_priority = [
        item
        for item in items
        if item["type"] != "Epic"
        and item["status"] != "Deferred"
        and item not in gate_items
        and priority_rank(item["priority"]) is None
        and not contains_token(item["priority"])
    ]
    token_items = [
        item
        for item in items
        if item["status"] != "Deferred"
        and contains_token(
            {
                field: item[field]
                for field in (
                    "priority",
                    "status",
                    "size",
                    "owner-role",
                    "human-gate",
                    "definition-of-done",
                )
            }
        )
    ]

    items_sha = hashlib.sha256(ITEMS_PATH.read_bytes()).hexdigest()
    status_sha = hashlib.sha256(program_status.encode("utf-8")).hexdigest()
    try:
        status_display = program_status_path.relative_to(ROOT).as_posix()
    except ValueError:
        status_display = Path("..") / program_status_path.relative_to(ROOT.parent)
        status_display = status_display.as_posix()

    lines = [
        "# Top priorities",
        "",
        "> Generated by `python3 pm/build_top_priorities.py`; do not hand-edit.",
        "",
        "## Decision read",
        "",
        f"The active phase is **{active_phase}**. The phase-gate source says the bypass suite "
        "is not green and is the first technical proof point; `EPIC-CORE.definition-of-done` "
        "defines green as all child items Done with the suite green inline and permanently "
        "wired into CI.",
        "",
        f"**{len(ranked)} items** can be placed in a deterministic top-priority order: "
        "the active P0 bypass-suite items first, followed by the highest-priority "
        "DECI-resolved workstream Epic rollups. Leaf tasks outside the bypass path remain "
        "`Unranked`; no Epic priority is inherited by a child.",
        "Deferred / Backlog items are intentionally excluded from ranking, readiness, and "
        "open-token sections until their activation trigger is satisfied.",
        "",
        "## Ranked top priorities",
        "",
        "| Rank | ID | Title | Type | Epic | Priority | Size | Owner-role | Status | Startable now? | Agent-delegable? | Rank rationale |",
        "|---:|---|---|---|---|---|---|---|---|---|---|---|",
    ]
    for rank, item in enumerate(ranked, 1):
        if item["type"] == "Epic":
            rationale = (
                f"workstream rollup: priority={item['priority']}; "
                f"derived status={item['status']}; size={item['size']}"
            )
        else:
            blockers = dependency_blockers(item)
            dependency_reason = (
                "no unmet dependencies"
                if not blockers
                else f"unmet dependencies={','.join(blockers)}"
            )
            rationale = (
                f"phase gate: epic={item['epic']}; priority={item['priority']}; "
                f"status={item['status']}; {dependency_reason}; size={item['size']}"
            )
        lines.append(
            "| "
            + " | ".join(
                [
                    str(rank),
                    code(item["id"]),
                    markdown(item["title"]),
                    markdown(item["type"]),
                    markdown(item["epic"]),
                    markdown(item["priority"]),
                    markdown(item["size"]),
                    markdown(item["owner-role"]),
                    markdown(item["status"]),
                    markdown(startable_label(item)),
                    markdown(delegability(item)),
                    markdown(rationale),
                ]
            )
            + " |"
        )

    lines.extend(
        [
            "",
            "The actionable bypass-suite child chain is kept first. Remaining rows follow "
            "the requested item `priority` and smaller `size`; stable item ID is used only "
            "when all requested fields tie. Epic rows show planning rollups and are not "
            "delegable work items.",
            "",
            "## Critical path to the Phase 1 gate",
            "",
            "The dependency graph in `items.json` is a fork/join, not a single linear chain:",
            "",
            "1. `CORE-001` — Done; the attack contract is published and pinned.",
            "2. `CORE-003-T3-tests` — in review on dgr-core PR #72; its typed-fault and panic cases remain deliberately RED when invoked directly.",
            "3. `CORE-003-T0-boundary` — blocked on the T3 review/merge, then founder-authored; `CORE-003` stays In Progress until both children finish.",
            "4. `CORE-002` — Steps 1–5 are Done while its separate parent completion boundary remains In Progress; `CORE-004` is the startable approval-timeout test.",
            "5. `CORE-005` — blocked by `CORE-002`, `CORE-003`, and `CORE-004`; wires the green suite into permanent CI.",
            "",
            "**Current next actions: review dgr-core PR #72, then founder-author `CORE-003-T0-boundary`; start `CORE-004`; and complete the separate `CORE-002` parent boundary.**",
            "",
            "| Item | Current blockers |",
            "|---|---|",
        ]
    )
    for item in sorted(gate_items, key=lambda value: natural_id(str(value["id"]))):
        blockers = dependency_blockers(item) + gate_blockers(item)
        if item["status"] == "Done":
            blocker_text = "none — Done"
        elif blockers:
            blocker_text = joined_codes(blockers)
        elif item["status"] == "To Do":
            blocker_text = "none — startable now"
        else:
            blocker_text = f"none — status={item['status']}"
        lines.append(
            f"| {code(item['id'])} | {blocker_text} |"
        )

    lines.extend(
        [
            "",
            "## Startable-now set",
            "",
            "Schema note: `prerequisites` in this repository are pinned reference IDs, not "
            "work items, and their statuses are `active`/`superseded` rather than "
            "`Done`/`To Do`. This report therefore treats an existing, non-superseded "
            "reference as available and determines item readiness from `status`, item "
            "`dependencies`, and open `FND-*` values in `human-gate`.",
            "",
            "| ID | Title | Size | Human gate | Delegation |",
            "|---|---|---|---|---|",
        ]
    )
    for item in startable_items:
        lines.append(
            "| "
            + " | ".join(
                [
                    code(item["id"]),
                    markdown(item["title"]),
                    markdown(item["size"]),
                    markdown(item["human-gate"]),
                    markdown(delegability(item)),
                ]
            )
            + " |"
        )

    lines.extend(
        [
            "",
            "## Parallelizability read",
            "",
            f"**Startable now: {len(startable_items)} total — "
            f"{len(agent_startable)} agent-delegable and "
            f"{len(founder_startable)} founder-led.**",
            "",
            "Agent-delegable means no T0 mention, `human-gate=None`, and non-empty "
            "acceptance criteria plus a non-token Definition of Done. Founder-led includes "
            "the founder-decision items themselves and any item that carries a human gate, "
            "even when the referenced decision is already Done.",
            "",
            f"**Agentic-team input:** there are **{len(agent_startable)} parallelizable, "
            "agent-safe items now**: "
            + joined_codes([str(item["id"]) for item in agent_startable])
            + ".",
            "",
            "This count supports focused parallel work; `CORE-004` advances the current "
            "bypass-suite path while `CORE-003-T3-tests` is already in review and the "
            "founder-owned `CORE-003-T0-boundary` remains gated behind it. The count is an "
            "input to the founder's staffing decision; it is not an automatic recommendation "
            "to stand up a fleet.",
            "",
            "## Blocked on founder",
            "",
            "| Item | Open founder decision(s) |",
            "|---|---|",
        ]
    )
    for item in blocked_on_founder:
        links = ", ".join(decision_link(by_id[fnd]) for fnd in gate_blockers(item))
        lines.append(f"| {code(item['id'])} — {markdown(item['title'])} | {links} |")
    if not blocked_on_founder:
        lines.append("| None | None |")

    lines.extend(
        [
            "",
            "## Cannot rank without fabrication",
            "",
            "The following leaf items have `priority=Unranked`; no epic priority is inherited "
            "because `items.json` does not define inheritance:",
            "",
            joined_codes([str(item["id"]) for item in sorted(unranked_priority, key=lambda value: natural_id(str(value["id"])))]),
            "",
            "The following items contain `{FOUNDER-SUPPLY}` in a field used for ranking, "
            "readiness, delegation, or finish-line assessment:",
            "",
            "| Item | Token-bearing field(s) | Existing FND mapping |",
            "|---|---|---|",
        ]
    )
    for item in sorted(token_items, key=lambda value: natural_id(str(value["id"]))):
        token_fields = [
            field
            for field in (
                "priority",
                "status",
                "size",
                "owner-role",
                "human-gate",
                "definition-of-done",
            )
            if contains_token(item[field])
        ]
        mapped_fnds = sorted(set(FND_ID.findall(str(item["human-gate"]))), key=natural_id)
        mapping = (
            ", ".join(
                f"{decision_link(by_id[fnd])} ({by_id[fnd]['status']})"
                for fnd in mapped_fnds
                if fnd in by_id
            )
            if mapped_fnds
            else "none in `items.json`"
        )
        lines.append(
            f"| {code(item['id'])} | {joined_codes(token_fields)} | {mapping} |"
        )

    lines.extend(
        [
            "",
            "The eight DECI-resolved workstream Epics no longer carry ranking or status "
            "tokens; their stored status is `derived` and the displayed value is computed "
            "from children. `EPIC-FND`, `EPIC-BKO`, and `BKO-001..005` retain only fields "
            "for which no completed decision supplies a value.",
            "",
            "## Trace and validation",
            "",
            f"- Ranking source: `pm/items.json` (SHA-256 `{items_sha}`).",
            f"- Phase source: `{status_display}` (SHA-256 `{status_sha}`).",
            f"- Active phase parsed from the phase source: `{active_phase}`.",
            f"- Ranked IDs asserted present in `items.json`: {joined_codes([str(item['id']) for item in ranked])}.",
            "- Every dependency ID is asserted to exist in `items.json`.",
            "- Every prerequisite ID is asserted to exist and be non-superseded in "
            "`reference/reference-index.lock.json`.",
            "- Every rank rationale is rendered from `epic`, `priority`, `status`, "
            "`dependencies`, and `size`; no priority or Definition of Done is inherited.",
            "- Epic statuses are materialized from child state by `pm/epic_status.py`; "
            "`items.json` stores only the `derived` marker.",
            "- Reproduce with `python3 pm/build_top_priorities.py`; validate a clean "
            "generated result with `python3 pm/build_top_priorities.py --check`.",
            "",
            "## Founder review gate",
            "",
            "Confirm the ordering and the `CORE-001 (Done) → CORE-003-T3-tests → "
            "CORE-003-T0-boundary → CORE-003`, alongside `{CORE-002, CORE-004}`, then "
            "the join at `CORE-005` critical path, including the founder-only ATK-07 floor, "
            f"then use the {len(agent_startable)}-to-"
            f"{len(founder_startable)} agent/founder split above to "
            "decide whether an agentic fleet is warranted. Nothing merges without founder "
            "approval.",
            "",
        ]
    )

    rendered = "\n".join(lines)
    if args.check:
        if not OUTPUT_PATH.is_file() or OUTPUT_PATH.read_text(encoding="utf-8") != rendered:
            print(
                "pm/TOP-PRIORITIES.md is stale; run "
                "`python3 pm/build_top_priorities.py`",
                file=sys.stderr,
            )
            return 1
        print("pm/TOP-PRIORITIES.md is current")
        return 0

    OUTPUT_PATH.write_text(rendered, encoding="utf-8")
    print(f"wrote {OUTPUT_PATH.relative_to(ROOT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
