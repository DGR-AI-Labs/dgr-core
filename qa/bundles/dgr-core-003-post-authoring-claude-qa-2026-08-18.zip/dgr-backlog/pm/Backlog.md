# DGR Delivery Backlog

<a id="epic-str"></a>
## EPIC-STR — Strategy & GTM

- **Type:** Epic
- **Epic:** Strategy & GTM
- **Priority:** P3
- **Size:** L — child items must be S/M
- **Owner-role:** Sales / Product
- **Status:** Blocked
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and Phase 1 adoption evidence and GTM materials are ready for founder advance-gate review.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="epic-arch"></a>
## EPIC-ARCH — Architecture & Specs

- **Type:** Epic
- **Epic:** Architecture & Specs
- **Priority:** P1
- **Size:** L — child items must be S/M
- **Owner-role:** Engineering
- **Status:** Blocked
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and the active Phase 1 ADR set supports the Rust enforcement proof without an unresolved architecture contradiction.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="epic-cfn"></a>
## EPIC-CFN — Cloud Foundation

- **Type:** Epic
- **Epic:** Cloud Foundation
- **Priority:** P3
- **Size:** L — child items must be S/M
- **Owner-role:** Engineering
- **Status:** In Progress
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and the Phase 1 dev-local and audit boundary is evidenced, with remaining foundation scope explicitly deferred to Phase 3.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="epic-core"></a>
## EPIC-CORE — Core Enforcement + Bypass Suite

- **Type:** Epic
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0
- **Size:** L — child items must be S/M
- **Owner-role:** Engineering
- **Status:** In Progress
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and the bypass suite is green inline and wired as a permanent CI gate.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="epic-pol"></a>
## EPIC-POL — Policy Plane

- **Type:** Epic
- **Epic:** Policy Plane
- **Priority:** P2
- **Size:** L — child items must be S/M
- **Owner-role:** Product (with Engineering)
- **Status:** Blocked
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and the Cedar policy/evidence contract supports the founder-selected Phase 1 demo.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="epic-val"></a>
## EPIC-VAL — Validation & QA Gates

- **Type:** Epic
- **Epic:** Validation & QA Gates
- **Priority:** P1
- **Size:** L — child items must be S/M
- **Owner-role:** Engineering
- **Status:** Blocked
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and the bypass suite plus required deterministic validation checks are enforced as green CI gates.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="epic-res"></a>
## EPIC-RES — Research & Credibility

- **Type:** Epic
- **Epic:** Research & Credibility
- **Priority:** P3
- **Size:** L — child items must be S/M
- **Owner-role:** Product
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and Phase 1 research claims are linked to primary evidence with the citation-remediation plan active.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="epic-tool"></a>
## EPIC-TOOL — Developer Tooling

- **Type:** Epic
- **Epic:** Developer Tooling
- **Priority:** P2
- **Size:** L — child items must be S/M
- **Owner-role:** Engineering
- **Status:** In Progress
- **Tags:** None
- **Prerequisites:** DECI-0004, DECI-0005
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** All child items are Done and the Phase 1 developer workflow can rebuild, test, and operate the Rust enforcement proof.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0004, DECI-0005

<a id="str-001"></a>
## STR-001 — Draft phase and open-core options memo

- **Type:** Task
- **Epic:** Strategy & GTM
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Product manager
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR, DECI-0001
- **Context:** Give the founder bounded options for phase sequence and the open-core paid boundary without deciding them.
- **Acceptance criteria:**
  - [ ] At least two options per decision are stated.
  - [ ] Evidence, tradeoffs, and reversible next steps are separated.
  - [ ] FND-1 and FND-8 are linked as human gates.
- **Definition of Done:** Memo is reviewable, linked to FND-1/FND-8, and `make verify` is green.
- **Human gate:** FND-1 and FND-8
- **Dependencies:** None
- **Links:** GLOSSARY-DGR, DECI-0001

<a id="str-002"></a>
## STR-002 — Draft trigger-qualified discovery guide

- **Type:** Task
- **Epic:** Strategy & GTM
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Sales / Business development
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR, SPEC-POLICY-PLANE
- **Context:** Translate the existing buyer and policy-plane evidence into a repeatable discovery conversation.
- **Acceptance criteria:**
  - [ ] Guide distinguishes trigger, pain, current workaround, and required proof.
  - [ ] Questions do not promise unproven enforcement.
  - [ ] Beachhead confirmation remains a founder gate.
- **Definition of Done:** A reviewer can run a mock discovery call from the guide and `make verify` is green.
- **Human gate:** FND-6 and FND-8
- **Dependencies:** None
- **Links:** GLOSSARY-DGR, SPEC-POLICY-PLANE

<a id="arch-001"></a>
## ARCH-001 — Author ADR-8 source/artifact-integrity stub

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** ADR-7, DECI-0001
- **Context:** The fact pack describes ADR-8 but no authoritative source is cataloged.
- **Acceptance criteria:**
  - [ ] Context, options, tradeoffs, and required evidence are documented.
  - [ ] Decision remains `{FOUNDER-SUPPLY}`.
  - [ ] No T0 implementation is authored.
- **Definition of Done:** Decision-open ADR stub passes reference validation and `make verify`.
- **Human gate:** FND-11
- **Dependencies:** None
- **Links:** ADR-7, DECI-0001

<a id="arch-002"></a>
## ARCH-002 — Author tenant-provisioning runbook stub

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** ADR-6, HOWTO-FOUNDATION
- **Context:** The intended tenant runbook route is missing.
- **Acceptance criteria:**
  - [ ] Phases, prerequisites, human deploy gates, rollback, and validation slots are structured.
  - [ ] No live account state or deployment outcome is asserted.
  - [ ] Unknown source decisions link to FND-11.
- **Definition of Done:** Runbook stub is reference-valid, reviewable, and `make verify` is green.
- **Human gate:** FND-11
- **Dependencies:** None
- **Links:** ADR-6, HOWTO-FOUNDATION

<a id="arch-003"></a>
## ARCH-003 — Record the CORE-002 guard authoring package

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** The settled CORE-002 design, review checklist, and founder authoring sequence are published and pinned by stable reference ID; this documentation authored no T0 enforcement logic.
- **Acceptance criteria:**
  - [ ] Class C, Option 2, B4-S2, K2, and T2 are recorded consistently.
  - [ ] The 300-second lifetime and 30-second skew tolerance are explicit.
  - [ ] The five founder-authored units and review-only agent boundary are documented.
- **Definition of Done:** The active reference catalog and backlog lock contain the complete CORE-002 design, review, and authoring package with no unresolved design token.
- **Human gate:** None
- **Dependencies:** None
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/f9e1801a499ec36df1a5e937c230c5438c77a603?region=us-west-2

<a id="arch-004"></a>
## ARCH-004 — Reconcile and publish the CORE-002 scaffold

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** SPEC-CORE-001-ATTACK-SET, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** The clean Rust scaffold was merged by founder review in dgr-core PR #58. PR #2's TypeScript T0 draft is not in its ancestry; the five founder units remain fail-closed stubs.
- **Acceptance criteria:**
  - [ ] The FND-14 disposition is applied to the Rust and TypeScript surfaces without preserving conflicting enforcement paths.
  - [ ] The five founder-authored units are distinct from harness and fixture files and are listed in T0-AUTHORS.md.
  - [ ] The scaffold is pushed and reviewed through the repository's normal PR and human-merge path.
  - [ ] The Rust crate builds and ATK-01 remains actively red until the founder authors the guard.
- **Definition of Done:** A reviewed scaffold is merged to current dgr-core main, the five-unit T0 boundary matches the settled design, and no agent-authored enforcement logic is present.
- **Human gate:** Completed by founder merge
- **Dependencies:** CORE-001, ARCH-003
- **Links:** SPEC-CORE-001-ATTACK-SET, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/58, https://github.com/DGR-AI-Labs/dgr-core/commit/a68befb601505410193584622ae036f56aff686a

<a id="arch-005"></a>
## ARCH-005 — Specify the first typed authorization schema and canonical form

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, ARCH-005-typed-authorization-schema
- **Context:** The founder-approved schema is merged on dgr-internal main, cataloged as active, and published by the reference pipeline.
- **Acceptance criteria:**
  - [ ] The first conformance tool and every authorization-relevant request field are identified with explicit types.
  - [ ] Money is a decimal string, identifiers have one normalization rule, and no bound field is a float.
  - [ ] A deterministic canonical byte form is specified so independent implementations produce the same commitment.
  - [ ] The guard recomputes from the actual request; no client-supplied hash or excluded field can influence authorization.
- **Definition of Done:** A founder-approved typed schema and canonical byte form are reviewable, fixture-ready, and sufficient for ATK-08/09/11 without authoring guard logic.
- **Human gate:** Completed by founder merge
- **Dependencies:** ARCH-004
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, ARCH-005-typed-authorization-schema, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/pull-requests/1/details?region=us-west-2, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/a563f388bca240ab94ddbf491582e58ac96f988f?region=us-west-2

<a id="arch-006"></a>
## ARCH-006 — Publish the capability-token wire format and signature preimage

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, ARCH-006-token-wire-format
- **Context:** The founder-approved wire-format specification is merged on dgr-internal main, cataloged as active, and published by the reference pipeline.
- **Acceptance criteria:**
  - [ ] The fixed binary token layout, domain tag, key identifier, nonce, and transport encoding are explicit.
  - [ ] Every decision-relevant field is included in the frozen Ed25519 preimage.
  - [ ] The active spec is cataloged without authoring verification or guard logic.
- **Definition of Done:** ARCH-006 is merged to dgr-internal main and remains cataloged as active for fixture and founder-guard consumers.
- **Human gate:** Completed by founder merge
- **Dependencies:** ARCH-004
- **Links:** ADR-10, DECI-0010, ARCH-006-token-wire-format, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/pull-requests/1/details?region=us-west-2, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/a563f388bca240ab94ddbf491582e58ac96f988f?region=us-west-2

<a id="arch-007"></a>
## ARCH-007 — Record the disposition of the obsolete TypeScript Phase 1 draft

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-12, DECI-0006
- **Context:** GitHub PR #2 was closed without merge after ADR-12 selected Rust as canonical and PR #58 reconstructed a clean Rust scaffold without the TypeScript T0 ancestry.
- **Acceptance criteria:**
  - [ ] The obsolete PR is closed without merge.
  - [ ] The canonical Rust decision and clean-scaffold replacement are linked.
  - [ ] No code from the obsolete T0 draft is promoted to main.
- **Definition of Done:** The obsolete draft is closed with a traceable disposition and the canonical replacement is merged.
- **Human gate:** None
- **Dependencies:** None
- **Links:** ADR-12, DECI-0006, https://github.com/DGR-AI-Labs/dgr-core/pull/2, https://github.com/DGR-AI-Labs/dgr-core/pull/58

<a id="cfn-001"></a>
## CFN-001 — Document current Foundation Part A state

- **Type:** Task
- **Epic:** Cloud Foundation
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Project manager
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** HOWTO-FOUNDATION
- **Context:** The prior two-thirds claim conflicts with the observed control inventory.
- **Acceptance criteria:**
  - [ ] Every HOWTO step is marked evidenced, not evidenced, or unknown.
  - [ ] No percentage is inferred.
  - [ ] The resulting decision request links to FND-2.
- **Definition of Done:** Evidence table is complete and ready for founder adjudication.
- **Human gate:** FND-2
- **Dependencies:** None
- **Links:** HOWTO-FOUNDATION

<a id="cfn-002"></a>
## CFN-002 — Prepare Deploy Step 3d checklist

- **Type:** Task
- **Epic:** Cloud Foundation
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** HOWTO-FOUNDATION, ADR-6, ADR-7
- **Context:** Founder deployment needs a bounded, reviewable preflight and rollback checklist.
- **Acceptance criteria:**
  - [ ] Identity, change scope, validation, rollback, and evidence capture are listed.
  - [ ] Checklist performs no AWS action.
  - [ ] Founder approval is explicit.
- **Definition of Done:** Checklist is dry-run reviewable and `make verify` is green.
- **Human gate:** FND-10
- **Dependencies:** None
- **Links:** HOWTO-FOUNDATION, ADR-6, ADR-7

<a id="cfn-003"></a>
## CFN-003 — Author the Cognito and Lambda@Edge private-site stack

- **Type:** Task
- **Epic:** Cloud Foundation
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0007, HOWTO-HOSTING-COGNITO-EDGE
- **Context:** The guarded Cognito, Lambda@Edge, origin, publication, and verification implementation is merged on dgr-internal main.
- **Acceptance criteria:**
  - [ ] The private-site infrastructure templates and edge-auth package are versioned.
  - [ ] The guarded publisher and offline verification path are versioned.
  - [ ] Deployment is not inferred from source implementation alone.
- **Definition of Done:** The private-site implementation and operator HOWTO are merged to dgr-internal main with reviewable QA evidence.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0007, HOWTO-HOSTING-COGNITO-EDGE, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/62626b9009a12809bf463f3263ff90d9f8daab0a?region=us-west-2

<a id="cfn-004"></a>
## CFN-004 — Confirm live deployment of the Cognito and Lambda@Edge private site

- **Type:** Task
- **Epic:** Cloud Foundation
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** unverified
- **Prerequisites:** DECI-0007, HOWTO-HOSTING-COGNITO-EDGE
- **Context:** Claimed in the local hosting deployment report and reconciliation request; no committed main-branch deployment receipt or merged PR was found. This claim is unverified and is not Done.
- **Acceptance criteria:**
  - [ ] A committed deployment receipt identifies the reviewed stack, region, deployment time, and validation outcome.
  - [ ] The evidence distinguishes source implementation from a live deployment.
  - [ ] The founder confirms any live AWS state before the status changes.
- **Definition of Done:** A founder-reviewed deployment receipt is merged and linked; until then the claim remains unverified.
- **Human gate:** Founder confirms live deployment evidence
- **Dependencies:** None
- **Links:** DECI-0007, HOWTO-HOSTING-COGNITO-EDGE

<a id="core-001"></a>
## CORE-001 — Define the bypass attack set

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** SRS-07, ADR-7, ADR-12, DECI-0006, DECI-0008, SPEC-CORE-001-ATTACK-SET
- **Context:** The Rust bypass attack contract for non-bypassability is published and reviewed. Operator-disable and hosted IAM execution remain explicitly scoped to their later gates.
- **Acceptance criteria:**
  - [ ] Direct tool call without token expects block.
  - [ ] Expired or replayed token expects deny.
  - [ ] Missing justification expects deny.
  - [ ] Ambiguous or insufficient evidence expects deny or escalation.
  - [ ] Approval timeout expects deny.
  - [ ] Hook throw expects deny.
- **Definition of Done:** The published attack matrix is reviewed, contains the expected outcomes, is pinned by stable ID, and its deterministic validation is green.
- **Human gate:** None
- **Dependencies:** None
- **Links:** SRS-07, ADR-7, ADR-12, DECI-0006, DECI-0008, SPEC-CORE-001-ATTACK-SET, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/7051fb34ee0ca783a4e4585f1cdca2bbe1f3b530?region=us-west-2, https://github.com/DGR-AI-Labs/dgr-core/pull/58

<a id="core-002"></a>
## CORE-002 — Author and prove the CORE-002 inline guard

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** M
- **Owner-role:** Founder
- **Status:** In Progress
- **Tags:** None
- **Prerequisites:** SRS-07, ADR-7, ADR-10, ADR-11, ADR-12, DECI-0006, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** Founder-authored Rust T0 work is progressing against the settled OpenClaw before_tool_call design. Steps 1–5 are founder-merged. Step 5 provides S2 durable-local atomic consumption, restart evidence against the same SQLite file, explicit fail-closed fault mapping, and ATK-03/13 coverage. Independent-human, cross-model, adversarial, and three-engine SAST/SCA review are complete, with founder analyzer dispositions recorded through dgr-core PR #70. The protected checklist truthfully records that PR #68 merged before final checklist sign-off; the founder formally accepted that post-merge remediation through the governance disposition in PR #71. Parent CORE-002 remains In Progress for its separate completion boundary.
- **Acceptance criteria:**
  - [ ] ATK-01 is green because an absent token denies before tool execution and every absence or internal error fails closed.
  - [ ] K2 key selection and Ed25519 verification make ATK-10 green; unknown key_id and client-supplied key material deny.
  - [ ] The guard enforces a 300-second lifetime with 30-second skew against its T2 clock and makes ATK-02 green.
  - [ ] The guard recomputes the typed per-tool request hash under the canonical rule and makes ATK-08, ATK-09, and ATK-11 green.
  - [ ] S2 atomically persists single-use consumption before Allow and makes ATK-03 green with record-before-allow ordering.
  - [ ] The full suite and line-mapped review checklist pass, and only the founder authored the five T0 units.
- **Definition of Done:** ATK-01/02/03/08/09/10/11 and the applicable fail-closed regression pass against the founder-authored guard; cases deferred to later controls remain explicitly classified; and the checklist has reviewer-approved file-and-line evidence.
- **Human gate:** FND-13, FND-14, and FND-15; Founder authors and reviews the five T0 units
- **Dependencies:** CORE-001, ARCH-004, ARCH-005, ARCH-006, TOOL-002, VAL-002
- **Links:** SRS-07, ADR-7, ADR-10, ADR-11, ADR-12, DECI-0006, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/62, https://github.com/DGR-AI-Labs/dgr-core/commit/5db7743897a08fdd9aa1fb5eb7c212c69e81b47e, https://github.com/DGR-AI-Labs/dgr-core/pull/63, https://github.com/DGR-AI-Labs/dgr-core/commit/fb7eefe24baf34279ef3ef8418562d41cb930cd4, https://github.com/DGR-AI-Labs/dgr-core/pull/64, https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5, https://github.com/DGR-AI-Labs/dgr-core/pull/67, https://github.com/DGR-AI-Labs/dgr-core/commit/418beb638351dfb317797939b1c7083d42340e1a

<a id="core-002-step1"></a>
## CORE-002-STEP1 — Step 1 — deny on absent token (ATK-01)

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** SRS-07, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** The founder-authored guard now blocks a direct effectful call when no capability token is present; PR #62 was founder-merged after ATK-01 and VAL-002 validation passed.
- **Acceptance criteria:**
  - [ ] An absent capability token returns Deny with RequiredOutcome::Block and the stable ATK-01 denial signal.
  - [ ] A present token returns FounderImplementationRequired while Steps 2–5 remain pending.
  - [ ] No path returns Allow, ATK-01 is green, and ATK-02 through ATK-15 remain ignored at this milestone.
- **Definition of Done:** The founder-authored Step 1 change is merged, ATK-01 passes before tool execution, and the present-token path remains explicitly unimplemented.
- **Human gate:** Completed by founder merge
- **Dependencies:** CORE-001, ARCH-004, VAL-002
- **Links:** SRS-07, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-REVIEW, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/62, https://github.com/DGR-AI-Labs/dgr-core/commit/5db7743897a08fdd9aa1fb5eb7c212c69e81b47e

<a id="core-002-step2"></a>
## CORE-002-STEP2 — Step 2 — verify signature and pinned key (ATK-10)

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** Founder-merged token verification selects the guard-local pinned K2 key by key_id and verifies Ed25519 over the transmitted ARCH-006 preimage. Real VAL-002 canaries make ATK-10 green with zero effectful invocations; PR #63 was founder-merged.
- **Acceptance criteria:**
  - [ ] K2 key selection and Ed25519 verification make ATK-10 green.
  - [ ] Unknown key_id and client-supplied key material deny.
  - [ ] No later check or Allow is reachable after verification failure.
- **Definition of Done:** ATK-10 passes against founder-authored verification using the pinned key set, with unknown or unverifiable tokens denied.
- **Human gate:** Completed by founder merge
- **Dependencies:** CORE-002-STEP1, TOOL-002, VAL-002
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/63, https://github.com/DGR-AI-Labs/dgr-core/commit/fb7eefe24baf34279ef3ef8418562d41cb930cd4

<a id="core-002-step3"></a>
## CORE-002-STEP3 — Step 3 — enforce token lifetime (ATK-02)

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** Founder-merged Step 3 threads the guard-local T2 clock through the decision boundary, then enforces the settled lifetime/skew rules and activates the ATK-02 proof. PR #64 merged both dependency-ordered pieces.
- **Acceptance criteria:**
  - [ ] Piece 1 threads a caller-supplied Unix timestamp through the guard interface, adapter, and all eight conformance call sites without changing the Step 2 decision behavior.
  - [ ] Piece 2 applies the settled 300-second token lifetime and 30-second skew, making expired tokens deny before tool execution.
  - [ ] The valid and expiry-boundary behavior is exercised by deterministic VAL-002 fixtures with zero effectful invocations.
- **Definition of Done:** Both Step 3 pieces are founder-reviewed, ATK-02 and the deterministic lifetime/skew boundary fixtures pass, and the guard remains fail-closed before tool execution.
- **Human gate:** Completed by founder merge
- **Dependencies:** CORE-002-STEP2, VAL-002
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/64, https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5

<a id="core-002-step3-piece1"></a>
## CORE-002-STEP3-PIECE1 — Step 3 Piece 1 — thread the guard-local clock

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** The founder-merged Step 3 change on codex/core-002-step3-atk02 threads an explicit now_unix_seconds value through the decision interface and adapter before applying expiry math.
- **Acceptance criteria:**
  - [ ] GuardDecisionPort and BeforeToolCallAdapter accept and relay now_unix_seconds without deriving or interpreting time.
  - [ ] The VAL-002 observe helper uses fixture.clock.now_unix_seconds(); the other seven call sites use FIXED_NOW_UNIX_SECONDS.
  - [ ] The Verified arm remains FounderImplementationRequired, and formatting, all-target build, ATK-01, ATK-10, VAL-002, and adapter tests stay green.
- **Definition of Done:** Clock plumbing compiles across every implementation and caller, the full existing suite is green, and no expiry decision or Allow path is introduced.
- **Human gate:** Completed by founder merge
- **Dependencies:** CORE-002-STEP2, VAL-002
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/64, https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5

<a id="core-002-step3-piece2"></a>
## CORE-002-STEP3-PIECE2 — Step 3 Piece 2 — enforce lifetime and prove ATK-02

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** Founder-merged guard logic applies the settled 300-second lifetime and 30-second skew to verified transmitted token fields and activates deterministic ATK-02 boundary, overlong-lifetime, and reversed-lifetime proofs.
- **Acceptance criteria:**
  - [ ] The guard applies the settled token-lifetime and skew rules only after signature verification succeeds.
  - [ ] The valid fixture and the token at the 30-second skew boundary reach FounderImplementationRequired; tokens expired by 120 seconds or 31 seconds deny.
  - [ ] ATK-02 boundary tests assert zero effectful invocations and leave the later Allow path unimplemented.
- **Definition of Done:** ATK-02 and all deterministic valid, expired, and skew-boundary fixtures pass against the founder-authored guard with no effectful invocation.
- **Human gate:** Completed by founder merge
- **Dependencies:** CORE-002-STEP3-PIECE1, VAL-002
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/64, https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5

<a id="core-002-step4"></a>
## CORE-002-STEP4 — Step 4 — verify typed request binding (ATK-08/09/11)

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, ARCH-005-typed-authorization-schema, ARCH-006-token-wire-format
- **Context:** Founder-merged Step 4 recomputes the raw ARCH-005 six-field SHA-256 request commitment from the intercepted action after signature and temporal checks. Scope, substitution, parameter-swap, and malformed-amount fixtures deny with zero effectful invocations; matching and non-binding-only changes advance to FounderImplementationRequired, so Step 5 remains the only path to a future Allow.
- **Acceptance criteria:**
  - [ ] The guard recomputes the typed per-tool request hash under the canonical rule.
  - [ ] Scope escalation, token substitution, and parameter swap make ATK-08, ATK-09, and ATK-11 green by denying.
  - [ ] Excluded tool, idempotency-key, and memo fields do not influence the commitment, and no client-supplied commitment is trusted.
- **Definition of Done:** ATK-08, ATK-09, and ATK-11 pass against the founder-authored canonical request-binding check.
- **Human gate:** Completed by founder merge
- **Dependencies:** CORE-002-STEP3, ARCH-005, ARCH-006, VAL-002
- **Links:** DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, ARCH-005-typed-authorization-schema, ARCH-006-token-wire-format, https://github.com/DGR-AI-Labs/dgr-core/pull/67, https://github.com/DGR-AI-Labs/dgr-core/commit/418beb638351dfb317797939b1c7083d42340e1a

<a id="core-002-step5"></a>
## CORE-002-STEP5 — Step 5 — atomically consume authorization (ATK-03)

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** cross-model-reviewed, sast-evidence-complete, post-merge-human-review-complete, process-nonconformance-recorded, governance-disposition-accepted
- **Prerequisites:** DECI-0010, DECI-0011, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** Founder-authored Step 5 performs atomic insert-if-absent consumption before Allow. The S2 guarantee is durable across process or connection restart only when the runtime reopens the same SQLite file; cross-process coordination through separate databases and distributed replay protection remain deferred S3 scope. The implementation merged through dgr-core PR #68 at commit ffe3a0fcb23f45d2d3b82e76df7e9bff44ff72e4. Independent-human, cross-model, adversarial, and three-engine SAST/SCA review are complete. Semgrep and CodeQL covered all 14 Rust files without execution or extraction errors; the founder accepted one Semgrep test-only finding and seven CodeQL deterministic-fixture findings. cargo-deny passed with zero blocking diagnostics, and its two version-pinned duplicate-dependency exceptions were accepted as temporary policy exceptions rather than advisory waivers. No T0 Rust changed between reviewed commit 0727e327631b475990ef8d9b7ef3b2c3554050a8 and scanned descendant 0a54d4995d1b9d98ab8a3ec61861fe2fe7ae29c3. The protected checklist on PR #70 records that PR #68 merged before final checklist sign-off. The founder formally accepted the post-merge remediation through the governance disposition in PR #71 without rewriting that history or weakening future T0 gates.
- **Acceptance criteria:**
  - [ ] S2 atomically persists single-use consumption before Allow and a restart test reopens the same SQLite file.
  - [ ] A previously consumed authorization makes ATK-03 green by denying.
  - [ ] Store failure cannot produce Allow; explicit fault mapping and ATK-13 prove fail-closed behavior with zero effectful invocation.
  - [ ] Production construction must use the file-backed open_at path before claiming restart durability; separate database files are not coordinated in S2.
- **Definition of Done:** ATK-03 and the applicable fail-closed regression pass against durable-local atomic consumption with restart evidence, record-before-allow ordering, and zero effectful invocation on store failure; required T0, cross-model, SAST, and human-review evidence is approved.
- **Human gate:** Completed — post-merge independent-human and founder evidence review is complete, and the founder formally accepted the recorded timing remediation through dgr-core PR #71
- **Dependencies:** CORE-002-STEP4, TOOL-002, VAL-002
- **Links:** DECI-0011, https://github.com/DGR-AI-Labs/dgr-core/pull/68, https://github.com/DGR-AI-Labs/dgr-core/commit/0727e327631b475990ef8d9b7ef3b2c3554050a8, https://github.com/DGR-AI-Labs/dgr-core/commit/0a54d4995d1b9d98ab8a3ec61861fe2fe7ae29c3, https://github.com/DGR-AI-Labs/dgr-core/commit/2712f0f815c5f132af5b2237c066b5e1b6b174b7, https://github.com/DGR-AI-Labs/dgr-core/commit/ffe3a0fcb23f45d2d3b82e76df7e9bff44ff72e4, https://github.com/DGR-AI-Labs/dgr-core/pull/69, https://github.com/DGR-AI-Labs/dgr-core/pull/70, https://github.com/DGR-AI-Labs/dgr-core/commit/b745adf6f223d362a55294e9de4c3cad9511b8e6, https://github.com/DGR-AI-Labs/dgr-core/pull/71

<a id="core-003"></a>
## CORE-003 — Fail closed when the reached enforcement hook errors (ATK-07)

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** In Progress
- **Tags:** atk-07, hook-reached, scope-fence
- **Prerequisites:** SRS-07, ADR-11, ADR-12, DECI-0006
- **Context:** CORE-003 owns ATK-07 only. In the Rust isolation harness, the enforcement hook is reached but its guard/verifier returns Err(GuardFault) or unwinds. The required boundary observation is Blocked with the registry-derived FailClosed outcome, no authorization, and zero effectful invocations. Hook-never-fired, route-around, plugin-missing, and operator-bypass threats remain deferred runtime-integration scope in RUNTIME-003/004.
- **Acceptance criteria:**
  - [ ] CORE-003-T3-tests supplies reviewed faulting and panicking guard conformance scaffolding without T0 behavior.
  - [ ] CORE-003-T0-boundary supplies the founder-authored fault/panic fail-closed floor.
  - [ ] ATK-07 is green only when both typed faults and unwinds block with FailClosed, issue no authorization, and invoke no effectful tool.
  - [ ] RUNTIME-003/004 retain hook-never-fired, route-around, plugin-missing, and operator-bypass scope unchanged.
- **Definition of Done:** Both CORE-003 children are Done, the founder-reviewed ATK-07 tests are un-ignored and green, and the scope fence remains explicit.
- **Human gate:** Founder — authors and reviews CORE-003-T0-boundary before ATK-07 is un-ignored
- **Dependencies:** CORE-003-T3-tests, CORE-003-T0-boundary
- **Links:** SRS-07, ADR-11, ADR-12, DECI-0006, https://github.com/DGR-AI-Labs/dgr-core/pull/72

<a id="core-003-t3-tests"></a>
## CORE-003-T3-tests — Scaffold ATK-07 typed-fault and panic conformance tests

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Engineering
- **Status:** In Review
- **Tags:** atk-07, t3-tests, red-test, in-review
- **Prerequisites:** SRS-07, ADR-11, ADR-12, DECI-0006
- **Context:** Agent-authorable Rust test work for ATK-07 only: document the boundary contract and add test-only faulting and panicking guards whose registry-derived assertions demand Blocked(FailClosed), no authorization, and zero effectful invocations. Required all-target CI stays green by compiling these pending-founder tests as explicitly ignored; direct invocation demonstrates the intended RED state.
- **Acceptance criteria:**
  - [ ] A test-only GuardDecisionPort returns Err(GuardFault::InternalError).
  - [ ] A test-only GuardDecisionPort panics at decide.
  - [ ] Both conformance tests derive ATK-07's outcome from the attack registry and reject Proceeded, raw GuardFault, or an escaping panic.
  - [ ] The tests assert zero effectful invocations and carry the exact pending-founder ignore reason while required all-target CI must remain green.
  - [ ] No executable adapter behavior or founder-owned enforcement unit changes.
- **Definition of Done:** dgr-core PR #72 is independently reviewed and merged with normal CI green, both pending-founder cases demonstrably RED when invoked directly, and no enforcement implementation authored.
- **Human gate:** None
- **Dependencies:** CORE-001
- **Links:** SRS-07, ADR-11, ADR-12, DECI-0006, https://github.com/DGR-AI-Labs/dgr-core/pull/72

<a id="core-003-t0-boundary"></a>
## CORE-003-T0-boundary — Author the ATK-07 fail-closed boundary floor

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** atk-07, t0, founder-authored, human-gated
- **Prerequisites:** SRS-07, ADR-11, ADR-12, DECI-0006
- **Context:** Founder-authored Rust T0 work for ATK-07 only. The reached before_tool_call boundary must map a guard Err(GuardFault) or unwind panic to Blocked with the registry-derived FailClosed outcome, no authorization, and zero effectful invocations, while relaying returned Ok(Deny|Allow) decisions unchanged. This item does not claim hook-never-fired, route-around, plugin-missing, or operator-bypass coverage; those remain in RUNTIME-003/004.
- **Acceptance criteria:**
  - [ ] Err(GuardFault) at the reached boundary produces Blocked(FailClosed) with no authorization and zero effectful invocations.
  - [ ] An unwind from decide is contained at the reached boundary and produces the same fail-closed observation.
  - [ ] Returned Ok(Deny|Allow) decisions retain their established relay semantics.
  - [ ] The founder turns both CORE-003-T3-tests cases green and then un-ignores the canonical ATK-07 gate test.
- **Definition of Done:** The founder authors the T0 fault/panic floor, completes the human review gate, and records green un-ignored ATK-07 evidence without broadening the isolation claim into RUNTIME-003/004.
- **Human gate:** Founder — sole author of the T0 boundary behavior and final ATK-07 reviewer
- **Dependencies:** CORE-003-T3-tests
- **Links:** SRS-07, ADR-11, ADR-12, DECI-0006

<a id="core-004"></a>
## CORE-004 — Approval-timeout deny test

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** S
- **Owner-role:** Engineering
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SRS-07, ADR-12, DECI-0006
- **Context:** In Rust, prove unresolved human approval cannot become authorization.
- **Acceptance criteria:**
  - [ ] A pending approval is forced past its deadline.
  - [ ] The observed result is deny.
  - [ ] No downstream effect occurs.
- **Definition of Done:** The timeout regression is deterministic and reviewer-approved.
- **Human gate:** None
- **Dependencies:** CORE-001
- **Links:** SRS-07, ADR-12, DECI-0006

<a id="core-005"></a>
## CORE-005 — Wire the bypass suite as a permanent CI gate

- **Type:** Task
- **Epic:** Core Enforcement + Bypass Suite
- **Priority:** P0 (source-stated first technical priority)
- **Size:** M
- **Owner-role:** Engineering
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SRS-07, ADR-7, ADR-12, DECI-0006
- **Context:** Wire the Rust bypass proof so it is repeatable on every relevant change.
- **Acceptance criteria:**
  - [ ] CI runs the suite without network-dependent adjudication.
  - [ ] A seeded bypass makes the job fail.
  - [ ] Evidence and ownership are documented.
- **Definition of Done:** CI is reproducibly red on a seeded bypass and green only when every case blocks as specified.
- **Human gate:** None
- **Dependencies:** CORE-002, CORE-003, CORE-004
- **Links:** SRS-07, ADR-7, ADR-12, DECI-0006

<a id="pol-001"></a>
## POL-001 — Draft starter Cedar policy and evidence schema

- **Type:** Task
- **Epic:** Policy Plane
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Product manager
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SPEC-POLICY-PLANE, SRS-07
- **Context:** Define a reviewable demo policy without deciding the second action.
- **Acceptance criteria:**
  - [ ] One payment action and one placeholder non-payment class are represented.
  - [ ] Required evidence, freshness, deny, and escalation behavior are explicit.
  - [ ] The non-payment class remains gated by FND-6.
- **Definition of Done:** Policy/schema draft type-checks or has a documented deterministic check and is reviewer-approved.
- **Human gate:** FND-6
- **Dependencies:** None
- **Links:** SPEC-POLICY-PLANE, SRS-07

<a id="val-001"></a>
## VAL-001 — Scaffold SAST trio CI stubs

- **Type:** Task
- **Epic:** Validation & QA Gates
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SRS-07, DECI-0011
- **Context:** Prepare Semgrep, CodeQL, and cargo-deny CI gates under the FND-7 validation and reviewer model.
- **Acceptance criteria:**
  - [ ] Semgrep and CodeQL jobs are structurally defined.
  - [ ] cargo-deny runs advisory, license, ban, and source policy checks from the committed deny.toml.
  - [ ] Tool execution errors, incomplete coverage, and missing raw artifacts fail closed.
  - [ ] Reviewer and writer roles cannot be the same in the documented gate.
- **Definition of Done:** CI stubs validate syntactically and `make verify` is green.
- **Human gate:** Independent human review and founder final SAST sign-off
- **Dependencies:** None
- **Links:** DECI-0011

<a id="val-002"></a>
## VAL-002 — Prepare deterministic CORE-002 token fixtures

- **Type:** Task
- **Epic:** Validation & QA Gates
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, ARCH-005-typed-authorization-schema, ARCH-006-token-wire-format
- **Context:** Founder-reviewed dgr-core PR #61 merged the deterministic fixture set at commit 48ee258. The fixtures remain support code and contain no enforcement logic.
- **Acceptance criteria:**
  - [ ] Fixtures represent a valid 300-second token, an expired token, and a token inside the 30-second skew band.
  - [ ] No-token, forged-signature, unknown-key, request-mismatch, and already-consumed cases are deterministic data.
  - [ ] Fixture requests use typed authorization-relevant fields, decimal-string money, normalized identifiers, and no bound floats.
  - [ ] The full cargo test command remains runnable and intended red or ignored cases are documented until their founder-authored step lands.
  - [ ] No fixture implements a guard decision, signature acceptance, or consumption outcome.
- **Definition of Done:** The complete fixture set compiles, deterministically exercises the settled values through the harness, and contains no T0 enforcement logic.
- **Human gate:** None
- **Dependencies:** ARCH-004, ARCH-005, ARCH-006, TOOL-002
- **Links:** DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, ARCH-005-typed-authorization-schema, ARCH-006-token-wire-format, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/pull-requests/1/details?region=us-west-2, https://github.com/DGR-AI-Labs/dgr-core/pull/61, https://github.com/DGR-AI-Labs/dgr-core/commit/48ee25869fb2e3215505ba55dd7372aa586c998d

<a id="val-atk15"></a>
## VAL-ATK15 — Make ATK-15 a live hosted-IAM assertion

- **Type:** Task
- **Epic:** Validation & QA Gates
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SRS-07, DECI-0008, SPEC-CORE-001-ATTACK-SET
- **Context:** ATK-15 is an accepted visible hosted-IAM execution gap, not a Phase 1 gate simulation. Close it before any hosted or multi-tenant deployment.
- **Acceptance criteria:**
  - [ ] A live AWS IAM assertion assumes a hosted tenant silo and its scoped deploy role.
  - [ ] The assertion proves the deploy role cannot decrypt the tenant CMK.
  - [ ] The assertion proves the deploy role cannot read the tenant ledger and returns no tenant plaintext or record.
  - [ ] The live assertion is a required pre-deployment check for every hosted/multi-tenant environment.
- **Definition of Done:** A reproducible live AWS IAM assertion passes for both denied operations, captures reviewable evidence, and is enforced before any hosted/multi-tenant deployment.
- **Human gate:** Founder — Phase 3 hosted tier, before first hosted/multi-tenant deployment
- **Dependencies:** None
- **Links:** SRS-07, DECI-0008, SPEC-CORE-001-ATTACK-SET

<a id="res-001"></a>
## RES-001 — Draft independent-citation remediation plan

- **Type:** Task
- **Epic:** Research & Credibility
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Product manager
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR
- **Context:** Turn the internal citation-gap finding into bounded remediation work.
- **Acceptance criteria:**
  - [ ] Independent evidence channels and target artifacts are listed.
  - [ ] Self-published and independent evidence are separated.
  - [ ] No external credibility claim is upgraded.
- **Definition of Done:** Plan has owners as role slots, checkable next actions, and reviewer approval.
- **Human gate:** None
- **Dependencies:** None
- **Links:** GLOSSARY-DGR

<a id="res-002"></a>
## RES-002 — Sync DEPLOY-5 and ICLR primary-artifact links

- **Type:** Task
- **Epic:** Research & Credibility
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Project manager
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR
- **Context:** Replace fact-pack-only research state with primary artifact references.
- **Acceptance criteria:**
  - [ ] Each claimed artifact is linked or marked not authored.
  - [ ] Dates and outcomes are copied only from primary evidence.
  - [ ] Missing sources are routed to FND-11.
- **Definition of Done:** Primary-artifact inventory is complete and `make verify` is green.
- **Human gate:** FND-11
- **Dependencies:** None
- **Links:** GLOSSARY-DGR

<a id="tool-002"></a>
## TOOL-002 — Pin CORE-002 cryptographic and durable-store dependencies

- **Type:** Task
- **Epic:** Developer Tooling
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** Founder-reviewed dgr-core PR #59 pinned ed25519-dalek 2.2.0 and rusqlite 0.40.2 with bundled SQLite; no enforcement logic was authored.
- **Acceptance criteria:**
  - [ ] The founder-approved Ed25519 verification dependency is pinned reproducibly.
  - [ ] The founder-approved S2 substrate is pinned and demonstrates durable atomic insert-if-absent capability outside the guard.
  - [ ] Dependency licenses, supported versions, and deterministic build behavior are reviewable.
  - [ ] No guard, token-verification decision, fail-closed mapping, or consumption logic is authored in this task.
- **Definition of Done:** The approved dependencies and capability checks build reproducibly and are ready for the founder-authored Step 2 and Step 5 units.
- **Human gate:** Completed by founder merge
- **Dependencies:** ARCH-004
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/59, https://github.com/DGR-AI-Labs/dgr-core/commit/179d9f15a80be4d38afe2ce6c697ba811f480829

<a id="tool-003"></a>
## TOOL-003 — Deploy and verify both internal auto-publication pipelines

- **Type:** Task
- **Epic:** Developer Tooling
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0009, HOWTO-DEPLOY-INTERNAL-HOSTING
- **Context:** The us-west-2 reference and us-east-1 backlog pipelines are merged, deployed, and recorded as successful with fail-closed ordering and separate publication prefixes.
- **Acceptance criteria:**
  - [ ] Both regional main-branch pipelines are versioned and operational evidence is recorded.
  - [ ] Reference publication precedes backlog lock validation and publication.
  - [ ] External publication remains unwired.
- **Definition of Done:** The committed rollout report records successful automatic main executions for both regional pipelines.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0009, HOWTO-DEPLOY-INTERNAL-HOSTING, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/ff003ae8f0244473e05e1e18dbe92301e295630f?region=us-west-2, https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-backlog/commit/16c9fc04d12163b3c319e2519902569a5b4a4572?region=us-east-1

<a id="tool-004"></a>
## TOOL-004 — Emit build-time reference propagation receipts

- **Type:** Task
- **Epic:** Developer Tooling
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0009
- **Context:** The internal publisher records previous/current source SHA and UTC propagation metadata at build time.
- **Acceptance criteria:**
  - [ ] A build-time receipt records previous and current source commits plus UTC time.
  - [ ] Unit and publication verification cover receipt generation.
  - [ ] The receipt does not alter T0 code.
- **Definition of Done:** The propagation-receipt implementation and tests are merged to dgr-internal main.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0009, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/504448f9c437dea95f8849b4b232326374ebda39?region=us-west-2

<a id="tool-005"></a>
## TOOL-005 — Establish the dgr-backlog CodeCommit remote and main trunk

- **Type:** Task
- **Epic:** Developer Tooling
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0001, HOWTO-BACKLOG-WORKFLOW
- **Context:** The backlog history converged to a non-rewritten main trunk and now has an authenticated us-east-1 CodeCommit origin containing current main.
- **Acceptance criteria:**
  - [ ] The canonical trunk is named main without history rewrite.
  - [ ] The CodeCommit origin exposes main and preserves the converged commits.
  - [ ] No force-push or unique-commit loss occurs.
- **Definition of Done:** The convergence report is on main and the current CodeCommit main contains it.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0001, HOWTO-BACKLOG-WORKFLOW, https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-backlog/commit/8208186501f6aa0817cc31b92870852cef1ed90f?region=us-east-1, https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-backlog/commit/e3c7ce5fcbf3326154327337ee72f7b03d63cab0?region=us-east-1

<a id="pm-001"></a>
## PM-001 — Stand up founder-decision queue hygiene

- **Type:** Task
- **Epic:** Validation & QA Gates
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Project manager
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0001
- **Context:** Keep founder decisions separate from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] FND-1 through FND-15 are present and uniquely identified.
  - [ ] Each item has a Done-when and affected locations.
  - [ ] No decision outcome is filled.
- **Definition of Done:** Founder queue validates and is linked from role navigation.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0001, https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-backlog/commit/e3c7ce5fcbf3326154327337ee72f7b03d63cab0?region=us-east-1

<a id="pm-002"></a>
## PM-002 — Apply board-hygiene rules to starter items

- **Type:** Task
- **Epic:** Validation & QA Gates
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Project manager
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0001
- **Context:** Ensure every starter is genuinely pickable and finishable.
- **Acceptance criteria:**
  - [ ] Every starter is To Do and size S or M.
  - [ ] Every starter has prerequisites, acceptance criteria, and DoD.
  - [ ] WIP guidance remains one to two items.
- **Definition of Done:** Automated starter validation passes.
- **Human gate:** None
- **Dependencies:** None
- **Links:** DECI-0001, https://us-east-1.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-backlog/commit/e3c7ce5fcbf3326154327337ee72f7b03d63cab0?region=us-east-1

<a id="prod-001"></a>
## PROD-001 — Draft minimum-irreplaceable-product brief

- **Type:** Task
- **Epic:** Strategy & GTM
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Product manager
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR, SPEC-POLICY-PLANE, SRS-07
- **Context:** Keep the wedge on cross-action, rail-agnostic decision governance.
- **Acceptance criteria:**
  - [ ] User, job, boundary, non-goals, and proof are explicit.
  - [ ] The brief does not collapse into a spending cap or generic governance.
  - [ ] Open-core and demo choices link to FND-6/FND-8.
- **Definition of Done:** Brief is reviewable by Product and Engineering and `make verify` is green.
- **Human gate:** FND-6 and FND-8
- **Dependencies:** None
- **Links:** GLOSSARY-DGR, SPEC-POLICY-PLANE, SRS-07

<a id="prod-002"></a>
## PROD-002 — Draft demo acceptance checklist

- **Type:** Task
- **Epic:** Policy Plane
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Product manager
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SPEC-POLICY-PLANE, SRS-07
- **Context:** Define observable demo behavior while leaving scenario selection open.
- **Acceptance criteria:**
  - [ ] Allow, deny, insufficient evidence, and timeout behavior are checkable.
  - [ ] Payment hero and non-payment slot are separate.
  - [ ] Scenario choice links to FND-6.
- **Definition of Done:** Checklist is executable once FND-6 resolves and is reviewer-approved.
- **Human gate:** FND-6
- **Dependencies:** None
- **Links:** SPEC-POLICY-PLANE, SRS-07

<a id="sales-001"></a>
## SALES-001 — Build trigger-qualified target-account list

- **Type:** Task
- **Epic:** Strategy & GTM
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Sales / Business development
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR
- **Context:** Create a bounded list using the stated off-core, digital-first fintech hypothesis.
- **Acceptance criteria:**
  - [ ] Each account has a public trigger and source.
  - [ ] No private contact data is stored.
  - [ ] Beachhead remains a founder confirmation.
- **Definition of Done:** A reviewable list with source links and qualification notes exists.
- **Human gate:** FND-8
- **Dependencies:** None
- **Links:** GLOSSARY-DGR

<a id="epic-fnd"></a>
## EPIC-FND — Founder Decision Queue

- **Type:** Epic
- **Epic:** Founder Decision Queue
- **Priority:** {FOUNDER-SUPPLY: priority}
- **Size:** L — child items must be S/M
- **Owner-role:** Founder
- **Status:** Blocked
- **Tags:** None
- **Prerequisites:** DECI-0001
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** {FOUNDER-SUPPLY: Epic Definition of Done}
- **Human gate:** FND-3 and FND-4
- **Dependencies:** None
- **Links:** DECI-0001

<a id="fnd-1"></a>
## FND-1 — Confirm current phase

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR, DECI-0002
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Current phase is recorded in program status and linked to a DECI record.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0002, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/c813399282665723647a8bcc111fade248861b60?region=us-west-2

<a id="fnd-2"></a>
## FND-2 — Confirm Foundation Part A state

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** HOWTO-FOUNDATION, DECI-0003
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Evidence-backed Foundation state is recorded without inferred percentage.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0003, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/c813399282665723647a8bcc111fade248861b60?region=us-west-2

<a id="fnd-3"></a>
## FND-3 — Assign owner-role per workstream Epic

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0001, DECI-0004
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** All eight workstream owner-role tokens are resolved.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0004, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/c813399282665723647a8bcc111fade248861b60?region=us-west-2

<a id="fnd-4"></a>
## FND-4 — Set priority and DoD per workstream Epic

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0001, DECI-0005
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** All eight Epic priority and DoD tokens are resolved.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0005, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/c813399282665723647a8bcc111fade248861b60?region=us-west-2

<a id="fnd-5"></a>
## FND-5 — Decide ADR-10, ADR-11, and ADR-12

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, ADR-11, ADR-12, DECI-0006
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Each ADR records a founder-approved decision or explicit deferral.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0006, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/322e5c826195a016ed9d0f96342565a6f851e741?region=us-west-2

<a id="fnd-6"></a>
## FND-6 — Lock demo scenario and first non-payment action

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SPEC-POLICY-PLANE
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Demo and second action are recorded in a DECI record.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** SPEC-POLICY-PLANE

<a id="fnd-7"></a>
## FND-7 — Set active validation stack and reviewer model

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** SRS-07, DECI-0011
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** The obsolete Phase-0 numeric threshold is explicitly deferred, and the Semgrep, CodeQL, cargo-deny, independent-human-review, and founder-sign-off model is recorded.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0011, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/505f3e470109bd10581b79980dc6a3ed2bb0b546?region=us-west-2

<a id="fnd-8"></a>
## FND-8 — Set business and Phase-3 gates

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** GLOSSARY-DGR
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Open-core, capital trigger, pricing, latency, and assurance timing are recorded.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** GLOSSARY-DGR

<a id="fnd-9"></a>
## FND-9 — Confirm role materials and external allowlist width

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** DECI-0001
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Role lists and external allowlist width are approved without implicit widening.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0001

<a id="fnd-10"></a>
## FND-10 — Name AWS permission sets and deploy boundary

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** HOWTO-FOUNDATION
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Exact permission sets, target accounts, and deploy approver are recorded.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** HOWTO-FOUNDATION

<a id="fnd-11"></a>
## FND-11 — Identify authoritative missing sources

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** DECI-0001
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Unified plan, ADR-5/8/9, tenant runbook, and prompt-library sources are synced or marked to author.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0001

<a id="fnd-12"></a>
## FND-12 — Rank and define the Model bake-off leaf tasks

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** To Do
- **Tags:** None
- **Prerequisites:** SRS-07
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Priority and Definition of Done for BKO-001..005 are recorded or explicitly deferred without inferred values.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** SRS-07

<a id="fnd-13"></a>
## FND-13 — Authorize CORE-002 Phase 1 enforcement in binding governance

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** DECI-0010, HOWTO-CORE-002-GUARD-AUTHORING
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** The binding dgr-core constitution and phase records explicitly permit the founder-authored CORE-002 enforcement work without a Phase 0 contradiction.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** DECI-0010, HOWTO-CORE-002-GUARD-AUTHORING, https://github.com/DGR-AI-Labs/dgr-core/pull/57, https://github.com/DGR-AI-Labs/dgr-core/commit/da6e39e291dcf689ec294463d7e3be8116eeb756

<a id="fnd-14"></a>
## FND-14 — Select the canonical CORE-002 implementation surface

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, ADR-12, DECI-0010, SPEC-CORE-002-GUARD-DESIGN
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** The Rust and TypeScript T0 surfaces have a recorded canonical disposition, including removal or quarantine of conflicting timing and enforcement paths.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** ADR-10, ADR-12, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, https://us-west-2.console.aws.amazon.com/codesuite/codecommit/repositories/dgr-internal/commit/322e5c826195a016ed9d0f96342565a6f851e741?region=us-west-2, https://github.com/DGR-AI-Labs/dgr-core/pull/58

<a id="fnd-15"></a>
## FND-15 — Approve CORE-002 Ed25519 and S2 dependency choices

- **Type:** Task
- **Epic:** Founder Decision Queue
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Founder
- **Status:** Done
- **Tags:** None
- **Prerequisites:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN
- **Context:** Founder-only decision separated from co-founder-executable work.
- **Acceptance criteria:**
  - [ ] Affected token locations are reviewed.
  - [ ] Outcome or explicit deferral is recorded.
- **Definition of Done:** Exact vetted Rust dependencies for Ed25519 verification and the durable-local atomic S2 substrate are recorded for implementation.
- **Human gate:** Founder
- **Dependencies:** None
- **Links:** ADR-10, DECI-0010, SPEC-CORE-002-GUARD-DESIGN, https://github.com/DGR-AI-Labs/dgr-core/pull/59, https://github.com/DGR-AI-Labs/dgr-core/commit/179d9f15a80be4d38afe2ce6c697ba811f480829

<a id="epic-bko"></a>
## EPIC-BKO — Model bake-off

- **Type:** Epic
- **Epic:** Model bake-off
- **Priority:** {FOUNDER-SUPPLY: priority}
- **Size:** L — child items must be S/M
- **Owner-role:** {FOUNDER-SUPPLY: owner-role}
- **Status:** Blocked
- **Tags:** None
- **Prerequisites:** DECI-0001
- **Context:** Portfolio workstream migrated from the DGR program map.
- **Acceptance criteria:**
  - [ ] Every child item conforms to the work-item standard.
- **Definition of Done:** {FOUNDER-SUPPLY: Epic Definition of Done}
- **Human gate:** FND-3 and FND-4
- **Dependencies:** None
- **Links:** DECI-0001

<a id="bko-001"></a>
## BKO-001 — Probe the Bedrock candidate boundary

- **Type:** Task
- **Epic:** Model bake-off
- **Priority:** {FOUNDER-SUPPLY: migrated priority}
- **Size:** M
- **Owner-role:** Founder
- **Status:** {FOUNDER-SUPPLY: migrated status}
- **Tags:** None
- **Prerequisites:** SRS-07
- **Context:** Migrated from the original model bake-off backlog; original detail remains in Backlog-legacy.md.
- **Acceptance criteria:**
  - [ ] Original acceptance criteria are reviewed before execution.
- **Definition of Done:** {FOUNDER-SUPPLY: migrated Definition of Done confirmation}
- **Human gate:** FND-12
- **Dependencies:** None
- **Links:** SRS-07, FND-12

<a id="bko-002"></a>
## BKO-002 — Freeze the DGR evaluation battery

- **Type:** Task
- **Epic:** Model bake-off
- **Priority:** {FOUNDER-SUPPLY: migrated priority}
- **Size:** M
- **Owner-role:** Founder
- **Status:** {FOUNDER-SUPPLY: migrated status}
- **Tags:** None
- **Prerequisites:** SRS-07
- **Context:** Migrated from the original model bake-off backlog; original detail remains in Backlog-legacy.md.
- **Acceptance criteria:**
  - [ ] Original acceptance criteria are reviewed before execution.
- **Definition of Done:** {FOUNDER-SUPPLY: migrated Definition of Done confirmation}
- **Human gate:** FND-12
- **Dependencies:** None
- **Links:** SRS-07, FND-12

<a id="bko-003"></a>
## BKO-003 — Run each approved Tier-1 candidate

- **Type:** Task
- **Epic:** Model bake-off
- **Priority:** {FOUNDER-SUPPLY: migrated priority}
- **Size:** M
- **Owner-role:** Founder
- **Status:** {FOUNDER-SUPPLY: migrated status}
- **Tags:** None
- **Prerequisites:** SRS-07
- **Context:** Migrated from the original model bake-off backlog; original detail remains in Backlog-legacy.md.
- **Acceptance criteria:**
  - [ ] Original acceptance criteria are reviewed before execution.
- **Definition of Done:** {FOUNDER-SUPPLY: migrated Definition of Done confirmation}
- **Human gate:** FND-12
- **Dependencies:** None
- **Links:** SRS-07, FND-12

<a id="bko-004"></a>
## BKO-004 — Score and validate results

- **Type:** Task
- **Epic:** Model bake-off
- **Priority:** {FOUNDER-SUPPLY: migrated priority}
- **Size:** M
- **Owner-role:** Founder
- **Status:** {FOUNDER-SUPPLY: migrated status}
- **Tags:** None
- **Prerequisites:** SRS-07
- **Context:** Migrated from the original model bake-off backlog; original detail remains in Backlog-legacy.md.
- **Acceptance criteria:**
  - [ ] Original acceptance criteria are reviewed before execution.
- **Definition of Done:** {FOUNDER-SUPPLY: migrated Definition of Done confirmation}
- **Human gate:** FND-12
- **Dependencies:** None
- **Links:** SRS-07, FND-12

<a id="bko-005"></a>
## BKO-005 — Decide separately per role

- **Type:** Task
- **Epic:** Model bake-off
- **Priority:** {FOUNDER-SUPPLY: migrated priority}
- **Size:** M
- **Owner-role:** Founder
- **Status:** {FOUNDER-SUPPLY: migrated status}
- **Tags:** None
- **Prerequisites:** SRS-07
- **Context:** Migrated from the original model bake-off backlog; original detail remains in Backlog-legacy.md.
- **Acceptance criteria:**
  - [ ] Original acceptance criteria are reviewed before execution.
- **Definition of Done:** {FOUNDER-SUPPLY: migrated Definition of Done confirmation}
- **Human gate:** FND-12
- **Dependencies:** None
- **Links:** SRS-07, FND-12

# Deferred / Backlog

These Phase-2/3 items are recorded but are not active Kanban work.

<a id="arch-005-appendix-b-normalization"></a>
## ARCH-005-APPENDIX-B-NORMALIZATION — Adopt Appendix-B normalization across issuer, guard, and fixtures

- **Type:** Task
- **Epic:** Architecture & Specs
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Founder
- **Status:** Deferred
- **Tags:** deferred, arch-005, normalization, binding-follow-up
- **Prerequisites:** ARCH-005-typed-authorization-schema
- **Context:** ARCH-005 Appendix-B normalization is deferred: the Step 4 canonicalizer currently binds raw strings. This is acceptable for the developer tier because raw-byte request binding already defeats the core scope-swap, token-substitution, and parameter-swap attacks. Before normalization-edge binding attacks can rely on NFC, case, or minor-unit normalization, the issuer, guard, and fixtures must adopt the same pinned rules in lockstep; changing only the guard would desynchronize minting and break valid tokens.
- **Acceptance criteria:**
  - [ ] Adopt one pinned Appendix-B normalization rule across the issuer, guard, and deterministic fixtures in the same evidence-linked change set.
  - [ ] Cover NFC, case, and minor-unit normalization edges without changing the six-field binding scope.
  - [ ] Keep existing valid-token golden vectors synchronized and prove normalization-edge binding attacks fail closed.
- **Definition of Done:** {FOUNDER-SUPPLY: ARCH-005-APPENDIX-B-NORMALIZATION Definition of Done}
- **Human gate:** Founder — activate and approve the lockstep issuer/guard/fixture migration before any one surface changes
- **Dependencies:** CORE-002-STEP4
- **Links:** ARCH-005-typed-authorization-schema

<a id="tool-001"></a>
## TOOL-001 — Write orchestration comparison memo

- **Type:** Task
- **Epic:** Developer Tooling
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** Deferred
- **Tags:** deferred, phase-2-3, runtime-integration-dependency
- **Prerequisites:** SPEC-AGENT-OPS, SPEC-AGENT-OPS-DIAGRAM
- **Context:** Deferred to Phase 2/3 as an input to the runtime-integration architecture ADR. Give the founder a bounded Paperclip versus AgentCore-native decision brief without pulling orchestration selection onto the Phase 1 CORE-002 path.
- **Acceptance criteria:**
  - [ ] Options compare operations, portability, boundary, cost evidence needs, and failure modes.
  - [ ] Recommendation is explicitly not decided.
  - [ ] A founder decision gate is identified.
- **Definition of Done:** Decision brief is reviewable, source-linked, and `make verify` is green.
- **Human gate:** FND-5
- **Dependencies:** None
- **Links:** SPEC-AGENT-OPS, SPEC-AGENT-OPS-DIAGRAM

<a id="epic-runtime-integration"></a>
## EPIC-RUNTIME-INTEGRATION — Runtime integration testing (OpenClaw + Hermes)

- **Type:** Epic
- **Epic:** Runtime integration testing (OpenClaw + Hermes)
- **Priority:** Unranked
- **Size:** L — deferred Phase 2/3 stories remain S/M
- **Owner-role:** Engineering
- **Status:** Deferred
- **Tags:** deferred, phase-2-3, runtime-integration
- **Prerequisites:** SRS-07, ADR-10, ADR-11, DECI-0006
- **Context:** Blocked until CORE-005 records the CORE-002 bypass suite fully green for all gate-tier attacks ATK-01..14 in the isolation harness. Starting earlier is an anti-pattern: it tests an incomplete guard and forces deferred Phase-3 orchestration decisions prematurely. This epic validates real interception and agent non-bypassability against a live runtime, which the isolation harness cannot prove, but is meaningful only after the guard is proven in isolation.
- **Acceptance criteria:**
  - [ ] The blocked-until trigger remains CORE-005 Done, representing the CORE-002 bypass suite fully green for ATK-01..14.
  - [ ] All runtime-integration stories remain Deferred until the founder activates the epic.
  - [ ] No Docker, OpenClaw, Hermes, T0, or integration work begins from this record.
- **Definition of Done:** The runtime-integration idea is preserved as a tracked, clearly deferred Phase-2/3 epic with a concrete bypass-suite-green trigger and its known open risks.
- **Human gate:** Founder — confirm the epic remains deferred and the blocked-until trigger is correct before merge
- **Dependencies:** CORE-005
- **Links:** SRS-07, ADR-10, ADR-11, DECI-0006

<a id="runtime-001"></a>
## RUNTIME-001 — Integration architecture ADR

- **Type:** Task
- **Epic:** Runtime integration testing (OpenClaw + Hermes)
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Deferred
- **Tags:** deferred, phase-2-3, runtime-integration
- **Prerequisites:** ADR-10, ADR-11, DECI-0006
- **Context:** Blocked until CORE-005 records the CORE-002 bypass suite fully green for all gate-tier attacks ATK-01..14 in the isolation harness. Starting earlier is an anti-pattern: it tests an incomplete guard and forces deferred Phase-3 orchestration decisions prematurely. Relate the real OpenClaw before_tool_call binding to ADR-10 agent-to-gate authentication; the deferred TOOL-001 Paperclip-versus-AgentCore question is an input. This ADR must precede Docker work.
- **Acceptance criteria:**
  - [ ] Record the architecture decision needed to bind the guard to OpenClaw before_tool_call in a real runtime.
- **Definition of Done:** {FOUNDER-SUPPLY: RUNTIME-001 Definition of Done}
- **Human gate:** Founder — activate only after the bypass-suite-green trigger
- **Dependencies:** CORE-005, TOOL-001
- **Links:** ADR-10, ADR-11, DECI-0006

<a id="runtime-002"></a>
## RUNTIME-002 — Local OpenClaw + Hermes harness (Docker)

- **Type:** Task
- **Epic:** Runtime integration testing (OpenClaw + Hermes)
- **Priority:** Unranked
- **Size:** M
- **Owner-role:** Engineering
- **Status:** Deferred
- **Tags:** deferred, phase-2-3, runtime-integration
- **Prerequisites:** ADR-11, DECI-0006
- **Context:** Blocked until CORE-005 records the CORE-002 bypass suite fully green for all gate-tier attacks ATK-01..14 in the isolation harness. Starting earlier is an anti-pattern: it tests an incomplete guard and forces deferred Phase-3 orchestration decisions prematurely.
- **Acceptance criteria:**
  - [ ] Describe a reproducible local OpenClaw and Hermes runtime that can exercise the guard against real tool calls.
- **Definition of Done:** {FOUNDER-SUPPLY: RUNTIME-002 Definition of Done}
- **Human gate:** Founder — activate only after RUNTIME-001 is decided
- **Dependencies:** CORE-005, RUNTIME-001
- **Links:** ADR-11, DECI-0006

<a id="runtime-003"></a>
## RUNTIME-003 — Integration conformance: real interception

- **Type:** Task
- **Epic:** Runtime integration testing (OpenClaw + Hermes)
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Deferred
- **Tags:** deferred, phase-2-3, runtime-integration
- **Prerequisites:** ADR-11, SPEC-CORE-001-ATTACK-SET
- **Context:** Blocked until CORE-005 records the CORE-002 bypass suite fully green for all gate-tier attacks ATK-01..14 in the isolation harness. Starting earlier is an anti-pattern: it tests an incomplete guard and forces deferred Phase-3 orchestration decisions prematurely.
- **Acceptance criteria:**
  - [ ] Prove a real agent tool call without a valid capability token is blocked at the live hook as the runtime analogue of ATK-01.
- **Definition of Done:** {FOUNDER-SUPPLY: RUNTIME-003 Definition of Done}
- **Human gate:** Founder — activate only after the local runtime harness is approved
- **Dependencies:** CORE-005, RUNTIME-002
- **Links:** ADR-11, SPEC-CORE-001-ATTACK-SET

<a id="runtime-004"></a>
## RUNTIME-004 — Integration conformance: non-bypassability

- **Type:** Task
- **Epic:** Runtime integration testing (OpenClaw + Hermes)
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Deferred
- **Tags:** deferred, phase-2-3, runtime-integration
- **Prerequisites:** SRS-07, ADR-11, SPEC-CORE-001-ATTACK-SET
- **Context:** Blocked until CORE-005 records the CORE-002 bypass suite fully green for all gate-tier attacks ATK-01..14 in the isolation harness. Starting earlier is an anti-pattern: it tests an incomplete guard and forces deferred Phase-3 orchestration decisions prematurely.
- **Acceptance criteria:**
  - [ ] Prove the agent cannot route around the live guard to reach an effectful tool within the runtime's control.
- **Definition of Done:** {FOUNDER-SUPPLY: RUNTIME-004 Definition of Done}
- **Human gate:** Founder — activate only after real-interception conformance passes
- **Dependencies:** CORE-005, RUNTIME-003
- **Links:** SRS-07, ADR-11, SPEC-CORE-001-ATTACK-SET

<a id="runtime-005"></a>
## RUNTIME-005 — Open runtime-integration risks to resolve

- **Type:** Task
- **Epic:** Runtime integration testing (OpenClaw + Hermes)
- **Priority:** Unranked
- **Size:** S
- **Owner-role:** Engineering
- **Status:** Deferred
- **Tags:** deferred, phase-2-3, runtime-integration
- **Prerequisites:** ADR-10, ADR-11, DECI-0006
- **Context:** Blocked until CORE-005 records the CORE-002 bypass suite fully green for all gate-tier attacks ATK-01..14 in the isolation harness. Starting earlier is an anti-pattern: it tests an incomplete guard and forces deferred Phase-3 orchestration decisions prematurely. Track hook semantics, Hermes routing, and authentication on the agent-to-gate channel. OpenClaw's official hook decision rules currently document that before_tool_call block is terminal; live-version behavior still requires deferred integration proof.
- **Acceptance criteria:**
  - [ ] Record specific runtime-integration questions and route each to a source, experiment, or founder decision before implementation begins.
- **Definition of Done:** {FOUNDER-SUPPLY: RUNTIME-005 Definition of Done}
- **Human gate:** Founder — confirm risks and evidence requirements when activating the epic
- **Dependencies:** CORE-005
- **Links:** ADR-10, ADR-11, DECI-0006, https://github.com/openclaw/openclaw/blob/main/docs/concepts/agent-loop.md
