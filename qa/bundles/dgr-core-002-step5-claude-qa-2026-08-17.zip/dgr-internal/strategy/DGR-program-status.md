---
title: DGR Program Status
classification: External-safe body with internal-only appendix
status: Assembly draft; founder approval required
source-of-truth: dgr-internal
---

# DGR Program Status

## Assumptions and evidence boundary

- This assembly reconciles repository sources with the founder-supplied fact
  pack dated `{AS_OF_DATE}`.
- “Present” means a source file exists; it does not imply that the underlying
  work is complete.
- Status, ownership, dates, labels, Definitions of Done, and decision outcomes
  remain founder judgments wherever explicitly marked `{FOUNDER-SUPPLY}`.
- Conflicting claims are preserved in the drift report rather than resolved
  silently.
- Enforcement-critical T0 is described only. Nothing here proposes or modifies
  capability tokens, the decision point, the fail-closed guard, or the hash
  chain.

## Executive summary

DGR is a deterministic, non-bypassable decision gate for consequential AI-agent
actions, with an initial focus on financial-services and AML governance.
The phased strategy is OSS-first, with enforcement proof before enterprise
reactivation. The current program phase is **Phase 1 — OSS MVP & Enforcement
Proof** ([DECI-0002](../decisions/DECI-0002-current-phase.md)). The Phase 0
signal test was not formally run; this is an accepted risk, revisited only if
adoption stalls. There is no design partner yet.
<!-- internal-only:start -->
The bypass suite is not green and remains the first technical proof point.
The founder is most needed to resolve the open gates below and supply honest
board states and Definitions of Done.
<!-- internal-only:end -->

## Portfolio and workstreams

| Workstream | Evidence-backed current state | Owner | Board Epic |
|---|---|---|---|
| Strategy & GTM | ICP and GTM conversion sources are present; Unified Strategy Plan is not yet synced; commercial gates remain open | Sales / Product | Strategy & GTM |
| Architecture & specs | ADR-6, ADR-7, SRS-07, and active ADR-10/11/12 are present; ADR-8 is described in the fact pack but not synced | Engineering | Architecture & Specs |
| Cloud foundation | Control Tower, organization structure, audit/log archive controls, hub account, and Identity Center profiles are reported live; per-step evidence remains pending | Engineering | Cloud Foundation |
| Core enforcement engine | Rust is the Phase 1 core; PR #2's TypeScript core is a throwaway spike; enforcement proof remains gated | Engineering | Core Enforcement + Bypass Suite |
| Policy management | Policy-plane design is present; Cedar remains the deterministic policy engine; implementation state requires founder confirmation | Product (with Engineering) | Policy Plane |
| Validation & QA gates | Validation runbook and bake-off materials are reported; deterministic bypass proof remains incomplete | Engineering | Validation & QA Gates |
| Research & credibility | ICAIL relevance source is present; DEPLOY-5 rebuttal and ICLR poster are reported in the fact pack | Product | Research & Credibility |
| Developer tooling | Bake-off tooling and agent-ops sources are present; orchestration and review-tool choices remain open | Engineering | Developer Tooling |

## Current state

### Foundation

The repository contains the Foundation bootstrap HOWTO. Per
[DECI-0003](../decisions/DECI-0003-foundation-state-method.md), `CFN-001` must
produce an evidence table marking every Foundation Part A/HOWTO step
**evidenced**, **not evidenced**, or **unknown**. No completion percentage is
inferred. Only if that table supports it may this section summarize the state as
“Part A substantially complete; Deploy Step 3d + validation pending.”
Multi-AZ, single-region, and DR deferred remain as decided in ADR-7.

### Enforcement core and bypass proof

ADR-7 and active ADR-12 specify a Rust core with Cedar's native crate and a
Phase-1 serverless shape. PR #2's TypeScript core is a throwaway spike.
`CORE-001` through `CORE-005` target Rust. The re-runnable bypass suite is the
migration guarantee for any future implementation change. T0 remains
review-only.
<!-- internal-only:start -->
The bypass suite is not green and is the first technical priority; this document
does not infer a completion percentage.
<!-- internal-only:end -->

### Research

The ICAIL 2026 relevance map is present. The fact pack also records a DEPLOY-5
workshop rebuttal submission, an ICLR 2026 poster, and workshop-review activity.
Those claims should be linked to their primary artifacts when synced.

<!-- internal-only:start -->
## Internal-only appendix

### Research credibility candor

Independent citation evidence is currently limited; self-published Zenodo
preprints dominate the reported footprint. Treat independent validation and
third-party citation growth as a remediation line, not as an externally promoted
claim.

### Internal reconciliation note

The Rust/TypeScript drift is resolved by ADR-12 and DECI-0006. Rust ramp must not
stall the enforcement proof; TS-now/Rust-later remains a recorded, unchosen
fallback protected by the re-runnable suite.
<!-- internal-only:end -->

<!-- internal-only:start -->
## Open decisions and human gates

### Resolved founder decisions

| FND | Resolution | Record | State |
|---|---|---|---|
| FND-1 | Current phase is Phase 1; Phase 0 signal test not formally run | [DECI-0002](../decisions/DECI-0002-current-phase.md) | **Resolved** |
| FND-2 | Evidence table via CFN-001; no inferred Foundation percentage | [DECI-0003](../decisions/DECI-0003-foundation-state-method.md) | **Resolved** |
| FND-3 | Durable ownership is by role | [DECI-0004](../decisions/DECI-0004-role-ownership.md) | **Resolved** |
| FND-4 | Phase-linked P0–P3 ranking and scope-derived Epic DoD | [DECI-0005](../decisions/DECI-0005-phase-linked-priority.md) | **Resolved** |
| FND-5 | Capability token; native runtime check; Rust now | [DECI-0006](../decisions/DECI-0006-enforcement-architecture-sequence.md) | **Resolved** |
| FND-7 | Semgrep, CodeQL, and cargo-deny; independent human review plus founder SAST sign-off | [DECI-0011](../decisions/DECI-0011-validation-stack-and-sast-gate.md) | **Resolved** |

### Remaining open decisions

| FND | Decision | State |
|---|---|---|
| FND-6 | Demo scenario and first non-payment action | **Open** |
| FND-8 | Open-core and Phase-3 business gates | **Open** |
| FND-9 | Role materials and external allowlist width | **Open** |
| FND-10 | AWS permission sets and deploy boundary | **Open** |
| FND-11 | Authoritative missing sources | **Open** |

| Decision | Owner | Blocked on | Gate | State |
|---|---|---|---|---|
| Orchestration: Paperclip vs AgentCore-native | Founder | Operating model comparison | Founder architecture/tooling decision | `{FOUNDER-SUPPLY: state}` |
| Deploy Step 3d | Founder | Deployment evidence and rollback readiness | Founder deploy approval | `{FOUNDER-SUPPLY: state}` |
| Demo scenario: spend hero + one non-payment action | Founder | Select second action class | Founder locks demo scope | `{FOUNDER-SUPPLY: state}` |
| Phase-0 pass/fail numbers | Founder | Phase 0 was exited under DECI-0002 | Explicitly deferred; no retrospective threshold invented | Deferred |
| SAST trio + review model | Founder + independent human reviewer | Semgrep, CodeQL, cargo-deny, cross-model, and adversarial evidence | Independent human reviews T0; founder adjudicates SAST and signs off | Resolved by DECI-0011 |
| Open-core paid boundary | Founder | Product and adoption evidence | Founder business-model decision | `{FOUNDER-SUPPLY: state}` |
| Phase 2→3 capital trigger | Founder | Phase-2 evidence | Founder capital gate | `{FOUNDER-SUPPLY: state}` |
| Phase-3 p99 latency, pricing, and SOC 2 timing | Founder | Enterprise evidence and economics | Founder enterprise-readiness gate | `{FOUNDER-SUPPLY: state}` |
| First non-payment action class | Founder | Buyer/demo evidence | Founder product-scope decision | `{FOUNDER-SUPPLY: state}` |

Recently settled: the organization is **DGR-AI-Labs**, the domain is
**decision-grade.com**, the monorepo is **dgr-core**, and DGR expands to
**Decision Governance Runtime**.
<!-- internal-only:end -->

*As of `{AS_OF_DATE}` · source commit `{SOURCE_COMMIT}`.*
