---
id: DECI-0011
type: DECI
status: active
supersedes: []
superseded-by: null
owner: Founder
last-reviewed: 2026-08-16
relates-to:
  - FND-7
  - VAL-001
  - CORE-002
---

# DECI-0011 — Validation stack and SAST gate

## Context

FND-7 owns the validation-stack decision that gates VAL-001 and T0 review.
Semgrep and CodeQL already cover first-party Rust code. The remaining material
risk surface is the locked Rust dependency graph, including the cryptographic
and SQLite supply chain.

The program has advanced from Phase 0 to Phase 1 under DECI-0002. No
retrospective numeric Phase-0 signal-test threshold is invented. That portion
of the original FND-7 wording is explicitly deferred; the enforceable
thresholds below govern the active Phase-1 validation gate.

## Decision

The three-engine gate for the Rust enforcement core is:

1. **Semgrep** for pattern-based first-party code analysis;
2. **CodeQL** for first-party code dataflow and taint analysis; and
3. **cargo-deny** for the dependency and supply-chain surface: RustSec
   advisories, license policy, dependency bans, and source policy.

Clippy remains a standard build gate and is not counted again as a SAST
engine. cargo-audit remains an advisory-only fallback if cargo-deny's broader
policy configuration becomes operationally unworkable. JavaScript mutation
testing is outside this Rust gate.

## Threshold and evidence semantics

- A tool execution error, extraction error, incomplete target coverage, or
  missing raw artifact blocks the gate.
- Each artifact identifies the full scanned commit, tool version, command,
  exit code, coverage or target count where available, and raw results.
- Findings are not auto-waived. Advisory, license, source, and ban-policy
  findings are blocking until fixed or explicitly excepted with a founder-
  approved reason.
- “No findings” is not self-certifying. The gate passes only after the raw
  outputs and any dispositions are reviewed and signed off.
- Narrow dependency exceptions are version-pinned, reasoned, and remain
  visible to cargo-deny; broad silent skips are not acceptable.

## Reviewer model

The T0 writer cannot be the sole human code reviewer. An independent human
reviews the founder-authored T0 change, while the founder owns final gate
sign-off and adjudicates the three raw SAST outputs. Cross-model review and
adversarial tests remain separate required evidence and do not replace human
review.

The trusted networked environment runs the tools and captures their raw
outputs. An offline agent may index and verify those artifacts against the
scanned commit, but may not fabricate, infer, or silently replace missing
tool evidence.

## Consequences

- VAL-001 must replace its disabled third-engine placeholder with cargo-deny
  and encode the reviewed license, source, and ban policy.
- A cargo-deny policy pass does not erase notes or exceptions; the human gate
  reviews them.
- CORE-002 may count the three named engines only when all three outputs cover
  the same reviewed artifact and their findings have explicit dispositions.
- This decision selects and governs validation tools. It authors no T0
  enforcement logic and changes no deployment authority.

## Founder gate

The founder confirms cargo-deny as engine three, the fail-closed evidence
thresholds, the independent-human-review requirement, and the final founder
sign-off model before merge.
