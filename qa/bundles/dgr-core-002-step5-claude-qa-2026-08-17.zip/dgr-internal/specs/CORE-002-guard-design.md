---
id: SPEC-CORE-002-GUARD-DESIGN
type: SPEC
status: active
supersedes: []
superseded-by: null
owner: Founder + Engineering
last-reviewed: 2026-08-16
relates-to:
  - CORE-002
---

# CORE-002 guard design

## Boundary

This note records the settled CORE-002 design. It does not implement or
authorize implementation of the guard. All five enforcement units below are
T0 and `{FOUNDER-AUTHORS}`. Agents may review them after founder authorship;
agents must not write or modify them.

The token and trust-root choices are fixed by
[ADR-10](../../adr/adr-10/index.md) and
[DECI-0010](../../deci/deci-0010/index.md). The review criteria are
[HOWTO-CORE-002-GUARD-REVIEW](../../howto/howto-core-002-guard-review/index.md).

## Five founder-authored units

| Unit | Recorded responsibility |
|---|---|
| Token verification | Verify the Class C action-instance token against the K2 guard-local trust store, time constraints, typed action binding, and consumption state. |
| Guard decision | Return Allow only when every required check and persistence obligation has completed; otherwise do not return Allow. |
| Fail-closed mapping | Map absence, invalidity, disabled/unavailable guard state, error, panic, or unreachable dependency to deny, never Allow. |
| S2 consumption store | Provide durable-local, atomic single-use consumption that survives restart. |
| `ConsumptionStore` interface | Preserve the boundary through which S2 is used now and S3 distributed consumption can be supplied at the hosted tier. |

The table is an ownership and responsibility record, not function bodies,
signatures, algorithms, or implementation guidance.

## Token and trust model

- Token scope is Class C: one action-instance capability minted per decision.
- Binding is Option 2: a typed schema per tool. The token commits to
  `hash(typed authorization-relevant fields)`; the guard recomputes the hash
  and never trusts a client-supplied hash.
- Money is represented as a decimal string, identifiers are normalized, and
  bound fields contain no floats.
- Replay is B4 single-use through S2 durable-local consumption in CORE-002.
- K2 is a small pinned verifying-key set in a guard-local trust store. The
  token's `key_id` selects a key; an unknown ID denies; the agent never
  supplies key material.
- T2 uses the guard-local host clock under the assumption that host time is
  outside agent control. Token lifetime is 300 seconds and deliberate
  clock-skew tolerance is 30 seconds.

Because B4 consumption is the replay defense, clock failure fails safe toward
false denial rather than permitted replay.

## Replay-protection scope

CORE-002's S2 guarantee is durable-local single-use consumption for one guard
deployment and its local store. A consumed authorization remains consumed
across process restarts only when the restarted guard reopens the same
file-backed SQLite database. The in-memory store used by the ATK-03 fixture
proves single-use behavior within one live store instance; it does not prove
restart durability.

S2 does not coordinate separate guard deployments or separate local
databases. The same nonce presented concurrently to two such instances can be
consumed once by each instance. Cross-instance replay protection therefore
remains deferred to S3 distributed consumption at the hosted tier, under the
same hosted trigger as VAL-ATK15/ATK-15 and K3 runtime key authority. Until S3
is implemented and validated, ATK-03 evidence must be described as local-only
and must not be cited as proof of cross-instance exactly-once enforcement.

## Persist then allow

For an otherwise valid allow candidate, the S2 store performs a durable,
atomic consume before the guard can return Allow. The ordering property is:

1. complete every required verification check;
2. atomically consume the single-use authorization in durable-local storage;
3. establish that the consume is durable; and only then
4. return Allow.

A crash before durable consumption cannot return Allow. A crash after durable
consumption but before tool execution can deny an action that might otherwise
have proceeded, but it cannot permit token replay. The failure direction is
denied-action, never permitted-replay.

This is the CORE-002 coupling to ATK-13's record-before-allow contract: if the
required consume/record cannot be made durable, no authorization leaves the
boundary and the action does not execute.

## Deferred interfaces and scoped assumptions

- S3 distributed consumption is deferred to the hosted tier under the
  VAL-ATK15/ATK-15 and K3 trigger; only its `ConsumptionStore` interface
  boundary is retained now.
- K3 runtime key authority is deferred to the hosted tier.
- The developer tier assumes the host clock is outside agent control.
- The developer tier assumes the agent cannot tamper with the S2 store.
- Operator disable remains out of scope at the developer tier per DECI-0008.

These are scoped-not-solved boundaries. They must not be promoted into hosted,
operator-proof, or multi-instance claims.
