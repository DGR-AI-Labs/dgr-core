#!/usr/bin/env python3
"""Offline verification for the standalone DGR backlog."""

from __future__ import annotations

import csv
import datetime
import json
import re
import subprocess
import sys
import os
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from pm.epic_status import derive_epic_statuses, materialize_epic_statuses

FIELDS = {
    "id", "title", "type", "epic", "priority", "size", "owner-role", "status",
    "prerequisites", "context", "acceptance-criteria", "definition-of-done",
    "human-gate", "dependencies", "links", "tags",
}


class Links(HTMLParser):
    def __init__(self) -> None:
        super().__init__(); self.ids: set[str] = set(); self.hrefs: list[str] = []
    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        values = dict(attrs)
        if values.get("id"): self.ids.add(str(values["id"]))
        if tag == "a" and values.get("href"): self.hrefs.append(str(values["href"]))


def run(*args: str) -> None:
    subprocess.run(args, cwd=ROOT, check=True)


def html_links(directory: Path) -> list[str]:
    broken = []
    for page in directory.rglob("*.html"):
        parser = Links(); parser.feed(page.read_text(encoding="utf-8"))
        for href in parser.hrefs:
            if href.startswith("#") and href[1:] not in parser.ids:
                broken.append(f"{page}: {href}")
            elif href.startswith(("http://", "https://")):
                continue
            elif not href.startswith("#"):
                target = (page.parent / href.split("#", 1)[0]).resolve()
                if target.is_dir():
                    target = target / "index.html"
                if not target.is_file():
                    broken.append(f"{page}: {href}")
    return broken


def main() -> None:
    run(sys.executable, "-m", "json.tool", "snapshot/roles.json")
    run(
        sys.executable,
        "-m",
        "py_compile",
        "snapshot/build.py",
        "pm/build_catalog.py",
        "pm/build_top_priorities.py",
        "pm/epic_status.py",
        "qa/build_backlog_reconciliation_bundle.py",
    )
    run(sys.executable, "pm/build_catalog.py")
    run(sys.executable, "snapshot/build.py", "--share-level", "external",
        "--allowlist", "snapshot/allowlist.txt", "--output", "snapshot/preview-external")
    run(sys.executable, "snapshot/build.py", "--share-level", "internal",
        "--allowlist", "snapshot/allowlist-internal.txt", "--output", "snapshot/preview")
    items = json.loads((ROOT / "pm/items.json").read_text(encoding="utf-8"))
    roles = json.loads((ROOT / "snapshot/roles.json").read_text(encoding="utf-8"))["roles"]
    refs = json.loads((ROOT / "reference/reference-index.lock.json").read_text(encoding="utf-8"))
    ids = {item["id"] for item in items}; ref_by_id = {entry["id"]: entry for entry in refs}
    errors: list[str] = []
    for item in items:
        if set(item) != FIELDS: errors.append(f"{item.get('id')}: fields")
        if not item["acceptance-criteria"] or not item["definition-of-done"] or not item["prerequisites"]:
            errors.append(f"{item['id']}: missing work contract")
        for ref_id in item["prerequisites"]:
            if ref_id not in ref_by_id: errors.append(f"{item['id']}: dangling {ref_id}")
            elif ref_by_id[ref_id]["status"] == "superseded":
                errors.append(f"{item['id']}: superseded {ref_id}")
        for dep in item["dependencies"]:
            if dep not in ids: errors.append(f"{item['id']}: missing dependency {dep}")
        if not isinstance(item["tags"], list): errors.append(f"{item['id']}: tags not list")
    epic_expectations = {
        "EPIC-STR": (
            "Sales / Product", "P3",
            "All child items are Done and Phase 1 adoption evidence and GTM materials are ready for founder advance-gate review.",
        ),
        "EPIC-ARCH": (
            "Engineering", "P1",
            "All child items are Done and the active Phase 1 ADR set supports the Rust enforcement proof without an unresolved architecture contradiction.",
        ),
        "EPIC-CFN": (
            "Engineering", "P3",
            "All child items are Done and the Phase 1 dev-local and audit boundary is evidenced, with remaining foundation scope explicitly deferred to Phase 3.",
        ),
        "EPIC-CORE": (
            "Engineering", "P0",
            "All child items are Done and the bypass suite is green inline and wired as a permanent CI gate.",
        ),
        "EPIC-POL": (
            "Product (with Engineering)", "P2",
            "All child items are Done and the Cedar policy/evidence contract supports the founder-selected Phase 1 demo.",
        ),
        "EPIC-VAL": (
            "Engineering", "P1",
            "All child items are Done and the bypass suite plus required deterministic validation checks are enforced as green CI gates.",
        ),
        "EPIC-RES": (
            "Product", "P3",
            "All child items are Done and Phase 1 research claims are linked to primary evidence with the citation-remediation plan active.",
        ),
        "EPIC-TOOL": (
            "Engineering", "P2",
            "All child items are Done and the Phase 1 developer workflow can rebuild, test, and operate the Rust enforcement proof.",
        ),
    }
    by_id = {item["id"]: item for item in items}
    expected_epic_statuses = {
        "EPIC-STR": "Blocked",
        "EPIC-ARCH": "Blocked",
        "EPIC-CFN": "In Progress",
        "EPIC-CORE": "In Progress",
        "EPIC-POL": "Blocked",
        "EPIC-VAL": "Blocked",
        "EPIC-RES": "To Do",
        "EPIC-TOOL": "In Progress",
        "EPIC-FND": "Blocked",
        "EPIC-BKO": "Blocked",
        "EPIC-RUNTIME-INTEGRATION": "Deferred",
    }
    derived_epic_statuses = derive_epic_statuses(items)
    if derived_epic_statuses != expected_epic_statuses:
        errors.append("derived Epic status rollup")
    for epic_id in expected_epic_statuses:
        expected_stored_status = (
            "Deferred" if epic_id == "EPIC-RUNTIME-INTEGRATION" else "derived"
        )
        if by_id[epic_id]["status"] != expected_stored_status:
            errors.append(f"{epic_id}: stored status must be {expected_stored_status}")
        if "{FOUNDER-SUPPLY:" in str(by_id[epic_id]["status"]):
            errors.append(f"{epic_id}: status token")
    for epic_id, (owner, priority, dod) in epic_expectations.items():
        epic_item = by_id[epic_id]
        if (
            epic_item["owner-role"] != owner
            or epic_item["priority"] != priority
            or epic_item["definition-of-done"] != dod
        ):
            errors.append(f"{epic_id}: owner/priority/DoD resolution")
        if any(
            "{FOUNDER-SUPPLY:" in str(epic_item[field])
            for field in ("owner-role", "priority", "definition-of-done")
        ):
            errors.append(f"{epic_id}: unresolved FND-3/FND-4 field")
    for number in range(1, 6):
        fnd = by_id[f"FND-{number}"]
        expected_deci = f"DECI-000{number + 1}"
        if fnd["status"] != "Done" or expected_deci not in fnd["links"]:
            errors.append(f"FND-{number}: not Done/link missing")
        if expected_deci not in ref_by_id:
            errors.append(f"FND-{number}: DECI absent from lock")
    for number in (6, 8, 9, 10, 11, 12):
        if by_id[f"FND-{number}"]["status"] != "To Do":
            errors.append(f"FND-{number}: should remain To Do")
    if (
        by_id["FND-7"]["status"] != "Done"
        or "DECI-0011" not in by_id["FND-7"]["links"]
        or "DECI-0011" not in ref_by_id
    ):
        errors.append("FND-7: validation-stack decision should be Done and linked")
    for number in range(13, 16):
        if by_id[f"FND-{number}"]["status"] != "Done":
            errors.append(f"FND-{number}: evidence-backed decision should be Done")
    for number in range(1, 6):
        bko = by_id[f"BKO-{number:03d}"]
        if (
            bko["priority"] != "{FOUNDER-SUPPLY: migrated priority}"
            or bko["status"] != "{FOUNDER-SUPPLY: migrated status}"
            or bko["definition-of-done"]
            != "{FOUNDER-SUPPLY: migrated Definition of Done confirmation}"
        ):
            errors.append(f"{bko['id']}: invented migrated value")
        if bko["human-gate"] != "FND-12" or "FND-12" not in bko["links"]:
            errors.append(f"{bko['id']}: missing FND-12 gate")
    token_count = len(
        re.findall(
            r"\{FOUNDER-SUPPLY:[^}]+\}",
            (ROOT / "pm/items.json").read_text(encoding="utf-8"),
        )
    )
    if token_count != 26:
        errors.append(f"unexpected source token count: {token_count}")
    for number in range(1, 6):
        core = by_id[f"CORE-{number:03d}"]
        if "Rust" not in core["context"]:
            errors.append(f"CORE-{number:03d}: Rust annotation missing")
    if by_id["CORE-001"]["status"] != "Done":
        errors.append("CORE-001: published attack contract should be Done")
    if (
        by_id["ARCH-003"]["status"] != "Done"
        or "HOWTO-CORE-002-GUARD-AUTHORING" not in by_id["ARCH-003"]["links"]
    ):
        errors.append("ARCH-003: completed CORE-002 authoring package")
    if by_id["ARCH-004"]["status"] != "Done":
        errors.append("ARCH-004: merged clean scaffold should be Done")
    if (
        by_id["CORE-002"]["status"] != "In Progress"
        or set(by_id["CORE-002"]["dependencies"])
        != {"CORE-001", "ARCH-004", "ARCH-005", "ARCH-006", "TOOL-002", "VAL-002"}
        or not {"FND-13", "FND-14", "FND-15"}.issubset(
            set(re.findall(r"\bFND-\d+\b", str(by_id["CORE-002"]["human-gate"])))
        )
    ):
        errors.append("CORE-002: in-progress state or settled dependencies not represented")
    expected_step_statuses = {
        "CORE-002-STEP1": "Done",
        "CORE-002-STEP2": "Done",
        "CORE-002-STEP3": "Done",
        "CORE-002-STEP3-PIECE1": "Done",
        "CORE-002-STEP3-PIECE2": "Done",
        "CORE-002-STEP4": "Done",
        "CORE-002-STEP5": "In Review",
    }
    for item_id, expected_status in expected_step_statuses.items():
        if item_id not in by_id or by_id[item_id]["status"] != expected_status:
            errors.append(f"{item_id}: expected {expected_status}")
    step_5 = by_id["CORE-002-STEP5"]
    if (
        "DECI-0011" not in step_5["prerequisites"]
        or "sast-evidence-complete" not in step_5["tags"]
        or "independent human" not in step_5["human-gate"].lower()
        or "founder final sign-off" not in step_5["human-gate"].lower()
    ):
        errors.append("CORE-002-STEP5: final SAST evidence or remaining human gate missing")
    val_001 = by_id["VAL-001"]
    if (
        "DECI-0011" not in val_001["prerequisites"]
        or "cargo-deny" not in val_001["context"]
        or "FND-7" == val_001["human-gate"]
    ):
        errors.append("VAL-001: selected cargo-deny gate not represented")
    if (
        by_id.get("CORE-002-STEP3-PIECE1", {}).get("dependencies")
        != ["CORE-002-STEP2", "VAL-002"]
        or by_id.get("CORE-002-STEP3-PIECE2", {}).get("dependencies")
        != ["CORE-002-STEP3-PIECE1", "VAL-002"]
    ):
        errors.append("CORE-002-STEP3: two-piece dependency chain is not represented")
    if "CORE-002-STEP1" in by_id and not {
        "https://github.com/DGR-AI-Labs/dgr-core/pull/62",
        "https://github.com/DGR-AI-Labs/dgr-core/commit/5db7743897a08fdd9aa1fb5eb7c212c69e81b47e",
    }.issubset(set(by_id["CORE-002-STEP1"]["links"])):
        errors.append("CORE-002-STEP1: merged PR/commit evidence missing")
    if "CORE-002-STEP2" in by_id and not {
        "https://github.com/DGR-AI-Labs/dgr-core/pull/63",
        "https://github.com/DGR-AI-Labs/dgr-core/commit/fb7eefe24baf34279ef3ef8418562d41cb930cd4",
    }.issubset(set(by_id["CORE-002-STEP2"]["links"])):
        errors.append("CORE-002-STEP2: PR/commit evidence missing")
    step_3_evidence = {
        "https://github.com/DGR-AI-Labs/dgr-core/pull/64",
        "https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5",
    }
    for item_id in (
        "CORE-002-STEP3",
        "CORE-002-STEP3-PIECE1",
        "CORE-002-STEP3-PIECE2",
    ):
        if item_id in by_id and not step_3_evidence.issubset(set(by_id[item_id]["links"])):
            errors.append(f"{item_id}: merged PR/commit evidence missing")
    step_4_evidence = {
        "https://github.com/DGR-AI-Labs/dgr-core/pull/67",
        "https://github.com/DGR-AI-Labs/dgr-core/commit/418beb638351dfb317797939b1c7083d42340e1a",
    }
    if not step_4_evidence.issubset(set(by_id["CORE-002-STEP4"]["links"])):
        errors.append("CORE-002-STEP4: PR/commit evidence missing")
    for item_id in ("ARCH-004", "ARCH-005", "ARCH-006", "TOOL-002", "VAL-002", "FND-13", "FND-14", "FND-15"):
        if item_id not in by_id:
            errors.append(f"{item_id}: missing readiness work item")
    if by_id["TOOL-002"]["status"] != "Done":
        errors.append("TOOL-002: merged dependency pins should be Done")
    if (
        by_id["VAL-002"]["status"] != "Done"
        or "https://github.com/DGR-AI-Labs/dgr-core/pull/61" not in by_id["VAL-002"]["links"]
    ):
        errors.append("VAL-002: merged fixture evidence should be Done and linked")
    if by_id["ARCH-005"]["status"] != "Done" or by_id["ARCH-006"]["status"] != "Done":
        errors.append("ARCH-005/006: merged and published specs should be Done")
    normalization_id = "ARCH-005-APPENDIX-B-NORMALIZATION"
    normalization = by_id.get(normalization_id)
    if normalization is None:
        errors.append(f"{normalization_id}: deferred lockstep item missing")
    elif (
        normalization["status"] != "Deferred"
        or normalization["dependencies"] != ["CORE-002-STEP4"]
        or not {"deferred", "arch-005", "normalization", "binding-follow-up"}.issubset(
            set(normalization["tags"])
        )
        or not str(normalization["definition-of-done"]).startswith("{FOUNDER-SUPPLY:")
    ):
        errors.append(f"{normalization_id}: deferred lockstep contract")
    runtime_ids = {
        "EPIC-RUNTIME-INTEGRATION",
        "RUNTIME-001",
        "RUNTIME-002",
        "RUNTIME-003",
        "RUNTIME-004",
        "RUNTIME-005",
    }
    if not runtime_ids.issubset(ids):
        errors.append("runtime integration: deferred epic or story missing")
    else:
        runtime_items = [by_id[item_id] for item_id in runtime_ids]
        if any(item["status"] != "Deferred" for item in runtime_items):
            errors.append("runtime integration: every item must remain Deferred")
        if any(
            not {"deferred", "phase-2-3", "runtime-integration"}.issubset(
                set(item["tags"])
            )
            for item in runtime_items
        ):
            errors.append("runtime integration: deferred Phase-2/3 tags missing")
        if by_id["EPIC-RUNTIME-INTEGRATION"]["dependencies"] != ["CORE-005"]:
            errors.append("runtime integration: bypass-suite-green trigger missing")
        for item_id in ("RUNTIME-001", "RUNTIME-002", "RUNTIME-003", "RUNTIME-004", "RUNTIME-005"):
            if not str(by_id[item_id]["definition-of-done"]).startswith(
                "{FOUNDER-SUPPLY:"
            ):
                errors.append(f"{item_id}: deferred Definition of Done was invented")
        if by_id["TOOL-001"]["status"] != "Deferred":
            errors.append("TOOL-001: orchestration dependency must remain deferred")
    for item in items:
        if item["type"] != "Epic" and item["status"] == "Done":
            if not any(str(link).startswith(("http://", "https://")) for link in item["links"]):
                errors.append(f"{item['id']}: Done without commit/PR evidence link")
        if "unverified" in item["tags"] and item["status"] == "Done":
            errors.append(f"{item['id']}: unverified claim marked Done")
    for role in roles:
        for starter in role["starter_items"]:
            if starter not in ids: errors.append(f"{role['key']}: missing starter {starter}")
            else:
                item = next(value for value in items if value["id"] == starter)
                if item["status"] != "To Do" or not str(item["size"]).startswith(("S", "M")):
                    errors.append(f"{starter}: starter not startable")
        for material in role["materials"]:
            if material["layer"] == "reference" and material["reference_id"] not in ref_by_id:
                errors.append(f"{role['key']}: missing reference material")
            if material["layer"] == "backlog" and not (ROOT / material["path"]).is_file():
                errors.append(f"{role['key']}: missing backlog path")
    required_epics = {
        "Strategy & GTM", "Architecture & Specs", "Cloud Foundation",
        "Core Enforcement + Bypass Suite", "Policy Plane", "Validation & QA Gates",
        "Research & Credibility", "Developer Tooling",
    }
    for epic in required_epics:
        if not any(item["epic"] == epic and item["type"] != "Epic" for item in items):
            errors.append(f"{epic}: no leaf")
    for core_id in ("CORE-001", "CORE-002", "CORE-003", "CORE-004", "CORE-005"):
        if core_id not in ids: errors.append(f"{core_id}: absent")
    atk15 = by_id.get("VAL-ATK15")
    if not atk15:
        errors.append("VAL-ATK15: absent")
    elif (
        atk15["status"] != "To Do"
        or atk15["owner-role"] != "Engineering"
        or atk15["human-gate"]
        != "Founder — Phase 3 hosted tier, before first hosted/multi-tenant deployment"
        or "DECI-0008" not in atk15["links"]
        or "SPEC-CORE-001-ATTACK-SET" not in atk15["prerequisites"]
        or "before any hosted/multi-tenant deployment" not in atk15["definition-of-done"]
    ):
        errors.append("VAL-ATK15: hosted-IAM work contract")
    commits = {entry["source-commit"] for entry in refs}
    if len(commits) != 1 or not re.fullmatch(r"[0-9a-f]{40}", next(iter(commits), "")):
        errors.append("reference lock source commit")
    reference_site = Path(
        os.environ.get("REFERENCE_SITE_DIR", str(ROOT.parent / "dgr-internal/reference-preview"))
    )
    for entry in refs:
        if not entry.get("url"):
            errors.append(f"{entry['id']}: missing reference url")
        elif not (reference_site / entry["url"] / "index.html").is_file():
            errors.append(f"{entry['id']}: rendered reference page missing")
    external = json.loads((ROOT / "snapshot/preview-external/manifest.json").read_text())
    internal = json.loads((ROOT / "snapshot/preview/manifest.json").read_text())
    if not external["interim"] or external["shippable"]: errors.append("token gate")
    if internal["interim"] or not internal["shippable"]: errors.append("internal gate")
    broken_external = html_links(ROOT / "snapshot/preview-external")
    broken_internal = html_links(ROOT / "snapshot/preview")
    if broken_external or broken_internal: errors.append("broken HTML links")
    for directory in (ROOT / "snapshot/preview", ROOT / "snapshot/preview-external"):
        page = (directory / "index.html").read_text(encoding="utf-8")
        if page.count('class="kanban-column"') != 5: errors.append("kanban columns")
        if page.count("data-role=") < len(items): errors.append("filter data attributes")
        kanban = page.split('<div class="kanban">', 1)[1].split('</div></section>', 1)[0]
        deferred = page.split('<section id="deferred">', 1)[1]
        for item_id in runtime_ids | {"TOOL-001", normalization_id}:
            item_href = f'items/{item_id.lower()}/'
            if item_href in kanban:
                errors.append(f"{item_id}: deferred item leaked into active Kanban")
            if item_href not in deferred:
                errors.append(f"{item_id}: missing from Deferred / Backlog section")
        for item in items:
            if not (directory / "items" / item["id"].lower() / "index.html").is_file():
                errors.append(f"{item['id']}: missing detail page")
    with (ROOT / "snapshot/preview/tasks.csv").open(encoding="utf-8", newline="") as handle:
        rows = list(csv.DictReader(handle))
    if set(rows[0]) != FIELDS or len(rows) != len(items): errors.append("CSV contract")
    rendered_items = json.loads((ROOT / "snapshot/preview/tasks.json").read_text())
    if rendered_items != materialize_epic_statuses(items):
        errors.append("generated exports do not materialize Epic status")
    top_priorities = (ROOT / "pm" / "TOP-PRIORITIES.md").read_text(encoding="utf-8")
    if any(
        item_id in top_priorities
        for item_id in runtime_ids | {"TOOL-001", normalization_id}
    ):
        errors.append("deferred items leaked into TOP-PRIORITIES")
    if errors:
        print("\n".join(errors), file=sys.stderr); raise SystemExit(1)
    report = [
        "# Role Actionability Verification",
        "",
        f"**Generated:** {datetime.date.today().isoformat()}",
        "",
        f"- Work items: **{len(items)}**",
        f"- Role starter items: **{sum(len(role['starter_items']) for role in roles)}**",
        f"- Reference IDs locked: **{len(refs)}**",
        f"- Reference source commit: `{next(iter(commits))}`",
        "- Eight workstream Epics have startable S/M leaf items: **PASS**",
        "- CORE-001 through CORE-005 present: **PASS**",
        "- VAL-ATK15 live hosted-IAM pre-deployment trigger: **PASS**",
        "- Prerequisites resolve offline and are not superseded: **PASS**",
        "- One-way contract: prerequisites contain reference IDs, not cross-repo paths: **PASS**",
        "- Structured CSV/JSON export contract: **PASS**",
        f"- External token gate: **PASS** (`{external['unresolved-founder-supply-count']}` rendered tokens; not shippable)",
        "- External redaction scan: **PASS**",
        "- External/internal HTML broken links: **0**",
        "- Per-item pages, full-field cards, kanban, and filter attributes: **PASS**",
        "- Role material and generated export paths: **PASS**",
        "- T0 implementation files: **not present or modified in this repository**",
        "- AWS/network/deploy/publish actions: **none**",
        "",
    ]
    (ROOT / "qa/role-actionability-report.md").write_text("\n".join(report), encoding="utf-8")
    fnd_report = [
        "# FND-1 through FND-5 verification — backlog", "",
        "- Eight workstream Epic owners/priorities/DoDs resolved: **PASS**",
        "- CORE-001 through CORE-005 annotated Rust: **PASS**",
        "- FND-1 through FND-5 Done with live DECI links: **PASS**",
        "- FND-7 is Done via DECI-0011; FND-6 and FND-8 through FND-12 remain To Do; FND-13 through FND-15 are evidence-backed Done: **PASS**",
        f"- Reference records pinned: **{len(refs)}**",
        "- T0 modified: **no**",
        "- Result: **PASS**",
        "",
    ]
    (ROOT / "qa/fnd-1-5-report.md").write_text("\n".join(fnd_report), encoding="utf-8")
    print("\n".join(report))


if __name__ == "__main__":
    main()
