#!/usr/bin/env python3
"""Generate structured DGR backlog sources and human-readable Markdown."""

from __future__ import annotations

import json
from pathlib import Path

from epic_status import materialize_epic_statuses

ROOT = Path(__file__).resolve().parent.parent


def codecommit_commit(repository: str, region: str, commit: str) -> str:
    return (
        f"https://{region}.console.aws.amazon.com/codesuite/codecommit/repositories/"
        f"{repository}/commit/{commit}?region={region}"
    )


def codecommit_pr(repository: str, region: str, pull_request: str) -> str:
    return (
        f"https://{region}.console.aws.amazon.com/codesuite/codecommit/repositories/"
        f"{repository}/pull-requests/{pull_request}/details?region={region}"
    )

EPIC_RESOLUTIONS = {
    "EPIC-STR": {
        "owner": "Sales / Product", "priority": "P3",
        "dod": "All child items are Done and Phase 1 adoption evidence and GTM materials are ready for founder advance-gate review.",
    },
    "EPIC-ARCH": {
        "owner": "Engineering", "priority": "P1",
        "dod": "All child items are Done and the active Phase 1 ADR set supports the Rust enforcement proof without an unresolved architecture contradiction.",
    },
    "EPIC-CFN": {
        "owner": "Engineering", "priority": "P3",
        "dod": "All child items are Done and the Phase 1 dev-local and audit boundary is evidenced, with remaining foundation scope explicitly deferred to Phase 3.",
    },
    "EPIC-CORE": {
        "owner": "Engineering", "priority": "P0",
        "dod": "All child items are Done and the bypass suite is green inline and wired as a permanent CI gate.",
    },
    "EPIC-POL": {
        "owner": "Product (with Engineering)", "priority": "P2",
        "dod": "All child items are Done and the Cedar policy/evidence contract supports the founder-selected Phase 1 demo.",
    },
    "EPIC-VAL": {
        "owner": "Engineering", "priority": "P1",
        "dod": "All child items are Done and the bypass suite plus required deterministic validation checks are enforced as green CI gates.",
    },
    "EPIC-RES": {
        "owner": "Product", "priority": "P3",
        "dod": "All child items are Done and Phase 1 research claims are linked to primary evidence with the citation-remediation plan active.",
    },
    "EPIC-TOOL": {
        "owner": "Engineering", "priority": "P2",
        "dod": "All child items are Done and the Phase 1 developer workflow can rebuild, test, and operate the Rust enforcement proof.",
    },
}

EPIC_RESOLUTION_SOURCES = {
    epic_id: {
        "owner-role": "DECI-0004 § Decision",
        "priority": "DECI-0005 § Decision, priority bands",
        "definition-of-done": (
            "DECI-0005 § Decision, all-children-Done plus scope-derived "
            "Phase 1 gate condition"
        ),
    }
    for epic_id in EPIC_RESOLUTIONS
}


def work(
    item_id: str,
    title: str,
    item_type: str,
    epic: str,
    size: str,
    owner_role: str,
    status: str,
    prerequisites: list[str],
    context: str,
    acceptance: list[str],
    dod: str,
    human_gate: str = "None",
    dependencies: list[str] | None = None,
    links: list[str] | None = None,
    priority: str = "Unranked",
    tags: list[str] | None = None,
) -> dict[str, object]:
    return {
        "id": item_id,
        "title": title,
        "type": item_type,
        "epic": epic,
        "priority": priority,
        "size": size,
        "owner-role": owner_role,
        "status": status,
        "prerequisites": prerequisites,
        "context": context,
        "acceptance-criteria": acceptance,
        "definition-of-done": dod,
        "human-gate": human_gate,
        "dependencies": dependencies or [],
        "links": links or prerequisites,
        "tags": tags or [],
    }


def epic(item_id: str, title: str) -> dict[str, object]:
    resolution = EPIC_RESOLUTIONS.get(item_id)
    return work(
        item_id,
        title,
        "Epic",
        title,
        "L — child items must be S/M",
        resolution["owner"] if resolution else ("Founder" if item_id == "EPIC-FND" else "{FOUNDER-SUPPLY: owner-role}"),
        "derived",
        ["DECI-0004", "DECI-0005"] if resolution else ["DECI-0001"],
        "Portfolio workstream migrated from the DGR program map.",
        ["Every child item conforms to the work-item standard."],
        resolution["dod"] if resolution else "{FOUNDER-SUPPLY: Epic Definition of Done}",
        "None" if resolution else "FND-3 and FND-4",
        priority=resolution["priority"] if resolution else "{FOUNDER-SUPPLY: priority}",
    )


def main() -> None:
    if set(EPIC_RESOLUTIONS) != set(EPIC_RESOLUTION_SOURCES):
        raise SystemExit("every resolved workstream Epic must cite its DECI source")
    for epic_id, resolution in EPIC_RESOLUTIONS.items():
        if set(resolution) != {"owner", "priority", "dod"}:
            raise SystemExit(f"{epic_id}: incomplete FND-3/FND-4 propagation")
        if any("{FOUNDER-SUPPLY:" in value for value in resolution.values()):
            raise SystemExit(f"{epic_id}: unresolved FND-3/FND-4 field")

    items: list[dict[str, object]] = []
    workstreams = [
        ("EPIC-STR", "Strategy & GTM"),
        ("EPIC-ARCH", "Architecture & Specs"),
        ("EPIC-CFN", "Cloud Foundation"),
        ("EPIC-CORE", "Core Enforcement + Bypass Suite"),
        ("EPIC-POL", "Policy Plane"),
        ("EPIC-VAL", "Validation & QA Gates"),
        ("EPIC-RES", "Research & Credibility"),
        ("EPIC-TOOL", "Developer Tooling"),
    ]
    items.extend(epic(*entry) for entry in workstreams)

    items.extend(
        [
            work(
                "STR-001",
                "Draft phase and open-core options memo",
                "Task",
                "Strategy & GTM",
                "M",
                "Product manager",
                "To Do",
                ["GLOSSARY-DGR", "DECI-0001"],
                "Give the founder bounded options for phase sequence and the open-core paid boundary without deciding them.",
                [
                    "At least two options per decision are stated.",
                    "Evidence, tradeoffs, and reversible next steps are separated.",
                    "FND-1 and FND-8 are linked as human gates.",
                ],
                "Memo is reviewable, linked to FND-1/FND-8, and `make verify` is green.",
                "FND-1 and FND-8",
                links=["GLOSSARY-DGR", "DECI-0001"],
            ),
            work(
                "STR-002",
                "Draft trigger-qualified discovery guide",
                "Task",
                "Strategy & GTM",
                "M",
                "Sales / Business development",
                "To Do",
                ["GLOSSARY-DGR", "SPEC-POLICY-PLANE"],
                "Translate the existing buyer and policy-plane evidence into a repeatable discovery conversation.",
                [
                    "Guide distinguishes trigger, pain, current workaround, and required proof.",
                    "Questions do not promise unproven enforcement.",
                    "Beachhead confirmation remains a founder gate.",
                ],
                "A reviewer can run a mock discovery call from the guide and `make verify` is green.",
                "FND-6 and FND-8",
            ),
            work(
                "ARCH-001",
                "Author ADR-8 source/artifact-integrity stub",
                "Task",
                "Architecture & Specs",
                "M",
                "Engineering",
                "To Do",
                ["ADR-7", "DECI-0001"],
                "The fact pack describes ADR-8 but no authoritative source is cataloged.",
                [
                    "Context, options, tradeoffs, and required evidence are documented.",
                    "Decision remains `{FOUNDER-SUPPLY}`.",
                    "No T0 implementation is authored.",
                ],
                "Decision-open ADR stub passes reference validation and `make verify`.",
                "FND-11",
            ),
            work(
                "ARCH-002",
                "Author tenant-provisioning runbook stub",
                "Task",
                "Architecture & Specs",
                "M",
                "Engineering",
                "To Do",
                ["ADR-6", "HOWTO-FOUNDATION"],
                "The intended tenant runbook route is missing.",
                [
                    "Phases, prerequisites, human deploy gates, rollback, and validation slots are structured.",
                    "No live account state or deployment outcome is asserted.",
                    "Unknown source decisions link to FND-11.",
                ],
                "Runbook stub is reference-valid, reviewable, and `make verify` is green.",
                "FND-11",
            ),
            work(
                "ARCH-003",
                "Record the CORE-002 guard authoring package",
                "Task",
                "Architecture & Specs",
                "S",
                "Engineering",
                "Done",
                [
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                ],
                "The settled CORE-002 design, review checklist, and founder authoring sequence are published and pinned by stable reference ID; this documentation authored no T0 enforcement logic.",
                [
                    "Class C, Option 2, B4-S2, K2, and T2 are recorded consistently.",
                    "The 300-second lifetime and 30-second skew tolerance are explicit.",
                    "The five founder-authored units and review-only agent boundary are documented.",
                ],
                "The active reference catalog and backlog lock contain the complete CORE-002 design, review, and authoring package with no unresolved design token.",
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    codecommit_commit(
                        "dgr-internal", "us-west-2",
                        "f9e1801a499ec36df1a5e937c230c5438c77a603",
                    ),
                ],
            ),
            work(
                "ARCH-004",
                "Reconcile and publish the CORE-002 scaffold",
                "Task",
                "Architecture & Specs",
                "M",
                "Engineering",
                "Done",
                [
                    "SPEC-CORE-001-ATTACK-SET",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                ],
                "The clean Rust scaffold was merged by founder review in dgr-core PR #58. PR #2's TypeScript T0 draft is not in its ancestry; the five founder units remain fail-closed stubs.",
                [
                    "The FND-14 disposition is applied to the Rust and TypeScript surfaces without preserving conflicting enforcement paths.",
                    "The five founder-authored units are distinct from harness and fixture files and are listed in T0-AUTHORS.md.",
                    "The scaffold is pushed and reviewed through the repository's normal PR and human-merge path.",
                    "The Rust crate builds and ATK-01 remains actively red until the founder authors the guard.",
                ],
                "A reviewed scaffold is merged to current dgr-core main, the five-unit T0 boundary matches the settled design, and no agent-authored enforcement logic is present.",
                "Completed by founder merge",
                dependencies=["CORE-001", "ARCH-003"],
                links=[
                    "SPEC-CORE-001-ATTACK-SET",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/58",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/a68befb601505410193584622ae036f56aff686a",
                ],
            ),
            work(
                "ARCH-005",
                "Specify the first typed authorization schema and canonical form",
                "Task",
                "Architecture & Specs",
                "S",
                "Founder",
                "Done",
                [
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "ARCH-005-typed-authorization-schema",
                ],
                "The founder-approved schema is merged on dgr-internal main, cataloged as active, and published by the reference pipeline.",
                [
                    "The first conformance tool and every authorization-relevant request field are identified with explicit types.",
                    "Money is a decimal string, identifiers have one normalization rule, and no bound field is a float.",
                    "A deterministic canonical byte form is specified so independent implementations produce the same commitment.",
                    "The guard recomputes from the actual request; no client-supplied hash or excluded field can influence authorization.",
                ],
                "A founder-approved typed schema and canonical byte form are reviewable, fixture-ready, and sufficient for ATK-08/09/11 without authoring guard logic.",
                "Completed by founder merge",
                dependencies=["ARCH-004"],
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "ARCH-005-typed-authorization-schema",
                    codecommit_pr("dgr-internal", "us-west-2", "1"),
                    codecommit_commit(
                        "dgr-internal", "us-west-2",
                        "a563f388bca240ab94ddbf491582e58ac96f988f",
                    ),
                ],
            ),
            work(
                "ARCH-006",
                "Publish the capability-token wire format and signature preimage",
                "Task",
                "Architecture & Specs",
                "S",
                "Founder",
                "Done",
                ["ADR-10", "DECI-0010", "ARCH-006-token-wire-format"],
                "The founder-approved wire-format specification is merged on dgr-internal main, cataloged as active, and published by the reference pipeline.",
                [
                    "The fixed binary token layout, domain tag, key identifier, nonce, and transport encoding are explicit.",
                    "Every decision-relevant field is included in the frozen Ed25519 preimage.",
                    "The active spec is cataloged without authoring verification or guard logic.",
                ],
                "ARCH-006 is merged to dgr-internal main and remains cataloged as active for fixture and founder-guard consumers.",
                "Completed by founder merge",
                dependencies=["ARCH-004"],
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "ARCH-006-token-wire-format",
                    codecommit_pr("dgr-internal", "us-west-2", "1"),
                    codecommit_commit(
                        "dgr-internal", "us-west-2",
                        "a563f388bca240ab94ddbf491582e58ac96f988f",
                    ),
                ],
            ),
            work(
                "ARCH-007",
                "Record the disposition of the obsolete TypeScript Phase 1 draft",
                "Task",
                "Architecture & Specs",
                "S",
                "Engineering",
                "Done",
                ["ADR-12", "DECI-0006"],
                "GitHub PR #2 was closed without merge after ADR-12 selected Rust as canonical and PR #58 reconstructed a clean Rust scaffold without the TypeScript T0 ancestry.",
                [
                    "The obsolete PR is closed without merge.",
                    "The canonical Rust decision and clean-scaffold replacement are linked.",
                    "No code from the obsolete T0 draft is promoted to main.",
                ],
                "The obsolete draft is closed with a traceable disposition and the canonical replacement is merged.",
                links=[
                    "ADR-12",
                    "DECI-0006",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/2",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/58",
                ],
            ),
            work(
                "CFN-001",
                "Document current Foundation Part A state",
                "Task",
                "Cloud Foundation",
                "S",
                "Project manager",
                "To Do",
                ["HOWTO-FOUNDATION"],
                "The prior two-thirds claim conflicts with the observed control inventory.",
                [
                    "Every HOWTO step is marked evidenced, not evidenced, or unknown.",
                    "No percentage is inferred.",
                    "The resulting decision request links to FND-2.",
                ],
                "Evidence table is complete and ready for founder adjudication.",
                "FND-2",
            ),
            work(
                "CFN-002",
                "Prepare Deploy Step 3d checklist",
                "Task",
                "Cloud Foundation",
                "M",
                "Engineering",
                "To Do",
                ["HOWTO-FOUNDATION", "ADR-6", "ADR-7"],
                "Founder deployment needs a bounded, reviewable preflight and rollback checklist.",
                [
                    "Identity, change scope, validation, rollback, and evidence capture are listed.",
                    "Checklist performs no AWS action.",
                    "Founder approval is explicit.",
                ],
                "Checklist is dry-run reviewable and `make verify` is green.",
                "FND-10",
            ),
            work(
                "CFN-003",
                "Author the Cognito and Lambda@Edge private-site stack",
                "Task",
                "Cloud Foundation",
                "M",
                "Engineering",
                "Done",
                ["DECI-0007", "HOWTO-HOSTING-COGNITO-EDGE"],
                "The guarded Cognito, Lambda@Edge, origin, publication, and verification implementation is merged on dgr-internal main.",
                [
                    "The private-site infrastructure templates and edge-auth package are versioned.",
                    "The guarded publisher and offline verification path are versioned.",
                    "Deployment is not inferred from source implementation alone.",
                ],
                "The private-site implementation and operator HOWTO are merged to dgr-internal main with reviewable QA evidence.",
                links=[
                    "DECI-0007",
                    "HOWTO-HOSTING-COGNITO-EDGE",
                    codecommit_commit(
                        "dgr-internal", "us-west-2",
                        "62626b9009a12809bf463f3263ff90d9f8daab0a",
                    ),
                ],
            ),
            work(
                "CFN-004",
                "Confirm live deployment of the Cognito and Lambda@Edge private site",
                "Task",
                "Cloud Foundation",
                "S",
                "Founder",
                "To Do",
                ["DECI-0007", "HOWTO-HOSTING-COGNITO-EDGE"],
                "Claimed in the local hosting deployment report and reconciliation request; no committed main-branch deployment receipt or merged PR was found. This claim is unverified and is not Done.",
                [
                    "A committed deployment receipt identifies the reviewed stack, region, deployment time, and validation outcome.",
                    "The evidence distinguishes source implementation from a live deployment.",
                    "The founder confirms any live AWS state before the status changes.",
                ],
                "A founder-reviewed deployment receipt is merged and linked; until then the claim remains unverified.",
                "Founder confirms live deployment evidence",
                links=["DECI-0007", "HOWTO-HOSTING-COGNITO-EDGE"],
                tags=["unverified"],
            ),
            work(
                "CORE-001",
                "Define the bypass attack set",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Engineering",
                "Done",
                [
                    "SRS-07",
                    "ADR-7",
                    "ADR-12",
                    "DECI-0006",
                    "DECI-0008",
                    "SPEC-CORE-001-ATTACK-SET",
                ],
                "The Rust bypass attack contract for non-bypassability is published and reviewed. Operator-disable and hosted IAM execution remain explicitly scoped to their later gates.",
                [
                    "Direct tool call without token expects block.",
                    "Expired or replayed token expects deny.",
                    "Missing justification expects deny.",
                    "Ambiguous or insufficient evidence expects deny or escalation.",
                    "Approval timeout expects deny.",
                    "Hook throw expects deny.",
                ],
                "The published attack matrix is reviewed, contains the expected outcomes, is pinned by stable ID, and its deterministic validation is green.",
                links=[
                    "SRS-07",
                    "ADR-7",
                    "ADR-12",
                    "DECI-0006",
                    "DECI-0008",
                    "SPEC-CORE-001-ATTACK-SET",
                    codecommit_commit(
                        "dgr-internal", "us-west-2",
                        "7051fb34ee0ca783a4e4585f1cdca2bbe1f3b530",
                    ),
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/58",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-002",
                "Author and prove the CORE-002 inline guard",
                "Task",
                "Core Enforcement + Bypass Suite",
                "M",
                "Founder",
                "In Progress",
                [
                    "SRS-07",
                    "ADR-7",
                    "ADR-10",
                    "ADR-11",
                    "ADR-12",
                    "DECI-0006",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                ],
                "Founder-authored Rust T0 work is progressing against the settled OpenClaw before_tool_call design. Steps 1–4 are founder-merged. Step 5 is implemented on its review branch with S2 durable-local atomic consumption, restart evidence against the same SQLite file, explicit fail-closed fault mapping, and ATK-03/13 coverage. Cross-model review passed with documented errata against dgr-core commit 0727e32 and bundle SHA-256 74fad508dbdfe05d142af93ad610043157bddb8b2edd1b7085eb91367511be49; founder/human, three-tool SAST, PR, and merge gates remain pending.",
                [
                    "ATK-01 is green because an absent token denies before tool execution and every absence or internal error fails closed.",
                    "K2 key selection and Ed25519 verification make ATK-10 green; unknown key_id and client-supplied key material deny.",
                    "The guard enforces a 300-second lifetime with 30-second skew against its T2 clock and makes ATK-02 green.",
                    "The guard recomputes the typed per-tool request hash under the canonical rule and makes ATK-08, ATK-09, and ATK-11 green.",
                    "S2 atomically persists single-use consumption before Allow and makes ATK-03 green with record-before-allow ordering.",
                    "The full suite and line-mapped review checklist pass, and only the founder authored the five T0 units.",
                ],
                "ATK-01/02/03/08/09/10/11 and the applicable fail-closed regression pass against the founder-authored guard; cases deferred to later controls remain explicitly classified; and the checklist has reviewer-approved file-and-line evidence.",
                "FND-13, FND-14, and FND-15; Founder authors and reviews the five T0 units",
                dependencies=[
                    "CORE-001", "ARCH-004", "ARCH-005", "ARCH-006", "TOOL-002", "VAL-002",
                ],
                links=[
                    "SRS-07",
                    "ADR-7",
                    "ADR-10",
                    "ADR-11",
                    "ADR-12",
                    "DECI-0006",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/62",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/5db7743897a08fdd9aa1fb5eb7c212c69e81b47e",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/63",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/fb7eefe24baf34279ef3ef8418562d41cb930cd4",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/64",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/67",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/418beb638351dfb317797939b1c7083d42340e1a",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-002-STEP1",
                "Step 1 — deny on absent token (ATK-01)",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Founder",
                "Done",
                [
                    "SRS-07",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                ],
                "The founder-authored guard now blocks a direct effectful call when no capability token is present; PR #62 was founder-merged after ATK-01 and VAL-002 validation passed.",
                [
                    "An absent capability token returns Deny with RequiredOutcome::Block and the stable ATK-01 denial signal.",
                    "A present token returns FounderImplementationRequired while Steps 2–5 remain pending.",
                    "No path returns Allow, ATK-01 is green, and ATK-02 through ATK-15 remain ignored at this milestone.",
                ],
                "The founder-authored Step 1 change is merged, ATK-01 passes before tool execution, and the present-token path remains explicitly unimplemented.",
                "Completed by founder merge",
                dependencies=["CORE-001", "ARCH-004", "VAL-002"],
                links=[
                    "SRS-07",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-REVIEW",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/62",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/5db7743897a08fdd9aa1fb5eb7c212c69e81b47e",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-002-STEP2",
                "Step 2 — verify signature and pinned key (ATK-10)",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Founder",
                "Done",
                ["ADR-10", "DECI-0010", "SPEC-CORE-002-GUARD-DESIGN", "HOWTO-CORE-002-GUARD-AUTHORING"],
                "Founder-merged token verification selects the guard-local pinned K2 key by key_id and verifies Ed25519 over the transmitted ARCH-006 preimage. Real VAL-002 canaries make ATK-10 green with zero effectful invocations; PR #63 was founder-merged.",
                [
                    "K2 key selection and Ed25519 verification make ATK-10 green.",
                    "Unknown key_id and client-supplied key material deny.",
                    "No later check or Allow is reachable after verification failure.",
                ],
                "ATK-10 passes against founder-authored verification using the pinned key set, with unknown or unverifiable tokens denied.",
                "Completed by founder merge",
                dependencies=["CORE-002-STEP1", "TOOL-002", "VAL-002"],
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/63",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/fb7eefe24baf34279ef3ef8418562d41cb930cd4",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-002-STEP3",
                "Step 3 — enforce token lifetime (ATK-02)",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Founder",
                "Done",
                ["ADR-10", "DECI-0010", "SPEC-CORE-002-GUARD-DESIGN", "HOWTO-CORE-002-GUARD-AUTHORING"],
                "Founder-merged Step 3 threads the guard-local T2 clock through the decision boundary, then enforces the settled lifetime/skew rules and activates the ATK-02 proof. PR #64 merged both dependency-ordered pieces.",
                [
                    "Piece 1 threads a caller-supplied Unix timestamp through the guard interface, adapter, and all eight conformance call sites without changing the Step 2 decision behavior.",
                    "Piece 2 applies the settled 300-second token lifetime and 30-second skew, making expired tokens deny before tool execution.",
                    "The valid and expiry-boundary behavior is exercised by deterministic VAL-002 fixtures with zero effectful invocations.",
                ],
                "Both Step 3 pieces are founder-reviewed, ATK-02 and the deterministic lifetime/skew boundary fixtures pass, and the guard remains fail-closed before tool execution.",
                "Completed by founder merge",
                dependencies=["CORE-002-STEP2", "VAL-002"],
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/64",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-002-STEP3-PIECE1",
                "Step 3 Piece 1 — thread the guard-local clock",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Founder",
                "Done",
                ["ADR-10", "DECI-0010", "SPEC-CORE-002-GUARD-DESIGN", "HOWTO-CORE-002-GUARD-AUTHORING"],
                "The founder-merged Step 3 change on codex/core-002-step3-atk02 threads an explicit now_unix_seconds value through the decision interface and adapter before applying expiry math.",
                [
                    "GuardDecisionPort and BeforeToolCallAdapter accept and relay now_unix_seconds without deriving or interpreting time.",
                    "The VAL-002 observe helper uses fixture.clock.now_unix_seconds(); the other seven call sites use FIXED_NOW_UNIX_SECONDS.",
                    "The Verified arm remains FounderImplementationRequired, and formatting, all-target build, ATK-01, ATK-10, VAL-002, and adapter tests stay green.",
                ],
                "Clock plumbing compiles across every implementation and caller, the full existing suite is green, and no expiry decision or Allow path is introduced.",
                "Completed by founder merge",
                dependencies=["CORE-002-STEP2", "VAL-002"],
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/64",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-002-STEP3-PIECE2",
                "Step 3 Piece 2 — enforce lifetime and prove ATK-02",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Founder",
                "Done",
                ["ADR-10", "DECI-0010", "SPEC-CORE-002-GUARD-DESIGN", "HOWTO-CORE-002-GUARD-AUTHORING"],
                "Founder-merged guard logic applies the settled 300-second lifetime and 30-second skew to verified transmitted token fields and activates deterministic ATK-02 boundary, overlong-lifetime, and reversed-lifetime proofs.",
                [
                    "The guard applies the settled token-lifetime and skew rules only after signature verification succeeds.",
                    "The valid fixture and the token at the 30-second skew boundary reach FounderImplementationRequired; tokens expired by 120 seconds or 31 seconds deny.",
                    "ATK-02 boundary tests assert zero effectful invocations and leave the later Allow path unimplemented.",
                ],
                "ATK-02 and all deterministic valid, expired, and skew-boundary fixtures pass against the founder-authored guard with no effectful invocation.",
                "Completed by founder merge",
                dependencies=["CORE-002-STEP3-PIECE1", "VAL-002"],
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/64",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/8446dd5f8a645ab7512b7fc208e475c1f9df43c5",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-002-STEP4",
                "Step 4 — verify typed request binding (ATK-08/09/11)",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Founder",
                "Done",
                [
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "ARCH-005-typed-authorization-schema",
                    "ARCH-006-token-wire-format",
                ],
                "Founder-merged Step 4 recomputes the raw ARCH-005 six-field SHA-256 request commitment from the intercepted action after signature and temporal checks. Scope, substitution, parameter-swap, and malformed-amount fixtures deny with zero effectful invocations; matching and non-binding-only changes advance to FounderImplementationRequired, so Step 5 remains the only path to a future Allow.",
                [
                    "The guard recomputes the typed per-tool request hash under the canonical rule.",
                    "Scope escalation, token substitution, and parameter swap make ATK-08, ATK-09, and ATK-11 green by denying.",
                    "Excluded tool, idempotency-key, and memo fields do not influence the commitment, and no client-supplied commitment is trusted.",
                ],
                "ATK-08, ATK-09, and ATK-11 pass against the founder-authored canonical request-binding check.",
                "Completed by founder merge",
                dependencies=["CORE-002-STEP3", "ARCH-005", "ARCH-006", "VAL-002"],
                links=[
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "ARCH-005-typed-authorization-schema",
                    "ARCH-006-token-wire-format",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/67",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/418beb638351dfb317797939b1c7083d42340e1a",
                ],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "ARCH-005-APPENDIX-B-NORMALIZATION",
                "Adopt Appendix-B normalization across issuer, guard, and fixtures",
                "Task",
                "Architecture & Specs",
                "M",
                "Founder",
                "Deferred",
                ["ARCH-005-typed-authorization-schema"],
                "ARCH-005 Appendix-B normalization is deferred: the Step 4 canonicalizer currently binds raw strings. This is acceptable for the developer tier because raw-byte request binding already defeats the core scope-swap, token-substitution, and parameter-swap attacks. Before normalization-edge binding attacks can rely on NFC, case, or minor-unit normalization, the issuer, guard, and fixtures must adopt the same pinned rules in lockstep; changing only the guard would desynchronize minting and break valid tokens.",
                [
                    "Adopt one pinned Appendix-B normalization rule across the issuer, guard, and deterministic fixtures in the same evidence-linked change set.",
                    "Cover NFC, case, and minor-unit normalization edges without changing the six-field binding scope.",
                    "Keep existing valid-token golden vectors synchronized and prove normalization-edge binding attacks fail closed.",
                ],
                "{FOUNDER-SUPPLY: ARCH-005-APPENDIX-B-NORMALIZATION Definition of Done}",
                "Founder — activate and approve the lockstep issuer/guard/fixture migration before any one surface changes",
                dependencies=["CORE-002-STEP4"],
                links=["ARCH-005-typed-authorization-schema"],
                priority="Unranked",
                tags=["deferred", "arch-005", "normalization", "binding-follow-up"],
            ),
            work(
                "CORE-002-STEP5",
                "Step 5 — atomically consume authorization (ATK-03)",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Founder",
                "In Review",
                ["DECI-0010", "DECI-0011", "SPEC-CORE-002-GUARD-DESIGN", "HOWTO-CORE-002-GUARD-AUTHORING"],
                "Founder-authored Step 5 now performs atomic insert-if-absent consumption before Allow. The S2 guarantee is durable across process or connection restart only when the runtime reopens the same SQLite file; cross-process coordination through separate databases and distributed replay protection remain deferred S3 scope. Cross-model review passed with errata against dgr-core T0 commit 0727e327631b475990ef8d9b7ef3b2c3554050a8 and reviewed bundle SHA-256 74fad508dbdfe05d142af93ad610043157bddb8b2edd1b7085eb91367511be49. Semgrep, CodeQL, and cargo-deny then completed against non-Rust review/policy descendant 0a54d4995d1b9d98ab8a3ec61861fe2fe7ae29c3 with complete 14/14 Rust coverage for both code analyzers, no execution or extraction errors, one Semgrep finding, seven CodeQL fixture findings, and a passing cargo-deny policy result. No T0 Rust changed between the two commits. Draft dgr-core PR #68 is open for the remaining independent-human and founder gates.",
                [
                    "S2 atomically persists single-use consumption before Allow and a restart test reopens the same SQLite file.",
                    "A previously consumed authorization makes ATK-03 green by denying.",
                    "Store failure cannot produce Allow; explicit fault mapping and ATK-13 prove fail-closed behavior with zero effectful invocation.",
                    "Production construction must use the file-backed open_at path before claiming restart durability; separate database files are not coordinated in S2.",
                ],
                "ATK-03 and the applicable fail-closed regression pass against durable-local atomic consumption with restart evidence, record-before-allow ordering, and zero effectful invocation on store failure; required T0, cross-model, SAST, and human-review evidence is approved.",
                "Three-engine raw evidence is complete; founder finding dispositions, independent human T0 review, and founder final sign-off remain pending",
                dependencies=["CORE-002-STEP4", "TOOL-002", "VAL-002"],
                links=[
                    "DECI-0011",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/68",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/0727e327631b475990ef8d9b7ef3b2c3554050a8",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/0a54d4995d1b9d98ab8a3ec61861fe2fe7ae29c3",
                ],
                priority="P0 (source-stated first technical priority)",
                tags=["cross-model-reviewed", "sast-evidence-complete", "human-review-pending"],
            ),
            work(
                "CORE-003",
                "Fail-closed-on-hook-error test",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Engineering",
                "To Do",
                ["SRS-07", "ADR-12", "DECI-0006"],
                "In Rust, prove plugin and exception paths cannot fail open.",
                [
                    "The test forces the authorization hook to throw.",
                    "The observed result is deny.",
                    "The test is red for allow or continued execution.",
                ],
                "The forced-throw regression is deterministic and reviewer-approved.",
                dependencies=["CORE-001"],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-004",
                "Approval-timeout deny test",
                "Task",
                "Core Enforcement + Bypass Suite",
                "S",
                "Engineering",
                "To Do",
                ["SRS-07", "ADR-12", "DECI-0006"],
                "In Rust, prove unresolved human approval cannot become authorization.",
                [
                    "A pending approval is forced past its deadline.",
                    "The observed result is deny.",
                    "No downstream effect occurs.",
                ],
                "The timeout regression is deterministic and reviewer-approved.",
                dependencies=["CORE-001"],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "CORE-005",
                "Wire the bypass suite as a permanent CI gate",
                "Task",
                "Core Enforcement + Bypass Suite",
                "M",
                "Engineering",
                "To Do",
                ["SRS-07", "ADR-7", "ADR-12", "DECI-0006"],
                "Wire the Rust bypass proof so it is repeatable on every relevant change.",
                [
                    "CI runs the suite without network-dependent adjudication.",
                    "A seeded bypass makes the job fail.",
                    "Evidence and ownership are documented.",
                ],
                "CI is reproducibly red on a seeded bypass and green only when every case blocks as specified.",
                dependencies=["CORE-002", "CORE-003", "CORE-004"],
                priority="P0 (source-stated first technical priority)",
            ),
            work(
                "POL-001",
                "Draft starter Cedar policy and evidence schema",
                "Task",
                "Policy Plane",
                "M",
                "Product manager",
                "To Do",
                ["SPEC-POLICY-PLANE", "SRS-07"],
                "Define a reviewable demo policy without deciding the second action.",
                [
                    "One payment action and one placeholder non-payment class are represented.",
                    "Required evidence, freshness, deny, and escalation behavior are explicit.",
                    "The non-payment class remains gated by FND-6.",
                ],
                "Policy/schema draft type-checks or has a documented deterministic check and is reviewer-approved.",
                "FND-6",
            ),
            work(
                "VAL-001",
                "Scaffold SAST trio CI stubs",
                "Task",
                "Validation & QA Gates",
                "M",
                "Engineering",
                "To Do",
                ["SRS-07", "DECI-0011"],
                "Prepare Semgrep, CodeQL, and cargo-deny CI gates under the FND-7 validation and reviewer model.",
                [
                    "Semgrep and CodeQL jobs are structurally defined.",
                    "cargo-deny runs advisory, license, ban, and source policy checks from the committed deny.toml.",
                    "Tool execution errors, incomplete coverage, and missing raw artifacts fail closed.",
                    "Reviewer and writer roles cannot be the same in the documented gate.",
                ],
                "CI stubs validate syntactically and `make verify` is green.",
                "Independent human review and founder final SAST sign-off",
                links=["DECI-0011"],
            ),
            work(
                "VAL-002",
                "Prepare deterministic CORE-002 token fixtures",
                "Task",
                "Validation & QA Gates",
                "S",
                "Engineering",
                "Done",
                [
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "ARCH-005-typed-authorization-schema",
                    "ARCH-006-token-wire-format",
                ],
                "Founder-reviewed dgr-core PR #61 merged the deterministic fixture set at commit 48ee258. The fixtures remain support code and contain no enforcement logic.",
                [
                    "Fixtures represent a valid 300-second token, an expired token, and a token inside the 30-second skew band.",
                    "No-token, forged-signature, unknown-key, request-mismatch, and already-consumed cases are deterministic data.",
                    "Fixture requests use typed authorization-relevant fields, decimal-string money, normalized identifiers, and no bound floats.",
                    "The full cargo test command remains runnable and intended red or ignored cases are documented until their founder-authored step lands.",
                    "No fixture implements a guard decision, signature acceptance, or consumption outcome.",
                ],
                "The complete fixture set compiles, deterministically exercises the settled values through the harness, and contains no T0 enforcement logic.",
                dependencies=["ARCH-004", "ARCH-005", "ARCH-006", "TOOL-002"],
                links=[
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "ARCH-005-typed-authorization-schema",
                    "ARCH-006-token-wire-format",
                    codecommit_pr("dgr-internal", "us-west-2", "1"),
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/61",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/48ee25869fb2e3215505ba55dd7372aa586c998d",
                ],
            ),
            work(
                "VAL-ATK15",
                "Make ATK-15 a live hosted-IAM assertion",
                "Task",
                "Validation & QA Gates",
                "M",
                "Engineering",
                "To Do",
                ["SRS-07", "DECI-0008", "SPEC-CORE-001-ATTACK-SET"],
                "ATK-15 is an accepted visible hosted-IAM execution gap, not a Phase 1 gate simulation. Close it before any hosted or multi-tenant deployment.",
                [
                    "A live AWS IAM assertion assumes a hosted tenant silo and its scoped deploy role.",
                    "The assertion proves the deploy role cannot decrypt the tenant CMK.",
                    "The assertion proves the deploy role cannot read the tenant ledger and returns no tenant plaintext or record.",
                    "The live assertion is a required pre-deployment check for every hosted/multi-tenant environment.",
                ],
                "A reproducible live AWS IAM assertion passes for both denied operations, captures reviewable evidence, and is enforced before any hosted/multi-tenant deployment.",
                "Founder — Phase 3 hosted tier, before first hosted/multi-tenant deployment",
                links=["SRS-07", "DECI-0008", "SPEC-CORE-001-ATTACK-SET"],
            ),
            work(
                "RES-001",
                "Draft independent-citation remediation plan",
                "Task",
                "Research & Credibility",
                "S",
                "Product manager",
                "To Do",
                ["GLOSSARY-DGR"],
                "Turn the internal citation-gap finding into bounded remediation work.",
                [
                    "Independent evidence channels and target artifacts are listed.",
                    "Self-published and independent evidence are separated.",
                    "No external credibility claim is upgraded.",
                ],
                "Plan has owners as role slots, checkable next actions, and reviewer approval.",
            ),
            work(
                "RES-002",
                "Sync DEPLOY-5 and ICLR primary-artifact links",
                "Task",
                "Research & Credibility",
                "M",
                "Project manager",
                "To Do",
                ["GLOSSARY-DGR"],
                "Replace fact-pack-only research state with primary artifact references.",
                [
                    "Each claimed artifact is linked or marked not authored.",
                    "Dates and outcomes are copied only from primary evidence.",
                    "Missing sources are routed to FND-11.",
                ],
                "Primary-artifact inventory is complete and `make verify` is green.",
                "FND-11",
            ),
            work(
                "TOOL-001",
                "Write orchestration comparison memo",
                "Task",
                "Developer Tooling",
                "M",
                "Engineering",
                "Deferred",
                ["SPEC-AGENT-OPS", "SPEC-AGENT-OPS-DIAGRAM"],
                "Deferred to Phase 2/3 as an input to the runtime-integration architecture ADR. Give the founder a bounded Paperclip versus AgentCore-native decision brief without pulling orchestration selection onto the Phase 1 CORE-002 path.",
                [
                    "Options compare operations, portability, boundary, cost evidence needs, and failure modes.",
                    "Recommendation is explicitly not decided.",
                    "A founder decision gate is identified.",
                ],
                "Decision brief is reviewable, source-linked, and `make verify` is green.",
                "FND-5",
                tags=["deferred", "phase-2-3", "runtime-integration-dependency"],
            ),
            work(
                "TOOL-002",
                "Pin CORE-002 cryptographic and durable-store dependencies",
                "Task",
                "Developer Tooling",
                "S",
                "Engineering",
                "Done",
                [
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                ],
                "Founder-reviewed dgr-core PR #59 pinned ed25519-dalek 2.2.0 and rusqlite 0.40.2 with bundled SQLite; no enforcement logic was authored.",
                [
                    "The founder-approved Ed25519 verification dependency is pinned reproducibly.",
                    "The founder-approved S2 substrate is pinned and demonstrates durable atomic insert-if-absent capability outside the guard.",
                    "Dependency licenses, supported versions, and deterministic build behavior are reviewable.",
                    "No guard, token-verification decision, fail-closed mapping, or consumption logic is authored in this task.",
                ],
                "The approved dependencies and capability checks build reproducibly and are ready for the founder-authored Step 2 and Step 5 units.",
                "Completed by founder merge",
                dependencies=["ARCH-004"],
                links=[
                    "ADR-10",
                    "DECI-0010",
                    "SPEC-CORE-002-GUARD-DESIGN",
                    "HOWTO-CORE-002-GUARD-AUTHORING",
                    "https://github.com/DGR-AI-Labs/dgr-core/pull/59",
                    "https://github.com/DGR-AI-Labs/dgr-core/commit/179d9f15a80be4d38afe2ce6c697ba811f480829",
                ],
            ),
            work(
                "TOOL-003",
                "Deploy and verify both internal auto-publication pipelines",
                "Task",
                "Developer Tooling",
                "M",
                "Engineering",
                "Done",
                ["DECI-0009", "HOWTO-DEPLOY-INTERNAL-HOSTING"],
                "The us-west-2 reference and us-east-1 backlog pipelines are merged, deployed, and recorded as successful with fail-closed ordering and separate publication prefixes.",
                [
                    "Both regional main-branch pipelines are versioned and operational evidence is recorded.",
                    "Reference publication precedes backlog lock validation and publication.",
                    "External publication remains unwired.",
                ],
                "The committed rollout report records successful automatic main executions for both regional pipelines.",
                links=[
                    "DECI-0009",
                    "HOWTO-DEPLOY-INTERNAL-HOSTING",
                    codecommit_commit(
                        "dgr-internal", "us-west-2",
                        "ff003ae8f0244473e05e1e18dbe92301e295630f",
                    ),
                    codecommit_commit(
                        "dgr-backlog", "us-east-1",
                        "16c9fc04d12163b3c319e2519902569a5b4a4572",
                    ),
                ],
            ),
            work(
                "TOOL-004",
                "Emit build-time reference propagation receipts",
                "Task",
                "Developer Tooling",
                "S",
                "Engineering",
                "Done",
                ["DECI-0009"],
                "The internal publisher records previous/current source SHA and UTC propagation metadata at build time.",
                [
                    "A build-time receipt records previous and current source commits plus UTC time.",
                    "Unit and publication verification cover receipt generation.",
                    "The receipt does not alter T0 code.",
                ],
                "The propagation-receipt implementation and tests are merged to dgr-internal main.",
                links=[
                    "DECI-0009",
                    codecommit_commit(
                        "dgr-internal", "us-west-2",
                        "504448f9c437dea95f8849b4b232326374ebda39",
                    ),
                ],
            ),
            work(
                "TOOL-005",
                "Establish the dgr-backlog CodeCommit remote and main trunk",
                "Task",
                "Developer Tooling",
                "S",
                "Engineering",
                "Done",
                ["DECI-0001", "HOWTO-BACKLOG-WORKFLOW"],
                "The backlog history converged to a non-rewritten main trunk and now has an authenticated us-east-1 CodeCommit origin containing current main.",
                [
                    "The canonical trunk is named main without history rewrite.",
                    "The CodeCommit origin exposes main and preserves the converged commits.",
                    "No force-push or unique-commit loss occurs.",
                ],
                "The convergence report is on main and the current CodeCommit main contains it.",
                links=[
                    "DECI-0001",
                    "HOWTO-BACKLOG-WORKFLOW",
                    codecommit_commit(
                        "dgr-backlog", "us-east-1",
                        "8208186501f6aa0817cc31b92870852cef1ed90f",
                    ),
                    codecommit_commit(
                        "dgr-backlog", "us-east-1",
                        "e3c7ce5fcbf3326154327337ee72f7b03d63cab0",
                    ),
                ],
            ),
            work(
                "PM-001",
                "Stand up founder-decision queue hygiene",
                "Task",
                "Validation & QA Gates",
                "S",
                "Project manager",
                "Done",
                ["DECI-0001"],
                "Keep founder decisions separate from co-founder-executable work.",
                [
                    "FND-1 through FND-15 are present and uniquely identified.",
                    "Each item has a Done-when and affected locations.",
                    "No decision outcome is filled.",
                ],
                "Founder queue validates and is linked from role navigation.",
                links=[
                    "DECI-0001",
                    codecommit_commit(
                        "dgr-backlog", "us-east-1",
                        "e3c7ce5fcbf3326154327337ee72f7b03d63cab0",
                    ),
                ],
            ),
            work(
                "PM-002",
                "Apply board-hygiene rules to starter items",
                "Task",
                "Validation & QA Gates",
                "S",
                "Project manager",
                "Done",
                ["DECI-0001"],
                "Ensure every starter is genuinely pickable and finishable.",
                [
                    "Every starter is To Do and size S or M.",
                    "Every starter has prerequisites, acceptance criteria, and DoD.",
                    "WIP guidance remains one to two items.",
                ],
                "Automated starter validation passes.",
                links=[
                    "DECI-0001",
                    codecommit_commit(
                        "dgr-backlog", "us-east-1",
                        "e3c7ce5fcbf3326154327337ee72f7b03d63cab0",
                    ),
                ],
            ),
            work(
                "PROD-001",
                "Draft minimum-irreplaceable-product brief",
                "Task",
                "Strategy & GTM",
                "M",
                "Product manager",
                "To Do",
                ["GLOSSARY-DGR", "SPEC-POLICY-PLANE", "SRS-07"],
                "Keep the wedge on cross-action, rail-agnostic decision governance.",
                [
                    "User, job, boundary, non-goals, and proof are explicit.",
                    "The brief does not collapse into a spending cap or generic governance.",
                    "Open-core and demo choices link to FND-6/FND-8.",
                ],
                "Brief is reviewable by Product and Engineering and `make verify` is green.",
                "FND-6 and FND-8",
            ),
            work(
                "PROD-002",
                "Draft demo acceptance checklist",
                "Task",
                "Policy Plane",
                "S",
                "Product manager",
                "To Do",
                ["SPEC-POLICY-PLANE", "SRS-07"],
                "Define observable demo behavior while leaving scenario selection open.",
                [
                    "Allow, deny, insufficient evidence, and timeout behavior are checkable.",
                    "Payment hero and non-payment slot are separate.",
                    "Scenario choice links to FND-6.",
                ],
                "Checklist is executable once FND-6 resolves and is reviewer-approved.",
                "FND-6",
            ),
            work(
                "SALES-001",
                "Build trigger-qualified target-account list",
                "Task",
                "Strategy & GTM",
                "M",
                "Sales / Business development",
                "To Do",
                ["GLOSSARY-DGR"],
                "Create a bounded list using the stated off-core, digital-first fintech hypothesis.",
                [
                    "Each account has a public trigger and source.",
                    "No private contact data is stored.",
                    "Beachhead remains a founder confirmation.",
                ],
                "A reviewable list with source links and qualification notes exists.",
                "FND-8",
            ),
        ]
    )

    fnd_specs = [
        ("FND-1", "Confirm current phase", "Current phase is recorded in program status and linked to a DECI record.", ["GLOSSARY-DGR"]),
        ("FND-2", "Confirm Foundation Part A state", "Evidence-backed Foundation state is recorded without inferred percentage.", ["HOWTO-FOUNDATION"]),
        ("FND-3", "Assign owner-role per workstream Epic", "All eight workstream owner-role tokens are resolved.", ["DECI-0001"]),
        ("FND-4", "Set priority and DoD per workstream Epic", "All eight Epic priority and DoD tokens are resolved.", ["DECI-0001"]),
        ("FND-5", "Decide ADR-10, ADR-11, and ADR-12", "Each ADR records a founder-approved decision or explicit deferral.", ["ADR-10", "ADR-11", "ADR-12"]),
        ("FND-6", "Lock demo scenario and first non-payment action", "Demo and second action are recorded in a DECI record.", ["SPEC-POLICY-PLANE"]),
        ("FND-7", "Set active validation stack and reviewer model", "The obsolete Phase-0 numeric threshold is explicitly deferred, and the Semgrep, CodeQL, cargo-deny, independent-human-review, and founder-sign-off model is recorded.", ["SRS-07"]),
        ("FND-8", "Set business and Phase-3 gates", "Open-core, capital trigger, pricing, latency, and assurance timing are recorded.", ["GLOSSARY-DGR"]),
        ("FND-9", "Confirm role materials and external allowlist width", "Role lists and external allowlist width are approved without implicit widening.", ["DECI-0001"]),
        ("FND-10", "Name AWS permission sets and deploy boundary", "Exact permission sets, target accounts, and deploy approver are recorded.", ["HOWTO-FOUNDATION"]),
        ("FND-11", "Identify authoritative missing sources", "Unified plan, ADR-5/8/9, tenant runbook, and prompt-library sources are synced or marked to author.", ["DECI-0001"]),
        (
            "FND-12",
            "Rank and define the Model bake-off leaf tasks",
            "Priority and Definition of Done for BKO-001..005 are recorded or explicitly deferred without inferred values.",
            ["SRS-07"],
        ),
        (
            "FND-13",
            "Authorize CORE-002 Phase 1 enforcement in binding governance",
            "The binding dgr-core constitution and phase records explicitly permit the founder-authored CORE-002 enforcement work without a Phase 0 contradiction.",
            ["DECI-0010", "HOWTO-CORE-002-GUARD-AUTHORING"],
        ),
        (
            "FND-14",
            "Select the canonical CORE-002 implementation surface",
            "The Rust and TypeScript T0 surfaces have a recorded canonical disposition, including removal or quarantine of conflicting timing and enforcement paths.",
            ["ADR-10", "ADR-12", "DECI-0010", "SPEC-CORE-002-GUARD-DESIGN"],
        ),
        (
            "FND-15",
            "Approve CORE-002 Ed25519 and S2 dependency choices",
            "Exact vetted Rust dependencies for Ed25519 verification and the durable-local atomic S2 substrate are recorded for implementation.",
            ["ADR-10", "DECI-0010", "SPEC-CORE-002-GUARD-DESIGN"],
        ),
    ]
    items.append(epic("EPIC-FND", "Founder Decision Queue"))
    decision_records = {
        "FND-1": "DECI-0002",
        "FND-2": "DECI-0003",
        "FND-3": "DECI-0004",
        "FND-4": "DECI-0005",
        "FND-5": "DECI-0006",
        "FND-7": "DECI-0011",
    }
    completed_evidence = {
        **{
            item_id: [
                codecommit_commit(
                    "dgr-internal", "us-west-2",
                    "c813399282665723647a8bcc111fade248861b60",
                )
            ]
            for item_id in ("FND-1", "FND-2", "FND-3", "FND-4")
        },
        "FND-5": [
            codecommit_commit(
                "dgr-internal", "us-west-2",
                "322e5c826195a016ed9d0f96342565a6f851e741",
            )
        ],
        "FND-7": [
            codecommit_commit(
                "dgr-internal", "us-west-2",
                "505f3e470109bd10581b79980dc6a3ed2bb0b546",
            )
        ],
        "FND-13": [
            "https://github.com/DGR-AI-Labs/dgr-core/pull/57",
            "https://github.com/DGR-AI-Labs/dgr-core/commit/da6e39e291dcf689ec294463d7e3be8116eeb756",
        ],
        "FND-14": [
            codecommit_commit(
                "dgr-internal", "us-west-2",
                "322e5c826195a016ed9d0f96342565a6f851e741",
            ),
            "https://github.com/DGR-AI-Labs/dgr-core/pull/58",
        ],
        "FND-15": [
            "https://github.com/DGR-AI-Labs/dgr-core/pull/59",
            "https://github.com/DGR-AI-Labs/dgr-core/commit/179d9f15a80be4d38afe2ce6c697ba811f480829",
        ],
    }
    for item_id, title, done_when, prerequisites in fnd_specs:
        decision_id = decision_records.get(item_id)
        evidence = completed_evidence.get(item_id, [])
        items.append(
            work(
                item_id,
                title,
                "Task",
                "Founder Decision Queue",
                "S",
                "Founder",
                "Done" if decision_id or evidence else "To Do",
                prerequisites + ([decision_id] if decision_id else []),
                "Founder-only decision separated from co-founder-executable work.",
                ["Affected token locations are reviewed.", "Outcome or explicit deferral is recorded."],
                done_when,
                "Founder",
                links=([decision_id] if decision_id else prerequisites) + evidence,
            )
        )

    items.append(epic("EPIC-BKO", "Model bake-off"))
    for number, title in enumerate(
        [
            "Probe the Bedrock candidate boundary",
            "Freeze the DGR evaluation battery",
            "Run each approved Tier-1 candidate",
            "Score and validate results",
            "Decide separately per role",
        ],
        1,
    ):
        items.append(
            work(
                f"BKO-{number:03d}",
                title,
                "Task",
                "Model bake-off",
                "M",
                "Founder",
                "{FOUNDER-SUPPLY: migrated status}",
                ["SRS-07"],
                "Migrated from the original model bake-off backlog; original detail remains in Backlog-legacy.md.",
                ["Original acceptance criteria are reviewed before execution."],
                "{FOUNDER-SUPPLY: migrated Definition of Done confirmation}",
                "FND-12",
                links=["SRS-07", "FND-12"],
                priority="{FOUNDER-SUPPLY: migrated priority}",
            )
        )

    runtime_epic = "Runtime integration testing (OpenClaw + Hermes)"
    runtime_prerequisites = ["SRS-07", "ADR-10", "ADR-11", "DECI-0006"]
    runtime_tags = ["deferred", "phase-2-3", "runtime-integration"]
    blocked_until = (
        "Blocked until CORE-005 records the CORE-002 bypass suite fully green for "
        "all gate-tier attacks ATK-01..14 in the isolation harness. Starting earlier "
        "is an anti-pattern: it tests an incomplete guard and forces deferred Phase-3 "
        "orchestration decisions prematurely."
    )
    items.extend(
        [
            work(
                "EPIC-RUNTIME-INTEGRATION",
                runtime_epic,
                "Epic",
                runtime_epic,
                "L — deferred Phase 2/3 stories remain S/M",
                "Engineering",
                "Deferred",
                runtime_prerequisites,
                f"{blocked_until} This epic validates real interception and agent non-bypassability against a live runtime, which the isolation harness cannot prove, but is meaningful only after the guard is proven in isolation.",
                [
                    "The blocked-until trigger remains CORE-005 Done, representing the CORE-002 bypass suite fully green for ATK-01..14.",
                    "All runtime-integration stories remain Deferred until the founder activates the epic.",
                    "No Docker, OpenClaw, Hermes, T0, or integration work begins from this record.",
                ],
                "The runtime-integration idea is preserved as a tracked, clearly deferred Phase-2/3 epic with a concrete bypass-suite-green trigger and its known open risks.",
                "Founder — confirm the epic remains deferred and the blocked-until trigger is correct before merge",
                dependencies=["CORE-005"],
                priority="Unranked",
                tags=runtime_tags,
            ),
            work(
                "RUNTIME-001",
                "Integration architecture ADR",
                "Task",
                runtime_epic,
                "S",
                "Engineering",
                "Deferred",
                ["ADR-10", "ADR-11", "DECI-0006"],
                f"{blocked_until} Relate the real OpenClaw before_tool_call binding to ADR-10 agent-to-gate authentication; the deferred TOOL-001 Paperclip-versus-AgentCore question is an input. This ADR must precede Docker work.",
                ["Record the architecture decision needed to bind the guard to OpenClaw before_tool_call in a real runtime."],
                "{FOUNDER-SUPPLY: RUNTIME-001 Definition of Done}",
                "Founder — activate only after the bypass-suite-green trigger",
                dependencies=["CORE-005", "TOOL-001"],
                priority="Unranked",
                tags=runtime_tags,
            ),
            work(
                "RUNTIME-002",
                "Local OpenClaw + Hermes harness (Docker)",
                "Task",
                runtime_epic,
                "M",
                "Engineering",
                "Deferred",
                ["ADR-11", "DECI-0006"],
                blocked_until,
                ["Describe a reproducible local OpenClaw and Hermes runtime that can exercise the guard against real tool calls."],
                "{FOUNDER-SUPPLY: RUNTIME-002 Definition of Done}",
                "Founder — activate only after RUNTIME-001 is decided",
                dependencies=["CORE-005", "RUNTIME-001"],
                priority="Unranked",
                tags=runtime_tags,
            ),
            work(
                "RUNTIME-003",
                "Integration conformance: real interception",
                "Task",
                runtime_epic,
                "S",
                "Engineering",
                "Deferred",
                ["ADR-11", "SPEC-CORE-001-ATTACK-SET"],
                blocked_until,
                ["Prove a real agent tool call without a valid capability token is blocked at the live hook as the runtime analogue of ATK-01."],
                "{FOUNDER-SUPPLY: RUNTIME-003 Definition of Done}",
                "Founder — activate only after the local runtime harness is approved",
                dependencies=["CORE-005", "RUNTIME-002"],
                priority="Unranked",
                tags=runtime_tags,
            ),
            work(
                "RUNTIME-004",
                "Integration conformance: non-bypassability",
                "Task",
                runtime_epic,
                "S",
                "Engineering",
                "Deferred",
                ["SRS-07", "ADR-11", "SPEC-CORE-001-ATTACK-SET"],
                blocked_until,
                ["Prove the agent cannot route around the live guard to reach an effectful tool within the runtime's control."],
                "{FOUNDER-SUPPLY: RUNTIME-004 Definition of Done}",
                "Founder — activate only after real-interception conformance passes",
                dependencies=["CORE-005", "RUNTIME-003"],
                priority="Unranked",
                tags=runtime_tags,
            ),
            work(
                "RUNTIME-005",
                "Open runtime-integration risks to resolve",
                "Task",
                runtime_epic,
                "S",
                "Engineering",
                "Deferred",
                ["ADR-10", "ADR-11", "DECI-0006"],
                f"{blocked_until} Track hook semantics, Hermes routing, and authentication on the agent-to-gate channel. OpenClaw's official hook decision rules currently document that before_tool_call block is terminal; live-version behavior still requires deferred integration proof.",
                ["Record specific runtime-integration questions and route each to a source, experiment, or founder decision before implementation begins."],
                "{FOUNDER-SUPPLY: RUNTIME-005 Definition of Done}",
                "Founder — confirm risks and evidence requirements when activating the epic",
                dependencies=["CORE-005"],
                links=[
                    "ADR-10",
                    "ADR-11",
                    "DECI-0006",
                    "https://github.com/openclaw/openclaw/blob/main/docs/concepts/agent-loop.md",
                ],
                priority="Unranked",
                tags=runtime_tags,
            ),
        ]
    )

    ids = [str(item["id"]) for item in items]
    if len(ids) != len(set(ids)):
        raise SystemExit("duplicate work-item id")
    items_text = json.dumps(items, indent=2, ensure_ascii=False) + "\n"
    (ROOT / "pm" / "items.json").write_text(items_text, encoding="utf-8")
    display_items = materialize_epic_statuses(items)
    ordered_display_items = [
        *[item for item in display_items if item["status"] != "Deferred"],
        *[item for item in display_items if item["status"] == "Deferred"],
    ]
    lines = ["# DGR Delivery Backlog", ""]
    deferred_heading_written = False
    for item in ordered_display_items:
        if item["status"] == "Deferred" and not deferred_heading_written:
            lines.extend(
                [
                    "# Deferred / Backlog",
                    "",
                    "These Phase-2/3 items are recorded but are not active Kanban work.",
                    "",
                ]
            )
            deferred_heading_written = True
        lines.extend(
            [
                f'<a id="{str(item["id"]).lower()}"></a>',
                f'## {item["id"]} — {item["title"]}',
                "",
                f'- **Type:** {item["type"]}',
                f'- **Epic:** {item["epic"]}',
                f'- **Priority:** {item["priority"]}',
                f'- **Size:** {item["size"]}',
                f'- **Owner-role:** {item["owner-role"]}',
                f'- **Status:** {item["status"]}',
                f'- **Tags:** {", ".join(item["tags"]) or "None"}',
                f'- **Prerequisites:** {", ".join(item["prerequisites"]) or "None"}',
                f'- **Context:** {item["context"]}',
                "- **Acceptance criteria:**",
            ]
        )
        lines.extend(f'  - [ ] {criterion}' for criterion in item["acceptance-criteria"])
        lines.extend(
            [
                f'- **Definition of Done:** {item["definition-of-done"]}',
                f'- **Human gate:** {item["human-gate"]}',
                f'- **Dependencies:** {", ".join(item["dependencies"]) or "None"}',
                f'- **Links:** {", ".join(item["links"]) or "None"}',
                "",
            ]
        )
    (ROOT / "pm" / "Backlog.md").write_text("\n".join(lines), encoding="utf-8")
    founder = ["# Founder Decision Queue", "", "Decision outcomes remain founder-owned.", ""]
    for item in display_items:
        if str(item["id"]).startswith("FND-"):
            founder.extend(
                [
                    f'## {item["id"]} — {item["title"]}',
                    "",
                    f'**Done when:** {item["definition-of-done"]}',
                    "",
                    f'**Affected backlog location:** `pm/items.json:{items_text[:items_text.index(chr(34) + "id" + chr(34) + ": " + chr(34) + str(item["id"]) + chr(34))].count(chr(10)) + 1}`',
                    "",
                    f'**Affected references:** {", ".join(item["links"])}',
                    "",
                ]
            )
    (ROOT / "pm" / "FOUNDER-DECISIONS.md").write_text(
        "\n".join(founder), encoding="utf-8"
    )
    print(json.dumps({"items": len(items), "ids": ids}, indent=2))


if __name__ == "__main__":
    main()
